using System.IO;
using UnityEditor;
using UnityEngine;

namespace ColonyCricket.Editor
{
    public sealed class ArtImportSettings : AssetPostprocessor
    {
        private void OnPreprocessTexture()
        {
            if (!assetPath.StartsWith("Assets/Resources/Art/")) return;
            var texture = (TextureImporter)assetImporter;
            string name = Path.GetFileNameWithoutExtension(assetPath);
            bool screenAsset = name == "Fade" || name == "Panel" || name == "Radar" || name == "Crest" || name == "Launcher";
            texture.mipmapEnabled = !screenAsset;
            texture.wrapMode = screenAsset || name.StartsWith("Board") ? TextureWrapMode.Clamp : TextureWrapMode.Repeat;
            texture.filterMode = screenAsset ? FilterMode.Bilinear : FilterMode.Trilinear;
            texture.textureCompression = name == "Fade" || name == "Panel" ? TextureImporterCompression.Uncompressed :
                TextureImporterCompression.CompressedHQ;
            texture.isReadable = false;
            texture.maxTextureSize = 1024;
        }
    }
}
