using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ColonyCricket.Editor
{
    public static class GameplayChecks
    {
        [MenuItem("Christian Colony Cricket/Verify gameplay logic")]
        public static void VerifyGameplay()
        {
            CheckRoster();
            CheckInput();
            CheckScoring();
            CheckDeliveryAndBounce();
            CheckCommentary();
            CheckBattingRig();
            CheckMissionTargets();
            CheckMissionSelectionHandoff();
            CheckGuardAndTimingMeter();
            CheckChaseHighScores();
            CheckCompleteRounds();
            CheckPersistentResume();
            CheckCompetition();
            CheckBowlingRelease();
            CheckFieldingAndReview();
            Debug.Log("Mission checks passed: grip sockets, joint lengths, targets, chase outcomes, voice assets and four round lengths.");
        }

        private static void CheckRoster()
        {
            var names = new[] { "Rashid", "Aneeza", "Abdullah", "Atif", "Haadi", "Musa", "Haram", "Hania" };
            Require(names.SequenceEqual(CharacterDatabase.Players.Select(player => player.Name)), "Incorrect roster.");
            Require(CharacterDatabase.Players.All(player => player.Deliveries.Length >= 2), "A player cannot bowl.");
            var teams = new TeamManager();
            teams.SwapPlayers(0, 0, 1, 1);
            var match = new MatchManager(teams, new BattingMission(1, Difficulty.Normal, 16), 51);
            Require(match.Striker.Name == "Musa" && match.Bowler.Name == "Haadi", "Incorrect batting or bowling selection.");
        }

        private static void CheckInput()
        {
            var origin = new Vector2(200f, 360f);
            Require(BattingController.Swipe(origin, origin - Vector2.right * 150f, 400f, .2f, out ShotInput left) &&
                left.Direction == -1, "Left swipe did not register.");
            Require(BattingController.Swipe(origin, origin + Vector2.right * 150f, 400f, .2f, out ShotInput right) &&
                right.Direction == 1, "Right swipe did not register.");
            Require(BattingController.Swipe(origin, origin, 400f, .2f, out ShotInput straight) &&
                straight.Direction == 0, "Tap did not produce a straight shot.");
            Require(BattingController.Swipe(origin, origin + Vector2.up * 150f, 400f, .2f, out ShotInput drive) &&
                drive.Direction == 0 && drive.Strength > straight.Strength, "Upward drive is not straight or charged.");
        }

        private static void CheckScoring()
        {
            Vector3 impact = new Vector3(0, .8f, DeliveryTrajectory.BatZ);
            var strike = new Shot { Stroke = Stroke.CoverDrive, Timing = Timing.Perfect, Direction = 1,
                Velocity = new Vector3(42f, -4f, 6f) };
            var boundary = CricketRulesEngine.ForShot(strike, false, impact);
            Require(boundary.Runs == 4 && boundary.Zone == ShotZone.Off && boundary.VoiceKey == "Off4" &&
                boundary.ShotDistance > 38f, "Ground boundary distance, direction, or commentary was incorrect.");
            Require(CricketRulesEngine.ForShot(strike, true, impact).Zone == ShotZone.Leg, "Left-handed shot label was not mirrored.");
            strike.Direction = -1;
            strike.Velocity.x *= -1f;
            DeliveryResult leg = CricketRulesEngine.ForShot(strike, false, impact);
            Require(leg.Zone == ShotZone.Leg && leg.VoiceKey == "Leg4" &&
                CricketRulesEngine.ForShot(strike, true, impact).VoiceKey == "Off4",
                "Leg/off scoring and commentary did not match handedness and physical direction.");

            strike.Direction = 0;
            strike.Velocity = new Vector3(0f, -3f, 7f);
            DeliveryResult shortStrike = CricketRulesEngine.ForShot(strike, false, impact);
            Require(shortStrike.Zone == ShotZone.Straight && shortStrike.Runs < boundary.Runs &&
                shortStrike.ShotDistance < 10f, "A short perfect stroke should stay short.");
            strike.Velocity = new Vector3(0f, -3f, 20f);
            var longer = CricketRulesEngine.ForShot(strike, false, impact);
            Require(longer.ShotDistance > shortStrike.ShotDistance && longer.Runs > shortStrike.Runs,
                "Run scoring ignores simulated distance.");
            strike.Timing = Timing.Early;
            var edge = CricketRulesEngine.ForShot(strike, false, impact);
            Require(edge.Call == BallCall.Dot && Mathf.Approximately(edge.ShotDistance, longer.ShotDistance),
                "Run scoring ignores timing at the same distance.");
            strike.Timing = Timing.Perfect;
            strike.Stroke = Stroke.Loft;
            strike.Velocity = new Vector3(0f, 19.5f, 38f);
            Require(CricketRulesEngine.ForShot(strike, false, impact).Runs == 6, "A clean loft over the rope should score six.");

            var origin = new Vector2(180f, 300f);
            BattingController.Swipe(origin, origin + Vector2.right * 32f, 400f, 1f, out ShotInput shortSwipe);
            BattingController.Swipe(origin, origin + Vector2.right * 180f, 400f, 1f, out ShotInput longSwipe);
            Cricketer batter = CharacterDatabase.Players[0];
            var shortShot = ShotResolver.Resolve(shortSwipe, 1f, 24f, impact, Difficulty.Normal, batter);
            var longShot = ShotResolver.Resolve(longSwipe, 1f, 24f, impact, Difficulty.Normal, batter);
            Require(shortShot.Timing == longShot.Timing && shortShot.Velocity.magnitude < longShot.Velocity.magnitude &&
                CricketRulesEngine.ForShot(shortShot, false, impact).Runs < CricketRulesEngine.ForShot(longShot, false, impact).Runs,
                "Changing the swipe length did not change the outcome for the same timing.");
            Debug.Log("Shot distance checks passed for short and long swipes, timing, ground boundaries and aerial boundaries.");
        }

        private static void CheckDeliveryAndBounce()
        {
            var match = new MatchManager(new TeamManager(), new BattingMission(1, Difficulty.Normal, 16), 72);
            match.StartBowl(BowlingController.Aim(DeliveryType.Fast, new Vector2(0f, -7.9f), false));
            Require(match.Phase == PlayPhase.RunUp && match.ShowLandingPreview, "Run-up or landing preview missing.");
            Vector3 predicted = match.UpcomingBounce;
            Vector3 actual = new Vector3(100f, 0, 0);
            match.Bounce += () => actual = match.BallPosition;
            for (int step = 0; step < 450 && match.Phase != PlayPhase.Decision; step++) match.Tick(1f / 120f);
            Require(Vector3.Distance(predicted, actual) < .23f, "Ball did not meet its predicted bounce.");
            Require(match.LastResult.Call == BallCall.Bowled && match.Rules.Wickets == 1 && match.Rules.Balls == 1, "A yorker into stumps did not count.");
        }

        private static void CheckCommentary()
        {
            var keys = new HashSet<string> { "Dot", "Beaten", "Bowled", "Wide" };
            foreach (ShotZone zone in new[] { ShotZone.Off, ShotZone.Leg, ShotZone.Straight })
                foreach (int runs in new[] { 1, 2, 3, 4, 6 })
                    keys.Add(new DeliveryResult { Call = BallCall.Runs, Zone = zone, Runs = runs }.VoiceKey);
            foreach (string key in keys)
            {
                var clip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Resources/Commentary/" + key + ".wav");
                Require(clip && clip.channels == 1 && clip.length > .15f && clip.length < 1.30f,
                    "Missing or overlong result voice: " + key);
            }
            Require(Resources.LoadAll<AudioClip>("Commentary").Length == keys.Count, "Commentary resource pack does not match match outcomes.");
            Debug.Log("Imported " + keys.Count + " complete, result-synchronised commentary lines.");
        }

        private static void CheckBattingRig()
        {
            foreach (int hand in new[] { -1, 1 })
            {
                var axis = new Vector3(-.49f * hand, .82f, -.30f).normalized;
                var left = new Vector3(.10f * hand, 1.31f, .20f);
                var right = new Vector3(.24f * hand, 1.33f, -.26f);
                var centre = BattingRig.FitGrip(new Vector3(.45f * hand, .78f, .19f),
                    axis, left, right, hand < 0);
                var grip = new BatGrip(centre, axis, Vector3.back);
                Require(Vector3.Distance((grip.Top + grip.Bottom) * .5f, centre) < .001f &&
                    Vector3.Dot((grip.Top - grip.Bottom).normalized, axis) > .999f &&
                    Mathf.Abs(Vector3.Distance(grip.Top, grip.Bottom) - .107f) < .001f,
                    "The aligned grip sockets no longer hold both hands on one handle.");
                Vector3 target = hand < 0 ? grip.Bottom : grip.Top;
                Vector3 elbow = BattingRig.Hinge(left, target, new Vector3(-hand, -.4f, -.3f), .303f, .312f);
                Require(Mathf.Abs(Vector3.Distance(left, elbow) - .303f) < .002f &&
                    Mathf.Abs(Vector3.Distance(elbow, target) - .312f) < .003f, "Batting arm lengths changed during the grip solve.");
            }
        }

        private static void CheckMissionTargets()
        {
            var rng = new System.Random(1154);
            int[,] ranges = { {8, 12}, {13, 18}, {19, 24} };
            foreach (int overs in BattingMission.Lengths)
                for (int level = 0; level < 3; level++)
                {
                    int previous = 0;
                    for (int round = 0; round < 24; round++)
                    {
                        var mission = BattingMission.Roll(overs, (Difficulty)level, rng, previous);
                        Require(mission.Target >= overs * ranges[level, 0] && mission.Target <= overs * ranges[level, 1] &&
                            mission.Target != previous, "Mission target repeated or escaped its difficulty range.");
                        previous = mission.Target;
                    }
                }

            var chase = new CricketRulesEngine(new BattingMission(1, Difficulty.Easy, 8));
            for (int i = 0; i < 4; i++) chase.Record(new DeliveryResult { Call = BallCall.Dot });
            chase.Record(new DeliveryResult { Call = BallCall.Runs, Runs = 4 });
            Require(!chase.Complete && chase.Remaining == 4, "A mission finished before the target or ball limit.");
            chase.Record(new DeliveryResult { Call = BallCall.Runs, Runs = 4 });
            Require(chase.Won && chase.Balls == 6 && chase.Remaining == 0, "A last-ball target should win.");
            chase = new CricketRulesEngine(new BattingMission(10, Difficulty.Hard, 220));
            for (int i = 0; i < 60; i++) chase.Record(new DeliveryResult { Call = BallCall.Dot });
            Require(chase.Complete && !chase.Won && chase.Balls == 60, "A ten-over chase must close after 60 legal balls.");
            chase = new CricketRulesEngine(new BattingMission(2, Difficulty.Normal, 30));
            for (int i = 0; i < 3; i++) chase.Record(new DeliveryResult { Call = BallCall.Bowled });
            Require(chase.Complete && !chase.Won && chase.Balls == 3, "The third dismissal must end a mission.");
            chase = new CricketRulesEngine(new BattingMission(1, Difficulty.Easy, 8));
            chase.Record(new DeliveryResult { Call = BallCall.Runs, Runs = 6 });
            chase.Record(new DeliveryResult { Call = BallCall.Runs, Runs = 2 });
            Require(chase.Won && chase.Complete && chase.Balls == 2, "An early target should finish the mission immediately.");
        }

        private static void CheckMissionSelectionHandoff()
        {
            var keys = new List<string>
            {
                "CCC.Length", "CCC.Difficulty", "CCC.Quality", "CCC.Sound", "CCC.Commentary", "CCC.Music"
            };
            foreach (int overs in BattingMission.Lengths)
                for (int level = 0; level < 3; level++)
                    keys.Add("CCC.Target." + overs + "." + (Difficulty)level);
            var original = keys.ToDictionary(key => key,
                key => PlayerPrefs.HasKey(key) ? (int?)PlayerPrefs.GetInt(key) : null);
            try
            {
                for (int length = 0; length < BattingMission.Lengths.Length; length++)
                    for (int level = 0; level < 3; level++)
                    {
                        // The picker saves before the match scene constructs fresh settings.
                        var pickerSettings = new SettingsManager { Length = length, Difficulty = (Difficulty)level };
                        pickerSettings.Save();

                        var gameplaySettings = new SettingsManager();
                        var round = new MatchManager(new TeamManager(), gameplaySettings.RollMission(), 1251);
                        int overs = BattingMission.Lengths[length];
                        Require(round.Mission.Overs == overs && round.Rules.BallLimit == 6 * overs &&
                            round.Mission.Difficulty == (Difficulty)level,
                            "Mission selection changed when the match scene read its settings.");
                    }
                Debug.Log("Mission selection handoff passed all 12 overs/difficulty combinations: 6, 12, 30, and 60 legal balls.");
            }
            finally
            {
                foreach (var entry in original)
                {
                    if (entry.Value.HasValue) PlayerPrefs.SetInt(entry.Key, entry.Value.Value);
                    else PlayerPrefs.DeleteKey(entry.Key);
                }
                PlayerPrefs.Save();
            }
        }

        private static void CheckGuardAndTimingMeter()
        {
            const float step = 1f / 120f;
            var round = new MatchManager(new TeamManager(), new BattingMission(2, Difficulty.Normal, 26), 72);
            float start = round.BattingGuard.x;
            round.MoveGuard(-1);
            round.Tick(.09f);
            Require(round.BattingGuard.x < start, "Left crease control did not move the batter.");

            BowlingAim aim = BowlingController.Aim(DeliveryType.Fast, new Vector2(0f, -6.2f), false);
            round.StartBowl(aim);
            for (int i = 0; i < 7; i++) round.MoveGuard(1);
            while (round.Phase == PlayPhase.RunUp) round.Tick(step);
            float releaseGuard = round.BattingGuard.x;
            Require(Mathf.Abs(releaseGuard - start - MatchManager.GuardLimit) < .001f,
                "Right crease control did not reach its limit before release.");
            var flight = new DeliveryTrajectory(aim, round.ReleasePoint, round.Mission.Difficulty);
            while (round.Phase == PlayPhase.Delivery && round.PhaseTime < flight.BatTime)
            {
                round.MoveGuard(-1);
                round.Tick(step);
            }
            Require(Mathf.Abs(round.BattingGuard.x - releaseGuard) < .001f, "Guard moved during the delivery.");
            Require(round.Phase == PlayPhase.Delivery, "Timing test ball ended before contact.");
            float meter = round.TimingGuideProgress;
            round.SubmitSwipe(new Vector2(180f, 300f), new Vector2(35f, 300f), 400f);
            Require(round.ShotMeterMark.HasValue && Mathf.Abs(round.ShotMeterMark.Value - meter) < .001f,
                "Shot marker did not capture the submitted timing.");
            for (int i = 0; i < 120 && round.Phase == PlayPhase.Delivery; i++) round.Tick(step);
            Require(round.Phase == PlayPhase.Decision && round.LastResult.Timing == Timing.Perfect &&
                round.ShotMeterMark.HasValue && Mathf.Abs(round.ShotMeterMark.Value - meter) < .001f,
                "Perfect timing or frozen result marker was lost.");
            Debug.Log("Crease movement and shot timing marker checks passed.");
        }

        private static void CheckChaseHighScores()
        {
            const string key = "CCC.TopChases.1.Easy";
            const string other = "CCC.TopChases.1.Hard";
            string saved = PlayerPrefs.HasKey(key) ? PlayerPrefs.GetString(key) : null;
            string savedOther = PlayerPrefs.HasKey(other) ? PlayerPrefs.GetString(other) : null;
            try
            {
                PlayerPrefs.DeleteKey(key);
                PlayerPrefs.DeleteKey(other);
                var mission = new BattingMission(1, Difficulty.Easy, 8);
                var loss = new CricketRulesEngine(mission);
                for (int i = 0; i < 3; i++) loss.Record(new DeliveryResult { Call = BallCall.Bowled });
                ChaseHighScores.Record(mission, loss);
                Require(ChaseHighScores.Read(1, Difficulty.Easy).Count == 0, "A loss appeared in Top Chases.");

                for (int i = 0; i < 8; i++)
                {
                    var win = new CricketRulesEngine(mission);
                    if (i % 2 == 0) win.Record(new DeliveryResult { Call = BallCall.Bowled });
                    win.Record(new DeliveryResult { Call = BallCall.Runs, Runs = 6 });
                    win.Record(new DeliveryResult { Call = BallCall.Runs, Runs = 2 + i % 5 });
                    ChaseHighScores.Record(mission, win);
                }
                var scores = ChaseHighScores.Read(1, Difficulty.Easy);
                Require(scores.Count == 5 && scores[0].Runs == 12 && scores[1].Runs == 11 &&
                    scores[2].Runs == 10 && scores[2].Balls == 2 && scores[3].Runs == 10 && scores[3].Balls == 3 &&
                    scores[4].Runs == 9 && scores[4].Wickets == 0, "Chase ranking or top five cutoff was incorrect.");
                Require(PlayerPrefs.GetString(key).Length > 0 && ChaseHighScores.Read(1, Difficulty.Hard).Count == 0,
                    "Chase scores did not persist separately by difficulty.");
                Debug.Log("Top Chases checks passed for winning-only records, persistence, ranking, and capacity.");
            }
            finally
            {
                if (saved == null) PlayerPrefs.DeleteKey(key);
                else PlayerPrefs.SetString(key, saved);
                if (savedOther == null) PlayerPrefs.DeleteKey(other);
                else PlayerPrefs.SetString(other, savedOther);
                PlayerPrefs.Save();
            }
        }

        private static void CheckCompleteRounds()
        {
            foreach (int overs in BattingMission.Lengths)
            {
                var match = new MatchManager(new TeamManager(), new BattingMission(overs, Difficulty.Normal, 36 * overs), 742 + overs);
                int decisions = 0;
                int contacted = 0;
                int totalRuns = 0;
                var positions = new Vector2(200f, 480f);
                match.Decided += result =>
                {
                    decisions++;
                    totalRuns += result.Runs;
                    if (result.Zone != ShotZone.Middle) contacted++;
                    Require(match.Phase == PlayPhase.Decision && match.Rules.Runs == totalRuns,
                        "Scoring must already be committed when commentary and result UI are notified.");
                };
                for (int step = 0; step < 26000 && match.Phase != PlayPhase.Finished; step++)
                {
                    if (match.Phase == PlayPhase.Delivery && match.TimingProgress >= .975f)
                    {
                        Vector2 end = positions + Vector2.right * ((decisions % 3 - 1) * 170);
                        match.SubmitSwipe(positions, end, 400f);
                    }
                    match.Tick(.02f);
                }
                Require(match.Phase == PlayPhase.Finished && match.Rules.Complete && contacted >= 1 &&
                    match.Rules.Deliveries == decisions && match.Rules.Balls <= overs * 6,
                    "The " + overs + "-over solo round did not complete correctly.");
            }
        }

        private static void CheckPersistentResume()
        {
            const string key = "CCC.MatchResume.1";
            string previous = PlayerPrefs.HasKey(key) ? PlayerPrefs.GetString(key) : null;
            try
            {
                var teams = new TeamManager();
                var session = MatchSession.Create(teams, new BattingMission(2, Difficulty.Normal, 26), 841);
                MatchManager original = MatchManager.Resume(session);
                original.MoveGuard(1);
                original.Rules.Record(new DeliveryResult { Call = BallCall.Runs, Runs = 4 });
                original.StartBowl(BowlingController.Aim(DeliveryType.Fast, new Vector2(0f, -6.2f), false));
                while (original.Phase == PlayPhase.RunUp || original.TimingProgress < .96f) original.Tick(.01f);
                var point = new Vector2(170f, 270f);
                original.SubmitSwipe(point, point + Vector2.right * 160f, 400f);
                session.Round = original.Capture();
                MatchSave.Write(session);
                var saved = MatchSave.Read();
                Require(saved != null && saved.Round.HasInput && saved.Round.Total.Runs == 4 && saved.Round.Target == 26,
                    "Match score, target, or pending swipe did not persist.");
                MatchManager loaded = MatchManager.Resume(saved);
                Require(loaded.Phase == original.Phase && Mathf.Abs(loaded.PhaseTime - original.PhaseTime) < .0001f &&
                    Vector3.Distance(loaded.BallPosition, original.BallPosition) < .0001f &&
                    Vector3.Distance(loaded.BattingGuard, original.BattingGuard) < .0001f &&
                    loaded.ShotMeterMark.HasValue, "Resume did not restore the delivery, position, and timing marker.");
                for (int i = 0; i < 155; i++)
                {
                    original.Tick(.01f);
                    loaded.Tick(.01f);
                }
                Require(original.Rules.Deliveries == loaded.Rules.Deliveries && loaded.Rules.Balls == 2 &&
                    original.Rules.Runs == loaded.Rules.Runs &&
                    Vector3.Distance(loaded.BallPosition, original.BallPosition) < .002f,
                    "Restored deliveries diverged or double-counted balls.");
                Debug.Log("Persistent resume checks passed for score, target, crease, mid-delivery swipe and continued physics.");
            }
            finally
            {
                if (previous == null) PlayerPrefs.DeleteKey(key);
                else PlayerPrefs.SetString(key, previous);
                PlayerPrefs.Save();
            }
        }

        private static void CheckCompetition()
        {
            for (int battingFirst = 0; battingFirst < 2; battingFirst++)
            {
                var session = MatchSession.Create(new TeamManager(), new BattingMission(1, Difficulty.Normal, 0),
                    1531, true, battingFirst, battingFirst);
                var innings = MatchManager.Resume(session);
                Require(innings.UserBowls == (battingFirst == 1) && !innings.Rules.Complete, "Toss did not set the first batting side.");
                var delivery = BowlingController.Aim(DeliveryType.MediumPace, new Vector2(.54f, -4.22f), false);
                PlayInnings(innings, delivery);
                Require(innings.Rules.Balls > 0, "The first innings did not record legal balls.");
                if (innings.UserBowls)
                    Require(innings.Rules.Runs > 0 || innings.LastReplay != null &&
                        innings.LastReplay.Result.Wicket, "AI innings did not produce a playable outcome.");
                session.Round = innings.Capture();
                int first = innings.Rules.Runs;
                session.StartChase();
                var chase = MatchManager.Resume(session);
                Require(chase.Rules.Target == first + 1 && chase.UserBowls != innings.UserBowls &&
                    chase.Rules.Balls == 0 && session.Interval && session.BattingTeam != battingFirst,
                    "Competition did not switch teams and create the chase from the batting total.");
                PlayInnings(chase, delivery);
                session.Round = chase.Capture();
                int expectedWinner = chase.Rules.Runs == first ? -1 : chase.Rules.Won ? session.BattingTeam : battingFirst;
                Require(session.Winner == expectedWinner && session.Score(battingFirst).Runs == first,
                    "Competition win, loss or tie calculation was incorrect.");
                session.Round.Total.Runs = first;
                Require(session.Winner == -1, "A level finish is a tie.");
            }
            Debug.Log("Competition checks passed for both innings orders, user bowling, AI scoring, target, and match results.");
        }

        private static void PlayInnings(MatchManager innings, BowlingAim delivery)
        {
            var start = new Vector2(180f, 290f);
            for (int tick = 0; tick < 2800 && innings.Phase != PlayPhase.Finished; tick++)
            {
                if (innings.UserBowls && innings.Phase == PlayPhase.Ready)
                    innings.StartBowl(delivery);
                if (innings.UserBowls && innings.Phase == PlayPhase.RunUp && !innings.ReleaseLocked && innings.ReleaseCursor >= .79f)
                    innings.LockRelease();
                if (!innings.UserBowls && innings.Phase == PlayPhase.Delivery && innings.TimingProgress >= .978f)
                    innings.SubmitSwipe(start, start + Vector2.up * 170f, 400f);
                innings.Tick(.02f);
            }
            Require(innings.Phase == PlayPhase.Finished, "Competition innings did not complete.");
        }

        private static void CheckBowlingRelease()
        {
            var session = MatchSession.Create(new TeamManager(), new BattingMission(2, Difficulty.Normal, 0), 39, true, 1, 1);
            MatchManager good = MatchManager.Resume(session);
            var over = good.StumpsAim(DeliveryType.Fast, false);
            var around = good.StumpsAim(DeliveryType.Fast, true);
            Require(good.ReleaseFor(over).x < 0f && good.ReleaseFor(around).x > 0f, "Bowling crease switch did not move release.");
            foreach (DeliveryType kind in Enum.GetValues(typeof(DeliveryType)))
            {
                BowlingAim target = good.StumpsAim(kind, true);
                var flight = new DeliveryTrajectory(target, good.ReleaseFor(target), Difficulty.Normal);
                Require(flight.HitsStumps(), "Stumps aim missed with " + kind + ".");
            }
            good.StartBowl(over);
            while (good.ReleaseCursor < .79f) good.Tick(1f / 120f);
            good.LockRelease();
            Require(good.ReleaseGrade == "PERFECT RELEASE", "Green release failed to mark perfect.");
            while (good.Phase != PlayPhase.Decision) good.Tick(1f / 120f);
            Require(good.LastResult.Call == BallCall.Bowled && good.Rules.Wickets == 1,
                "Perfect release on the stumps did not break the wicket.");

            MatchManager miss = MatchManager.Resume(session);
            miss.StartBowl(over);
            miss.Tick(.12f);
            miss.LockRelease();
            Require(miss.ReleaseGrade == "EARLY RELEASE" && !Mathf.Approximately(miss.Aim.Line, over.Line) &&
                miss.Aim.SpeedScale < 1f, "Release timing did not alter line and pace.");
            MatchManager nextEnd = MatchManager.Resume(session);
            for (int i = 0; i < 6; i++) nextEnd.Rules.Record(new DeliveryResult { Call = BallCall.Dot });
            Require(nextEnd.ReverseEnd && nextEnd.World(new Vector3(0f, 0f, -10f)).z == 10f,
                "The playing end did not switch after six legal deliveries.");
            Debug.Log("Bowling release checks passed: metre window, pace and line, all stumps aims, bowled and both ends.");
        }

        private static void CheckFieldingAndReview()
        {
            var hit = new Vector3(15f, .72f, 18.5f);
            var aerial = FieldingSimulation.Resolve(hit, new Vector3(0f, 1.4f, 5f), Difficulty.Normal, true);
            Require(aerial.Collected && aerial.ActuallyCaught && aerial.Appealable && aerial.Player >= 0,
                "A reachable aerial shot was not caught.");
            var ground = FieldingSimulation.Resolve(hit, new Vector3(.2f, -5f, 5f), Difficulty.Normal, true);
            Require(ground.Collected && !ground.ActuallyCaught && ground.ReturnAt > ground.At && ground.FirstBounce >= 0f,
                "A bouncing ball did not produce a ground pickup and throw.");
            Require(Vector3.Distance(FieldingSimulation.FielderPosition(ground, ground.Player, 0f),
                FieldingSimulation.FielderPosition(ground, ground.Player, ground.At)) > .5f,
                "The collecting fielder did not move from their fielding position.");
            var returned = FieldingSimulation.ReturnPosition(ground, ground.ReturnAt);
            Require(Mathf.Abs(returned.x) < .05f && Mathf.Abs(Mathf.Abs(returned.z) - 10f) < .1f,
                "The fielder did not throw back to a wicket.");

            var review = DeliveryReview.FromCatch(ground);
            review.Kind = Appeal.Catch;
            review.OnFieldOut = true;
            Require(review.Apply(new DeliveryResult { Call = BallCall.Caught }, 2).Runs == 2,
                "The catch review did not overturn a grounded ball.");
            var session = MatchSession.Create(new TeamManager(), new BattingMission(2, Difficulty.Normal, 0), 39, true, 0, 0);
            var round = MatchManager.Resume(session);
            BowlingAim aim = round.StumpsAim(DeliveryType.Fast, false);
            var flight = new DeliveryTrajectory(aim, round.ReleaseFor(aim), Difficulty.Normal);
            DeliveryReview lbw = DeliveryReview.FromPad(flight, false);
            Require(lbw.ActualOut && lbw.HitsWicket && lbw.ImpactInline && lbw.PitchedLegal,
                "LBW review does not follow pitch, impact and the wickets.");
            var data = new DeliveryReplay { Aim = aim, Release = round.ReleaseFor(aim), Difficulty = Difficulty.Normal,
                DeliveryTime = flight.TimeAtZ(-9.29f), Evidence = lbw, Impact = lbw.Impact, AfterTime = .65f };
            var replay = new ReplayTimeline(data);
            Require(Vector3.Distance(replay.Ball(data.DeliveryTime), lbw.Impact) < .003f &&
                Vector3.Distance(replay.Ball(replay.Duration), lbw.AtWicket) < .005f,
                "Replay ball does not follow the measured LBW path.");
            Debug.Log("Fielding, instant replay and DRS checks passed for catches, pickups, return throws and LBW projection.");
        }

        private static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
    }
}
