using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ColonyCricket.Editor
{
    public static class GameplayChecks
    {
        [MenuItem("Christian Colony Cricket/Verify gameplay logic")]
        public static void VerifyGameplay()
        {
            CheckRoster();
            CheckRules();
            CheckShots();
            CheckBallFlight();
            CheckInningsTransition();
            CheckSeededMatches();
            Debug.Log("Gameplay logic checks succeeded. Scene rendering, input on a touchscreen and Android runtime QA are device tests.");
        }

        private static void CheckRoster()
        {
            var names = new[] { "Rashid", "Aneeza", "Abdullah", "Atif", "Haadi", "Musa", "Haram", "Hania" };
            Require(names.SequenceEqual(CharacterDatabase.Players.Select(player => player.Name)), "Incorrect roster.");
            Require(CharacterDatabase.Players.All(player => player.Deliveries.Length >= 2), "A player cannot bowl.");
            var teams = new TeamManager();
            teams.SwapPlayers(0, 0, 1, 1);
            teams.SwapPlayers(0, 0, 0, 3);
            Require(teams.Player(0, 3).Name == "Musa" && teams.Player(1, 1).Name == "Rashid", "Lineup swapping failed.");
            var ids = new HashSet<int>();
            for (int team = 0; team < 2; team++)
                for (int slot = 0; slot < 4; slot++) ids.Add(teams.PlayerId(team, slot));
            Require(ids.Count == 8, "Lineup swaps duplicated a player.");
        }

        private static void CheckRules()
        {
            var rules = new CricketRulesEngine(2);
            rules.Record(new DeliveryResult { RunningRuns = 1 }, 0, 4);
            Require(rules.Current.Striker == 1 && rules.Current.Runs == 1 && rules.Current.LegalBalls == 1, "Odd runs did not rotate strike.");
            rules.Record(new DeliveryResult { Extra = Extra.Wide }, 1, 4);
            rules.Record(new DeliveryResult { Extra = Extra.NoBall, Boundary = 4, Dismissal = Dismissal.Caught }, 1, 4);
            Require(rules.Current.Runs == 7 && rules.Current.Extras == 2 && rules.Current.LegalBalls == 1 &&
                rules.Current.Wickets == 0 && rules.Current.Striker == 1, "Extras, catch legality or boundary scoring failed.");
            for (int i = 0; i < 5; i++) rules.Record(default, 1, 4);
            Require(rules.Current.Overs == "1.0" && rules.Current.Striker == 0 && rules.BowlingSlot == 1, "End of over failed.");
            rules.Record(new DeliveryResult { RunningRuns = 1, Dismissal = Dismissal.RunOut, WicketEnd = WicketEnd.NonStriker }, 0, 5);
            Require(rules.LastDismissedSlot == 0 && rules.Current.NonStriker == 2 && rules.BowlingWickets[5] == 0, "Run out ended the wrong batter.");
            rules.Record(new DeliveryResult { Dismissal = Dismissal.Bowled }, 1, 5);
            rules.Record(new DeliveryResult { Dismissal = Dismissal.Caught }, 3, 5);
            Require(rules.Current.Wickets == 3 && rules.InningsEnded, "Three wickets must close an innings.");
            rules.ChangeInnings();
            Require(rules.Target == 9 && rules.Required == 9, "Chase target is wrong.");
            rules.Record(new DeliveryResult { Boundary = 6 }, 4, 0);
            rules.Record(new DeliveryResult { Boundary = 4 }, 4, 0);
            Require(rules.MatchEnded && rules.Required == 0 && rules.Winner == 1, "Successful chase did not finish immediately.");

            var tie = new CricketRulesEngine(1);
            foreach (int _ in Enumerable.Range(0, 6)) tie.Record(default, 0, 4);
            tie.ChangeInnings();
            foreach (int _ in Enumerable.Range(0, 6)) tie.Record(default, 4, 0);
            Require(tie.MatchEnded && tie.Winner == -1, "An equal score at the end must tie.");
        }

        private static void CheckShots()
        {
            Require(BattingController.Swipe(new Vector2(300, 60), new Vector2(80, 60), 400, .9f, out ShotInput left) &&
                left.Direction == -1, "Left gesture did not produce left input.");
            Require(BattingController.Swipe(new Vector2(80, 60), new Vector2(300, 60), 400, .9f, out ShotInput right) &&
                right.Direction == 1, "Right gesture did not produce right input.");
            Require(!BattingController.Swipe(new Vector2(100, 30), new Vector2(100, 340), 400, .9f, out _), "Vertical motion registered as batting.");
            foreach (Cricketer player in CharacterDatabase.Players)
            {
                Shot a = ShotResolver.Resolve(left, .9f, 21, new Vector3(.2f, .8f, -8.8f), Difficulty.Normal, player);
                Shot b = ShotResolver.Resolve(right, .9f, 21, new Vector3(.2f, .8f, -8.8f), Difficulty.Normal, player);
                Require(a.MadeContact && b.MadeContact && a.Velocity.x < 0 && b.Velocity.x > 0, player.Name + " could not play both sides.");
                foreach (DeliveryType type in player.Deliveries)
                {
                    BowlingAim aim = BowlingController.Aim(type, new Vector2(.1f, -6.3f), false);
                    var trajectory = new DeliveryTrajectory(aim, new Vector3(-.69f, 2.03f * player.Height, 8.68f), Difficulty.Normal);
                    Require(trajectory.Position(trajectory.BatTime).z < -8.7f && trajectory.Speed > 0, player.Name + " could not deliver " + type);
                }
            }
            Cricketer rashid = CharacterDatabase.Players[0];
            Vector3 reach = new Vector3(.15f, .82f, -8.8f);
            Shot timed = ShotResolver.Resolve(left, .9f, 22, reach, Difficulty.Normal, rashid);
            left.Time -= .235f;
            Shot early = ShotResolver.Resolve(left, .9f, 22, reach, Difficulty.Normal, rashid);
            Require(timed.Timing == Timing.Perfect && early.Timing == Timing.Early &&
                timed.Velocity.magnitude > early.Velocity.magnitude, "Timing did not change contact.");
            Require(ShotTimingSystem.Rate(.45f, 24f, Difficulty.Normal, 1f) == Timing.Miss, "Far outside the window must miss.");
        }

        private static void CheckBallFlight()
        {
            Vector3 strike = new Vector3(0, .91f, -8.8f);
            var ball = new BallPhysicsController();
            ball.Launch(strike, new Vector3(43, -2.5f, 8));
            for (int i = 0; i < 1200 && ball.Boundary == 0; i++) ball.Tick(1 / 120f);
            Require(ball.Boundary == 4 && ball.Grounded, "A ground boundary must score four.");
            ball.Launch(strike, new Vector3(33, 18, 11));
            for (int i = 0; i < 1200 && ball.Boundary == 0; i++) ball.Tick(1 / 120f);
            Require(ball.Boundary == 6 && !ball.Grounded, "A direct aerial boundary must score six.");
            ball.Launch(strike, new Vector3(3, 1, 1));
            for (int i = 0; i < 1200 && ball.Boundary == 0; i++) ball.Tick(1 / 120f);
            Require(ball.Boundary == 0 && ball.Rolling && ball.Velocity.magnitude < .005f, "A soft shot did not roll to a stop.");
        }

        private static void CheckInningsTransition()
        {
            var match = new MatchManager(new TeamManager(), 1, Difficulty.Normal, 8834);
            for (int i = 0; i < 3; i++)
            {
                match.StartBowl(BowlingController.Aim(DeliveryType.Fast, new Vector2(0, -7.95f), false));
                Until(match, PlayPhase.Decision);
                Require(match.LastResult.Dismissal == Dismissal.Bowled, "Physical yorker did not take the stumps on a missed shot.");
                Until(match, i == 2 ? PlayPhase.Interval : PlayPhase.Ready);
            }
            match.AdvanceContinued();
            Require(!match.HumanBatting && match.Rules.Target == 1, "Wrong switch to the bowling innings.");
            match.StartBowl(BowlingController.Aim(DeliveryType.Fast, new Vector2(1.48f, -7.8f), false));
            Until(match, PlayPhase.Finished);
            Require(match.Rules.Winner == 1 && match.Rules.Current.LegalBalls == 0, "Winning wide should finish the chase without a legal ball.");
        }

        private static void CheckSeededMatches()
        {
            foreach (int overs in new[] { 1, 2, 5 })
            {
                var match = new MatchManager(new TeamManager(), overs, Difficulty.Normal, 742 + overs);
                bool swiped = false;
                int decisions = 0;
                match.Decided += _ => decisions++;
                for (int step = 0; step < 36000 && !match.Rules.MatchEnded; step++)
                {
                    if (match.Phase == PlayPhase.Ready)
                    {
                        swiped = false;
                        if (!match.HumanBatting)
                            match.StartBowl(BowlingController.Aim(match.Bowler.Deliveries[0],
                                new Vector2(.28f * (decisions % 3 - 1), -4.7f - decisions % 3), false));
                    }
                    else if (match.Phase == PlayPhase.Interval)
                    {
                        Require(match.Rules.Current.LegalBalls <= 6 * overs, "Innings exceeded the configured overs.");
                        match.AdvanceContinued();
                    }
                    else if (match.HumanBatting && !swiped && match.Phase == PlayPhase.Delivery && match.TimingProgress > .965f)
                    {
                        int end = decisions % 2 == 0 ? 20 : 380;
                        match.SubmitSwipe(new Vector2(200, 400), new Vector2(end, 400), 400);
                        swiped = true;
                    }

                    match.Tick(.02f);
                    Require(match.Rules.Current.Wickets <= 3 && match.Rules.Current.LegalBalls <= 6 * overs, "Bad match limits.");
                }
                Require(match.Rules.MatchEnded && decisions >= 2, $"A {overs} over match did not finish.");
                Require(match.Rules.Scores[1].Runs >= 0 && match.Rules.Scores[0].Runs >= 0, "A score became negative.");
            }
        }

        private static void Until(MatchManager match, PlayPhase desired)
        {
            for (int i = 0; i < 960 && match.Phase != desired; i++) match.Tick(.0125f);
            Require(match.Phase == desired, "Timed out waiting for phase " + desired);
        }

        private static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
    }
}
