using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ColonyCricket.Editor
{
    public static class GameplayChecks
    {
        [MenuItem("Christian Colony Cricket/Verify gameplay logic")]
        public static void VerifyGameplay()
        {
            CheckRoster();
            CheckInput();
            CheckScoring();
            CheckDeliveryAndBounce();
            CheckCommentary();
            CheckCompleteRounds();
            Debug.Log("Solo batting checks passed: directional input, timing, instant scoring, bounce, commentary and round completion.");
        }

        private static void CheckRoster()
        {
            var names = new[] { "Rashid", "Aneeza", "Abdullah", "Atif", "Haadi", "Musa", "Haram", "Hania" };
            Require(names.SequenceEqual(CharacterDatabase.Players.Select(player => player.Name)), "Incorrect roster.");
            Require(CharacterDatabase.Players.All(player => player.Deliveries.Length >= 2), "A player cannot bowl.");
            var teams = new TeamManager();
            teams.SwapPlayers(0, 0, 1, 1);
            var match = new MatchManager(teams, 1, Difficulty.Normal, 51);
            Require(match.Striker.Name == "Musa" && match.Bowler.Name == "Haadi", "Incorrect batting or bowling selection.");
        }

        private static void CheckInput()
        {
            var origin = new Vector2(200f, 360f);
            Require(BattingController.Swipe(origin, origin - Vector2.right * 150f, 400f, .2f, out ShotInput left) &&
                left.Direction == -1, "Left swipe did not register.");
            Require(BattingController.Swipe(origin, origin + Vector2.right * 150f, 400f, .2f, out ShotInput right) &&
                right.Direction == 1, "Right swipe did not register.");
            Require(BattingController.Swipe(origin, origin, 400f, .2f, out ShotInput straight) &&
                straight.Direction == 0, "Tap did not produce a straight shot.");
            Require(BattingController.Swipe(origin, origin + Vector2.up * 150f, 400f, .2f, out ShotInput drive) &&
                drive.Direction == 0 && drive.Strength > straight.Strength, "Upward drive is not straight or charged.");
        }

        private static void CheckScoring()
        {
            Vector3 impact = new Vector3(0, .8f, DeliveryTrajectory.BatZ);
            var strike = new Shot { Stroke = Stroke.CoverDrive, Timing = Timing.Perfect, Direction = -1,
                Velocity = new Vector3(-24, 2, 14) };
            var perfect = CricketRulesEngine.ForShot(strike, false, impact);
            Require(perfect.Runs == 4 && perfect.Zone == ShotZone.Off && perfect.VoiceKey == "Off4", "Perfect off drive did not synchronise its score and voice key.");
            Require(CricketRulesEngine.ForShot(strike, true, impact).Zone == ShotZone.Leg, "Left-handed shot label was not mirrored.");
            strike.Direction = 0;
            strike.Timing = Timing.Good;
            Require(CricketRulesEngine.ForShot(strike, false, impact).Zone == ShotZone.Straight, "Straight shot labelled incorrectly.");
            Require(CricketRulesEngine.ForShot(strike, false, impact).Runs == 3, "Strong good timing must score three.");
            strike.Timing = Timing.Ok;
            Require(CricketRulesEngine.ForShot(strike, false, impact).Runs == 1, "OK timing must score one.");
            strike.Timing = Timing.Early;
            Require(CricketRulesEngine.ForShot(strike, false, impact).Call == BallCall.Dot, "An edge should be a dot.");
            strike.Timing = Timing.Perfect;
            strike.Stroke = Stroke.Loft;
            strike.Velocity = new Vector3(0, 19.5f, 38f);
            Require(CricketRulesEngine.ForShot(strike, false, impact).Runs == 6, "A clean loft over the rope should score six.");
        }

        private static void CheckDeliveryAndBounce()
        {
            var match = new MatchManager(new TeamManager(), 1, Difficulty.Normal, 72);
            match.StartBowl(BowlingController.Aim(DeliveryType.Fast, new Vector2(0f, -7.9f), false));
            Require(match.Phase == PlayPhase.RunUp && match.ShowLandingPreview, "Run-up or landing preview missing.");
            Vector3 predicted = match.UpcomingBounce;
            Vector3 actual = new Vector3(100f, 0, 0);
            match.Bounce += () => actual = match.BallPosition;
            for (int step = 0; step < 450 && match.Phase != PlayPhase.Decision; step++) match.Tick(1f / 120f);
            Require(Vector3.Distance(predicted, actual) < .23f, "Ball did not meet its predicted bounce.");
            Require(match.LastResult.Call == BallCall.Bowled && match.Rules.Wickets == 1 && match.Rules.Balls == 1, "A yorker into stumps did not count.");
        }

        private static void CheckCommentary()
        {
            var keys = new HashSet<string> { "Dot", "Beaten", "Bowled", "Wide" };
            foreach (ShotZone zone in new[] { ShotZone.Off, ShotZone.Leg, ShotZone.Straight })
                foreach (int runs in new[] { 1, 2, 3, 4, 6 })
                    keys.Add(new DeliveryResult { Call = BallCall.Runs, Zone = zone, Runs = runs }.VoiceKey);
            foreach (string key in keys)
            {
                var clip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Resources/Commentary/" + key + ".wav");
                Require(clip && clip.channels == 1 && clip.length > .15f && clip.length < 1.30f,
                    "Missing or overlong result voice: " + key);
            }
            Require(Resources.LoadAll<AudioClip>("Commentary").Length == keys.Count, "Commentary resource pack does not match match outcomes.");
            Debug.Log("Imported " + keys.Count + " complete, result-synchronised commentary lines.");
        }

        private static void CheckCompleteRounds()
        {
            foreach (int overs in new[] { 1, 2, 5 })
            {
                var match = new MatchManager(new TeamManager(), overs, Difficulty.Normal, 742 + overs);
                int decisions = 0;
                int contacted = 0;
                int totalRuns = 0;
                var positions = new Vector2(200f, 480f);
                match.Decided += result =>
                {
                    decisions++;
                    totalRuns += result.Runs;
                    if (result.Zone != ShotZone.Middle) contacted++;
                    Require(match.Phase == PlayPhase.Decision && match.Rules.Runs == totalRuns,
                        "Scoring must already be committed when commentary and result UI are notified.");
                };
                for (int step = 0; step < 26000 && match.Phase != PlayPhase.Finished; step++)
                {
                    if (match.Phase == PlayPhase.Delivery && match.TimingProgress >= .975f)
                    {
                        Vector2 end = positions + Vector2.right * ((decisions % 3 - 1) * 170);
                        match.SubmitSwipe(positions, end, 400f);
                    }
                    match.Tick(.02f);
                }
                Require(match.Phase == PlayPhase.Finished && match.Rules.Complete && contacted >= 1 &&
                    match.Rules.Deliveries == decisions && match.Rules.Balls <= overs * 6,
                    "The " + overs + "-over solo round did not complete correctly.");
            }
        }

        private static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
    }
}
