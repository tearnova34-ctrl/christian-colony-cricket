using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace ColonyCricket.Editor
{
    [InitializeOnLoad]
    public static class AndroidBuildConfiguration
    {
        public const string PackageName = "com.christiancolony.cricket";
        public const string ApkFilename = "Christian_Colony_Cricket.apk";
        private const string RenderFolder = "Assets/Resources/Art";
        private const string PipelineFolder = "Assets/Rendering";
        private static readonly string[] Scenes =
        {
            "Assets/Scenes/MainMenu.unity", "Assets/Scenes/TeamSelection.unity",
            "Assets/Scenes/CricketMatch.unity", "Assets/Scenes/MatchResult.unity"
        };

        static AndroidBuildConfiguration()
        {
            EditorApplication.delayCall += InitializeProject;
        }

        private static void InitializeProject()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += InitializeProject;
                return;
            }
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            Configure();
            if (!Application.isBatchMode && string.IsNullOrEmpty(SceneManager.GetActiveScene().path) &&
                !SceneManager.GetActiveScene().isDirty)
                EditorSceneManager.OpenScene(Scenes[0]);
        }

        [MenuItem("Christian Colony Cricket/Configure project")]
        public static void Configure()
        {
            EnsureRendering();
            PlayerSettings.companyName = "Christian Colony";
            PlayerSettings.productName = "Christian Colony Cricket";
            PlayerSettings.bundleVersion = "0.8.0";
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, PackageName);
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.useAnimatedAutorotation = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = false;
            PlayerSettings.allowedAutorotateToLandscapeRight = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToPortrait = true;
            PlayerSettings.colorSpace = ColorSpace.Linear;
            PlayerSettings.SplashScreen.show = false;
            PlayerSettings.Android.bundleVersionCode = 9;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.applicationEntry = AndroidApplicationEntry.Activity;
            PlayerSettings.Android.forceInternetPermission = false;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.OpenGLES3 });
            PlayerSettings.Android.textureCompressionFormats = new[] { TextureCompressionFormat.ETC2 };

            var icon = AssetDatabase.LoadAssetAtPath<Texture2D>(RenderFolder + "/Launcher.png");
            if (icon) PlayerSettings.SetIconsForTargetGroup(BuildTargetGroup.Unknown, new[] { icon });

            EditorBuildSettings.scenes = Scenes.Select(path => new EditorBuildSettingsScene(path, true)).ToArray();
            AssetDatabase.SaveAssets();
        }

        // Set this as the Pre-export method in the Unity Build Automation target.
        public static void PrepareCloudBuild()
        {
            Configure();
            GameplayChecks.VerifyGameplay();
        }

        [MenuItem("Christian Colony Cricket/Build Android APK")]
        public static void BuildAndroid()
        {
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
                throw new BuildFailedException("Install Android Build Support, Android SDK/NDK Tools and OpenJDK for the project's Unity Editor.");
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
            {
                if (Application.isBatchMode)
                    throw new BuildFailedException("Start the editor process with -buildTarget Android.");
                if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
                    throw new BuildFailedException("Unity could not switch the active build target to Android.");
            }

            Configure();
            GameplayChecks.VerifyGameplay();
            PlayerSettings.Android.useCustomKeystore = false;
            EditorUserBuildSettings.buildAppBundle = false;
            EditorUserBuildSettings.exportAsGoogleAndroidProject = false;
            string folder = Environment.GetEnvironmentVariable("CCC_BUILD_DIR");
            if (string.IsNullOrWhiteSpace(folder)) folder = Path.GetFullPath("Builds/Android");
            Directory.CreateDirectory(folder);
            string destination = Path.Combine(folder, ApkFilename);
            BuildReport report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
            {
                scenes = Scenes,
                target = BuildTarget.Android,
                targetGroup = BuildTargetGroup.Android,
                locationPathName = destination,
                options = BuildOptions.StrictMode
            });
            bool succeeded = report != null && report.summary.result == BuildResult.Succeeded;
            if (!succeeded || !File.Exists(destination) || new FileInfo(destination).Length == 0)
                throw new BuildFailedException("Unity did not produce a successful Android APK. Check the build log.");
            Debug.Log($"Android APK created at {destination} ({report.summary.totalSize:N0} bytes). Install and run on an Android device for gameplay QA.");
        }

        private static void EnsureRendering()
        {
            if (!AssetDatabase.IsValidFolder(PipelineFolder)) AssetDatabase.CreateFolder("Assets", "Rendering");
            string rendererPath = PipelineFolder + "/ColonyRenderer.asset";
            string pipelinePath = PipelineFolder + "/ColonyURP.asset";
            var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(rendererPath);
            if (!renderer)
            {
                renderer = ScriptableObject.CreateInstance<UniversalRendererData>();
                AssetDatabase.CreateAsset(renderer, rendererPath);
            }
            var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(pipelinePath);
            if (!pipeline)
            {
                pipeline = UniversalRenderPipelineAsset.Create(renderer);
                pipeline.shadowDistance = 46;
                pipeline.msaaSampleCount = 4;
                pipeline.supportsHDR = false;
                AssetDatabase.CreateAsset(pipeline, pipelinePath);
            }
            GraphicsSettings.defaultRenderPipeline = pipeline;
            Template("SurfaceTemplate", "Universal Render Pipeline/Lit");
            Template("SignTemplate", "Universal Render Pipeline/Unlit");
        }

        private static void Template(string name, string shaderName)
        {
            string path = RenderFolder + "/" + name + ".mat";
            if (AssetDatabase.LoadAssetAtPath<Material>(path)) return;
            Shader shader = Shader.Find(shaderName);
            if (!shader) throw new BuildFailedException("URP shader import is incomplete: " + shaderName);
            AssetDatabase.CreateAsset(new Material(shader), path);
        }
    }
}
