Shader "Colony/ArenaSky"
{
    Properties
    {
        _Top ("Zenith", Color) = (.115,.32,.54,1)
        _Horizon ("Horizon", Color) = (.63,.79,.90,1)
        _SunColor ("Sun", Color) = (1,.76,.39,1)
    }
    SubShader
    {
        Tags { "Queue"="Background" "RenderType"="Background" "PreviewType"="Skybox" "RenderPipeline"="UniversalPipeline" }
        Cull Off ZWrite Off
        Pass
        {
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            CBUFFER_START(UnityPerMaterial)
                half4 _Top, _Horizon, _SunColor;
            CBUFFER_END
            struct Varyings { float4 positionCS : SV_POSITION; float3 direction : TEXCOORD0; };
            Varyings vert(float4 vertex : POSITION)
            {
                Varyings o;
                o.positionCS = TransformObjectToHClip(vertex.xyz);
                o.direction = vertex.xyz;
                return o;
            }
            half4 frag(Varyings i) : SV_Target
            {
                float3 direction = normalize(i.direction);
                float up = saturate(direction.y);
                float sun = saturate(dot(direction, normalize(float3(-.75,.29,.39))));
                float glow = pow(sun, 18);
                half3 sky = lerp(_Horizon.rgb, _Top.rgb, pow(up, .47));
                sky = lerp(sky, _SunColor.rgb, glow * .33 + smoothstep(.9985, .9995, sun) * .62);
                float cloud = sin(direction.x * 19 + direction.z * 12) * sin(direction.z * 17 - direction.x * 7);
                cloud += sin(direction.x * 64 + direction.z * 51) * .25;
                float band = smoothstep(.045,.23,up) * (1 - smoothstep(.29,.54,up));
                sky = lerp(sky, half3(.88,.91,.95), smoothstep(.49,.92,cloud) * band * .33);
                return half4(sky, 1);
            }
            ENDHLSL
        }
    }
}
