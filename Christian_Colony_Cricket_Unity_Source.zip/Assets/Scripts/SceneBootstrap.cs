using UnityEngine;

namespace ColonyCricket
{
    public sealed class SceneBootstrap : MonoBehaviour
    {
        private GameManager current;

        private void Start()
        {
            current = new GameManager(transform);
        }

        private void Update()
        {
            current?.Update();
        }
    }
}
