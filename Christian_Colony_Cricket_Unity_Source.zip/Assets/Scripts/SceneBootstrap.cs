using UnityEngine;

namespace ColonyCricket
{
    public sealed class SceneBootstrap : MonoBehaviour
    {
        private GameManager current;

        private void Start()
        {
            current = new GameManager(transform);
        }

        private void OnApplicationPause(bool background) => current?.OnApplicationPause(background);

        private void OnApplicationQuit() => current?.SaveActiveMatch();

        private void Update()
        {
            current?.Update();
        }
    }
}
