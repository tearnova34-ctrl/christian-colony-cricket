using System;
using UnityEngine;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class MatchStatsOverlay
    {
        private readonly RectTransform layer;
        private readonly RectTransform[] rows = new RectTransform[10];
        private readonly Text[] over = new Text[10], batter = new Text[10], bowler = new Text[10];
        private readonly Text caption, notice;
        private readonly Button first, second;
        private MatchSession session;
        private MatchManager active;
        private bool showFirst;

        public bool Active => layer.gameObject.activeSelf;

        public MatchStatsOverlay(UIManager ui, Action dismiss)
        {
            RectTransform card = ui.Modal("Over scorecard", .665f, Palette.India, out layer);
            ui.Label(card, new Rect(.1f, .046f, .80f, .071f), "SCORECARD", 29, UIManager.Gold);
            ui.Graphic(card, new Rect(.065f, .126f, .16f, .125f), "AvatarBatter", fitted: true);
            ui.Graphic(card, new Rect(.775f, .126f, .16f, .125f), "AvatarBowler", fitted: true);
            caption = ui.Label(card, new Rect(.225f, .129f, .55f, .111f), "", 15, UIManager.Ivory);
            first = ui.Button(card, new Rect(.12f, .253f, .36f, .064f), "1ST INNINGS", UIManager.PanelTint, UIManager.Ivory,
                () => { showFirst = true; Draw(); }, 14);
            second = ui.Button(card, new Rect(.52f, .253f, .36f, .064f), "2ND INNINGS", UIManager.PanelTint, UIManager.Ivory,
                () => { showFirst = false; Draw(); }, 14);
            ui.Label(card, new Rect(.055f, .337f, .15f, .038f), "OVER", 12, UIManager.Muted);
            ui.Label(card, new Rect(.226f, .337f, .30f, .038f), "BATTER", 12, UIManager.Muted);
            ui.Label(card, new Rect(.55f, .337f, .375f, .038f), "BOWLER", 12, UIManager.Muted);
            for (int i = 0; i < rows.Length; i++)
            {
                rows[i] = ui.Panel(card, new Rect(.065f, .387f + i * .042f, .87f, .039f), UIManager.PanelTint);
                over[i] = ui.Label(rows[i], new Rect(.00f, 0f, .18f, 1f), "", 13, UIManager.Gold);
                batter[i] = ui.Label(rows[i], new Rect(.19f, 0f, .35f, 1f), "", 13, UIManager.Ivory);
                bowler[i] = ui.Label(rows[i], new Rect(.55f, 0f, .44f, 1f), "", 13, UIManager.Ivory);
            }
            notice = ui.Label(card, new Rect(.07f, .813f, .86f, .054f), "", 12, UIManager.Muted);
            ui.Button(card, new Rect(.20f, .88f, .60f, .074f), "BACK", UIManager.Gold, UIManager.Ink, dismiss, 18);
            Close();
        }

        public void Open(MatchSession game, MatchManager match)
        {
            session = game;
            active = match;
            showFirst = false;
            Draw();
            layer.SetAsLastSibling();
            layer.gameObject.SetActive(true);
        }

        private void Draw()
        {
            bool two = session.Competition && session.SecondInnings;
            first.gameObject.SetActive(two);
            second.gameObject.SetActive(two);
            if (two)
            {
                first.targetGraphic.color = showFirst ? UIManager.Blue : UIManager.PanelTint;
                second.targetGraphic.color = showFirst ? UIManager.PanelTint : UIManager.Blue;
            }
            int side = showFirst ? session.BattingFirst : session.BattingTeam;
            Cricketer striker = CharacterDatabase.Players[side == 0 ? session.PakistanCaptain : session.IndiaCaptain];
            Cricketer opposing = CharacterDatabase.Players[side == 0 ? session.IndiaCaptain : session.PakistanCaptain];
            caption.text = striker.Name.ToUpperInvariant() + " BAT\n" + opposing.Name.ToUpperInvariant() + " BOWL";
            OverFigure[] entries = showFirst ? session.FirstOvers : session.Round.Scorecard;
            bool limited = showFirst ? entries == null || entries.Length == 0 :
                active != null ? active.Scorecard.HistoricalOversUnavailable : session.Round.LegacyBallsFaced > 0 || session.Round.LegacyBatRuns > 0;
            for (int i = 0; i < rows.Length; i++)
            {
                bool visible = i < session.Overs;
                rows[i].gameObject.SetActive(visible);
                if (!visible) continue;
                OverFigure line = !showFirst && active != null ? active.Scorecard.At(i) :
                    entries != null && i < entries.Length ? entries[i] : default;
                over[i].text = (i + 1).ToString();
                batter[i].text = line.Deliveries == 0 ? "—" : line.BatRuns + " (" + line.BallsFaced + ")";
                bowler[i].text = line.Deliveries == 0 ? "—" : line.Wickets + " W  ·  " + line.BowlerRuns + " R";
            }
            notice.text = limited ? "Earlier overs were saved as totals only." : "";
        }

        public void Close() => layer.gameObject.SetActive(false);
    }
}
