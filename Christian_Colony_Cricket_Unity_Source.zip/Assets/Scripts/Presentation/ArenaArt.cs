using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace ColonyCricket
{
    internal sealed class ArenaArt
    {
        private readonly Dictionary<string, Material> materials = new Dictionary<string, Material>();
        private readonly Shader lit, unlit;
        public static readonly Color Blue = new Color(.105f, .37f, .92f);
        public static readonly Color Gold = new Color(1f, .71f, .18f);
        public static readonly Color Navy = new Color(.032f, .081f, .159f);
        public static readonly Color Bone = new Color(.91f, .94f, .94f);
        public static readonly Color Green = new Color(.078f, .25f, .19f);

        public ArenaArt()
        {
            Material litTemplate = Resources.Load<Material>("Art/SurfaceTemplate");
            Material unlitTemplate = Resources.Load<Material>("Art/SignTemplate");
            lit = litTemplate ? litTemplate.shader : Shader.Find("Universal Render Pipeline/Lit");
            unlit = unlitTemplate ? unlitTemplate.shader : Shader.Find("Universal Render Pipeline/Unlit");
        }

        public Material Mat(string name, Color color, string texture = null, bool flat = false, float tile = 1)
        {
            if (materials.TryGetValue(name, out Material material)) return material;
            material = new Material(flat ? unlit : lit) { name = name, color = color, enableInstancing = true };
            material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", .24f);
            if (texture != null)
            {
                material.SetTexture("_BaseMap", Resources.Load<Texture2D>("Art/" + texture));
                material.SetTextureScale("_BaseMap", Vector2.one * tile);
            }
            materials.Add(name, material);
            return material;
        }

        public static Transform Node(string name, Transform parent, Vector3 position)
        {
            Transform node = new GameObject(name).transform;
            node.SetParent(parent, false);
            node.localPosition = position;
            return node;
        }

        public static Transform Part(string name, Transform parent, Mesh shape, Material material,
            Vector3 position, Vector3 scale, bool shadow = true)
        {
            Transform node = Node(name, parent, position);
            node.localScale = scale;
            node.gameObject.AddComponent<MeshFilter>().sharedMesh = shape;
            MeshRenderer render = node.gameObject.AddComponent<MeshRenderer>();
            render.sharedMaterial = material;
            if (!shadow) render.shadowCastingMode = ShadowCastingMode.Off;
            return node;
        }
    }

    internal static class Forms
    {
        public static Mesh Ball { get; private set; }
        public static Mesh Tube { get; private set; }
        public static Mesh Box { get; private set; }
        public static Mesh Quad { get; private set; }
        public static Mesh Bat { get; private set; }
        public static Mesh Shirt { get; private set; }
        public static Mesh Sleeve { get; private set; }
        public static Mesh Trousers { get; private set; }
        public static Mesh Head { get; private set; }
        public static Mesh Cap { get; private set; }
        public static Mesh Shoe { get; private set; }
        public static Mesh CrowdBody { get; private set; }
        public static Mesh CrowdHead { get; private set; }

        public static void Initialize()
        {
            if (Ball) return;
            Ball = Profile("Rounded form", 14, .05f, .07f, .51f, .59f, .81f, .88f, .96f, 1f, 1f, 1f, .94f, .97f,
                .80f, .86f, .58f, .62f, .05f, .07f);
            Tube = Profile("Rounded cylinder", 12, .12f, .12f, .96f, .96f, 1, 1, 1, 1, .96f, .96f, .12f, .12f);
            Shirt = Profile("Jersey tailoring", 13, .80f, .72f, .84f, .80f, .85f, .86f, .91f, .99f, 1f, 1f,
                .91f, .94f, .64f, .81f, .40f, .67f);
            Sleeve = Profile("Sleeve and muscle", 10, .72f, .75f, .88f, .92f, .96f, 1f, 1f, .96f, .82f, .83f, .67f, .68f);
            Trousers = Profile("Tapered kit leg", 10, .60f, .70f, .69f, .76f, .75f, .82f, .88f, .91f, 1f, 1f, .84f, .93f);
            Head = Profile("Cheeks and jaw", 14, .42f, .54f, .65f, .69f, .85f, .90f, .96f, 1f,
                1f, .99f, .91f, .92f, .74f, .83f, .41f, .52f, .04f, .05f);
            Cap = Profile("Six-panel cap", 14, .73f, .82f, .99f, 1f, 1f, 1f, .94f, .94f, .77f, .80f, .47f, .53f, .06f, .10f);
            Shoe = Profile("Cleated cricket shoe", 12, .88f, .95f, 1f, 1f, .98f, .98f, .80f, .86f, .52f, .68f, .23f, .38f);
            Bat = Profile("Beveled willow blade", 12, new[] { .84f, .63f, .97f, .77f, 1f, .95f, .98f, 1f, .91f, .95f, .44f, .58f, .28f, .51f }, .31f);
            CrowdBody = Profile("Crowd body", 6, .64f, .69f, .89f, .93f, .77f, .80f, .42f, .49f);
            CrowdHead = Profile("Crowd head", 6, .22f, .28f, 1, 1, .82f, .90f, .20f, .30f);
            Quad = Make("Sign quad", new[] { new Vector3(-.5f, -.5f), new Vector3(-.5f, .5f),
                new Vector3(.5f, .5f), new Vector3(.5f, -.5f) }, new[] { 0, 1, 2, 0, 2, 3 },
                new[] { Vector2.zero, Vector2.up, Vector2.one, Vector2.right });
            Box = MakeBox();
        }

        private static Mesh Profile(string name, int sides, params float[] outline) => Profile(name, sides, outline, 1f);

        private static Mesh Profile(string name, int sides, float[] outline, float squareness)
        {
            int rings = outline.Length / 2;
            var verts = new Vector3[rings * (sides + 1) + 2];
            var uv = new Vector2[verts.Length];
            var indices = new List<int>(rings * sides * 6);
            for (int y = 0; y < rings; y++)
            {
                float h = (float)y / (rings - 1);
                for (int x = 0; x <= sides; x++)
                {
                    float turn = (float)x / sides;
                    float a = turn * 2f * Mathf.PI;
                    float sx = Mathf.Cos(a);
                    float sz = Mathf.Sin(a);
                    int i = y * (sides + 1) + x;
                    verts[i] = new Vector3(Mathf.Sign(sx) * Mathf.Pow(Mathf.Abs(sx), squareness) * outline[y * 2] * .5f,
                        h, Mathf.Sign(sz) * Mathf.Pow(Mathf.Abs(sz), squareness) * outline[y * 2 + 1] * .5f);
                    uv[i] = new Vector2(turn, h);
                    if (x == sides || y == rings - 1) continue;
                    int next = i + sides + 1;
                    indices.Add(i); indices.Add(next); indices.Add(i + 1);
                    indices.Add(i + 1); indices.Add(next); indices.Add(next + 1);
                }
            }
            int bottom = verts.Length - 2;
            int top = verts.Length - 1;
            verts[top] = Vector3.up;
            for (int x = 0; x < sides; x++)
            {
                int ringTop = (rings - 1) * (sides + 1) + x;
                indices.Add(bottom); indices.Add(x); indices.Add(x + 1);
                indices.Add(top); indices.Add(ringTop + 1); indices.Add(ringTop);
            }

            Mesh mesh = Make(name, verts, indices.ToArray(), uv);
            Vector3[] normals = mesh.normals;
            for (int ring = 0; ring < rings; ring++)
            {
                int left = ring * (sides + 1);
                int right = left + sides;
                Vector3 normal = (normals[left] + normals[right]).normalized;
                normals[left] = normals[right] = normal;
            }
            mesh.normals = normals;
            return mesh;
        }

        private static Mesh MakeBox()
        {
            Vector3[] points = {
                new Vector3(-.5f, -.5f, -.5f), new Vector3(.5f, -.5f, -.5f), new Vector3(.5f, .5f, -.5f), new Vector3(-.5f, .5f, -.5f),
                new Vector3(-.5f, -.5f, .5f), new Vector3(.5f, -.5f, .5f), new Vector3(.5f, .5f, .5f), new Vector3(-.5f, .5f, .5f)
            };
            int[] faceCorners = { 0, 3, 2, 1, 5, 6, 7, 4, 1, 2, 6, 5, 4, 7, 3, 0, 3, 7, 6, 2, 4, 0, 1, 5 };
            var vertices = new Vector3[24];
            var uv = new Vector2[24];
            var triangles = new int[36];
            for (int face = 0; face < 6; face++)
            {
                int start = face * 4;
                for (int i = 0; i < 4; i++) vertices[start + i] = points[faceCorners[start + i]];
                uv[start] = Vector2.zero; uv[start + 1] = Vector2.up; uv[start + 2] = Vector2.one; uv[start + 3] = Vector2.right;
                int index = face * 6;
                triangles[index] = start; triangles[index + 1] = start + 1; triangles[index + 2] = start + 2;
                triangles[index + 3] = start; triangles[index + 4] = start + 2; triangles[index + 5] = start + 3;
            }
            return Make("Chamfer support box", vertices, triangles, uv);
        }

        public static Mesh Make(string name, Vector3[] points, int[] tris, Vector2[] uv)
        {
            var mesh = new Mesh { name = name, vertices = points, uv = uv, triangles = tris };
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }
    }
}
