using UnityEngine;

namespace ColonyCricket
{
    internal sealed class FieldingAvatar
    {
        private readonly Transform[] legs = new Transform[2], arms = new Transform[2], hands = new Transform[2];
        private readonly Transform torso, skull;
        public readonly Transform Root;

        public FieldingAvatar(Transform parent, ArenaArt art, int team, int index)
        {
            Root = ArenaArt.Node("Fielder " + (index + 1), parent, Vector3.zero);
            float scale = .92f + (index % 4) * .036f;
            Root.localScale = Vector3.one * scale;
            Material shirt = art.Mat("Kit shirt " + team, Color.white, team == 0 ? "PAKJersey" : "INDJersey");
            Material pants = art.Mat("Field trousers " + team, team == 0 ? new Color(.045f, .27f, .16f) : new Color(.055f, .235f, .51f));
            Material skin = art.Mat("Field skin " + index, Color.Lerp(new Color(.40f, .225f, .147f),
                new Color(.77f, .55f, .42f), (index % 5) / 5f));
            Material footwear = art.Mat("Fielder white shoes", new Color(.90f, .94f, .94f));
            Material gloves = index == FieldingSimulation.Homes.Length - 1 ? footwear : skin;
            torso = ArenaArt.Node("Fielder body", Root, Vector3.zero);
            ArenaArt.Part("Field jersey", torso, Forms.Shirt, shirt, new Vector3(0f, -.05f, 0f), new Vector3(.56f, .62f, .33f));
            skull = ArenaArt.Part("Field head", torso, Forms.Ball, skin, new Vector3(0f, .54f, .01f),
                new Vector3(.217f, .294f, .238f));
            ArenaArt.Part("Field cap", torso, Forms.Cap, shirt, new Vector3(0f, .745f, .017f), new Vector3(.251f, .108f, .261f), false);
            ArenaArt.Part("Cap visor", torso, Forms.Ball, shirt, new Vector3(0f, .733f, .117f), new Vector3(.216f, .029f, .221f), false);
            for (int i = 0; i < 2; i++)
            {
                int side = 2 * i - 1;
                legs[i] = ArenaArt.Node("Leg", torso, new Vector3(.121f * side, 0f, 0f));
                ArenaArt.Part("Field trousers", legs[i], Forms.Trousers, pants, new Vector3(0f, -.84f, 0f),
                    new Vector3(.206f, .84f, .22f), false);
                ArenaArt.Part("Field boots", legs[i], Forms.Shoe, footwear, new Vector3(0f, -.89f, .055f),
                    new Vector3(.139f, .109f, .238f), false);
                arms[i] = ArenaArt.Node("Arm", torso, new Vector3(.235f * side, .418f, 0));
                ArenaArt.Part("Shirt sleeve", arms[i], Forms.Sleeve, shirt, new Vector3(0f, -.23f, 0f),
                    new Vector3(.162f, .254f, .166f), false);
                ArenaArt.Part("Forearm", arms[i], Forms.Sleeve, skin, new Vector3(0f, -.49f, 0f),
                    new Vector3(.118f, .31f, .123f), false);
                hands[i] = ArenaArt.Part("Hand", arms[i], Forms.Ball, gloves, new Vector3(0f, -.55f, 0f),
                    new Vector3(.095f, .121f, .091f), false);
            }
        }

        public void Animate(Vector3 position, Vector3 focus, float time, float effort, float collect, float throwing, float catchHeight)
        {
            Vector3 facing = focus - position;
            facing.y = 0f;
            Root.SetPositionAndRotation(position, facing.sqrMagnitude > .001f ? Quaternion.LookRotation(facing) : Quaternion.identity);
            float stride = Mathf.Sin(time * 14.4f) * effort;
            torso.localPosition = new Vector3(0f, .91f + Mathf.Abs(stride) * .06f - collect * Mathf.Lerp(.32f, .02f, catchHeight), 0f);
            torso.localRotation = Quaternion.Euler(9f * effort + collect * 22f * (1f - catchHeight), 0f, 3f * stride);
            skull.localRotation = Quaternion.Euler(-10f * effort - catchHeight * collect * 11f, 0f, 0f);
            for (int i = 0; i < 2; i++)
            {
                int side = 2 * i - 1;
                legs[i].localRotation = Quaternion.Euler(side * stride * 34f - collect * 6f, 0f, side * 4f);
                arms[i].localRotation = Quaternion.Euler(side * -stride * 36f - collect * (49f + 79f * catchHeight) -
                    (i == 1 ? throwing * 135f : 0f), 0f, side * (9f - 6f * collect));
            }
        }
    }

    internal sealed class FieldingView
    {
        private readonly FieldingAvatar[] actors = new FieldingAvatar[FieldingSimulation.Homes.Length];

        public FieldingView(Transform parent, ArenaArt art, int team)
        {
            for (int i = 0; i < actors.Length; i++) actors[i] = new FieldingAvatar(parent, art, team, i);
        }

        public void Draw(FieldingSimulation.Play play, float time, bool inPlay, Vector3 ball, bool reversed)
        {
            for (int i = 0; i < actors.Length; i++)
            {
                bool handles = inPlay && play.Collected && play.Player == i;
                float collect = handles ? Mathf.SmoothStep(0f, 1f, (time - play.At + .24f) / .24f) *
                    (1f - Mathf.SmoothStep(0f, 1f, (time - play.At - .12f) / .31f)) : 0f;
                float throwing = handles && !play.ActuallyCaught ? Mathf.Sin(Mathf.PI * Mathf.Clamp01((time - play.At - .22f) / .48f)) : 0f;
                Vector3 position = inPlay ? FieldingSimulation.FielderPosition(play, i, time) : FieldingSimulation.Homes[i];
                float effort = inPlay && time < play.At && (position - FieldingSimulation.Homes[i]).sqrMagnitude > .035f ?
                    (play.Player == i ? 1f : .57f) : 0f;
                actors[i].Animate(MatchManager.World(position, reversed), MatchManager.World(inPlay ? ball : new Vector3(0f, 0f, -8f), reversed),
                    time + i * .38f, effort, collect, throwing, Mathf.Clamp01((play.Pickup.y - .2f) / 1.5f));
            }
        }
    }
}
