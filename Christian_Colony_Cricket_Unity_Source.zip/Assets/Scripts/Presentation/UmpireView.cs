using UnityEngine;

namespace ColonyCricket
{
    internal sealed class UmpireView
    {
        private readonly PlayerCharacter main, square;
        public UmpireView(Transform parent, ArenaArt art)
        {
            main = new PlayerCharacter(parent, art, "Kosar Parveen", 8, 2,
                new Cricketer("Kosar Parveen", false, 1f, 1f, 1f, .98f, 1.05f, DeliveryType.MediumPace));
            square = new PlayerCharacter(parent, art, "Razia Parveen", 9, 2,
                new Cricketer("Razia Parveen", false, 1f, 1f, 1f, .94f, .98f, DeliveryType.MediumPace));
        }

        public void Draw(DeliveryResult result, float elapsed, bool signalling, bool reversed, bool leftHanded)
        {
            Vector3 leg = PitchLayout.SquareLegUmpire(leftHanded);
            main.Root.SetPositionAndRotation(PitchLayout.ToWorld(PitchLayout.BowlerEndUmpire, reversed),
                Quaternion.Euler(0f, reversed ? 0f : 180f, 0f));
            Vector3 squarePosition = PitchLayout.ToWorld(leg, reversed);
            Vector3 atCrease = PitchLayout.ToWorld(new Vector3(0f, 0f, -9.26f), reversed);
            square.Root.SetPositionAndRotation(squarePosition, Quaternion.LookRotation(atCrease - squarePosition));
            ActorPose signal = result.Wicket ? ActorPose.SignalOut : result.Runs == 6 ? ActorPose.SignalSix :
                result.Runs == 4 ? ActorPose.SignalFour : ActorPose.Idle;
            main.Act(signalling ? signal : ActorPose.Idle, elapsed);
            square.Act(signalling && result.Runs == 6 ? ActorPose.SignalSix : ActorPose.Idle, elapsed);
        }
    }
}
