using UnityEngine;

namespace ColonyCricket
{
    internal sealed class UmpireView
    {
        private readonly PlayerCharacter main, square;
        public UmpireView(Transform parent, ArenaArt art)
        {
            main = new PlayerCharacter(parent, art, "Kosar Parveen", 8, 2,
                new Cricketer("Kosar Parveen", false, 1f, 1f, 1f, .98f, 1.05f, DeliveryType.MediumPace));
            square = new PlayerCharacter(parent, art, "Razia Parveen", 9, 2,
                new Cricketer("Razia Parveen", false, 1f, 1f, 1f, .94f, .98f, DeliveryType.MediumPace));
        }

        public void Draw(DeliveryResult result, float elapsed, bool signalling, bool reversed)
        {
            PlayerCharacter actor = result.Runs == 6 ? square : main;
            main.Root.SetPositionAndRotation(MatchManager.World(new Vector3(1.23f, 0f, 10.67f), reversed),
                Quaternion.Euler(0f, reversed ? 0f : 180f, 0f));
            square.Root.SetPositionAndRotation(MatchManager.World(new Vector3(4.55f, 0f, -7.35f), reversed),
                Quaternion.Euler(0f, reversed ? 90f : -90f, 0f));
            ActorPose signal = result.Wicket ? ActorPose.SignalOut : result.Runs == 6 ? ActorPose.SignalSix :
                result.Runs == 4 ? ActorPose.SignalFour : result.Call == BallCall.Wide ? ActorPose.SignalWide : ActorPose.Idle;
            main.Act(signalling && actor == main ? signal : ActorPose.Idle, elapsed);
            square.Act(signalling && actor == square ? signal : ActorPose.Idle, elapsed);
        }
    }
}
