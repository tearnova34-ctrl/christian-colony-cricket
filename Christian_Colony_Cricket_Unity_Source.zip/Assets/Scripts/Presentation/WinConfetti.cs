using UnityEngine;

namespace ColonyCricket
{
    internal sealed class WinConfetti
    {
        private readonly RectTransform root;
        private readonly Flake[] flakes = new Flake[36];
        private readonly float started;

        private struct Flake
        {
            public RectTransform View;
            public float X, Delay, Fall, Drift, Spin, Size;
        }

        public WinConfetti(UIManager ui)
        {
            root = UIManager.RectNode("Victory confetti", ui.Safe, new Rect(0, 0, 1, 1));
            var random = new System.Random(61);
            Color[] colors = { UIManager.Gold, UIManager.Blue, new Color(.43f, .98f, .80f), UIManager.Ivory };
            for (int i = 0; i < flakes.Length; i++)
            {
                var panel = ui.Panel(root, new Rect(0, 0, .01f, .01f), colors[i % colors.Length], false);
                flakes[i] = new Flake { View = panel, X = (i + .5f) / flakes.Length,
                    Delay = (float)random.NextDouble() * .72f, Fall = .24f + (float)random.NextDouble() * .28f,
                    Drift = ((float)random.NextDouble() - .5f) * .19f,
                    Spin = 105f + (float)random.NextDouble() * 280f, Size = .006f + (float)random.NextDouble() * .008f };
            }
            started = Time.unscaledTime;
            Draw();
        }

        public void Draw()
        {
            if (!root.gameObject.activeSelf) return;
            float time = Time.unscaledTime - started;
            if (time > 2.9f)
            {
                root.gameObject.SetActive(false);
                return;
            }
            for (int i = 0; i < flakes.Length; i++)
            {
                Flake item = flakes[i];
                float elapsed = time - item.Delay;
                float y = 1.025f - elapsed * item.Fall - elapsed * elapsed * .067f;
                item.View.gameObject.SetActive(elapsed >= 0f && y > -.03f);
                if (elapsed < 0f || y <= -.03f) continue;
                float x = item.X + Mathf.Sin(elapsed * 4f + i) * .018f + item.Drift * elapsed;
                item.View.anchorMin = new Vector2(x, y);
                item.View.anchorMax = new Vector2(x + item.Size, y + item.Size * .83f);
                item.View.localRotation = Quaternion.Euler(0f, 0f, elapsed * item.Spin);
            }
        }
    }
}
