using UnityEngine;

namespace ColonyCricket
{
    internal sealed class ArenaMatchView
    {
        private readonly Stadium stadium;
        private readonly PlayerCharacter[] roster;
        private readonly PlayerCharacter[][] field = new PlayerCharacter[2][];
        private readonly MatchManager match;
        private readonly UmpireController umpire;
        private float swingTime = 5;
        private Shot stroke;
        private Vector3 impact;
        private int striker, partner, bowler, oldTeam;
        private string previousStriker;
        private bool powerful;
        public bool Powerful => powerful;

        public ArenaMatchView(Stadium stadium, ArenaArt art, PlayerCharacter[] roster, MatchManager match)
        {
            this.stadium = stadium;
            this.roster = roster;
            this.match = match;
            for (int team = 0; team < 2; team++)
            {
                field[team] = new PlayerCharacter[match.Fielders.Length];
                for (int i = 0; i < field[team].Length; i++)
                    field[team][i] = new PlayerCharacter(stadium.Root, art,
                        i == 0 ? "Wicketkeeper" : "Fielder", 20 + i, team, simple: i > 2);
            }
            umpire = new UmpireController(stadium.Root, art);
            match.Changed += KeepRoles;
            match.Swing += OnSwing;
            KeepRoles();
        }

        private void OnSwing(Shot shot)
        {
            swingTime = 0;
            stroke = shot;
            impact = match.BallPosition;
            powerful = shot.MadeContact && shot.Velocity.magnitude > 23.4f;
        }

        private void KeepRoles()
        {
            if (match.Phase != PlayPhase.Ready) return;
            PlayerVisibility(false);
            striker = match.StrikerId; partner = match.PartnerId; bowler = match.BowlerId;
            oldTeam = match.Rules.Innings;
            PlayerVisibility(true);
            roster[striker].Dress(true);
            roster[partner].Dress(true);
            roster[bowler].Dress(false);
            swingTime = 5;
            powerful = false;
            stadium.NearWicket.Animate(0);
            stadium.FarWicket.Animate(0);
        }

        private void PlayerVisibility(bool show)
        {
            if (!show)
            {
                foreach (PlayerCharacter actor in roster) actor.Root.gameObject.SetActive(false);
            }
            else
            {
                roster[striker].Root.gameObject.SetActive(true);
                roster[partner].Root.gameObject.SetActive(true);
                roster[bowler].Root.gameObject.SetActive(true);
            }
            for (int team = 0; team < 2; team++)
                foreach (PlayerCharacter actor in field[team]) actor.Root.gameObject.SetActive(show && team != oldTeam);
        }

        public void Draw(BowlingAim selectedAim, bool paused)
        {
            PlayPhase phase = match.Phase;
            float t = match.PhaseTime;
            if (!paused) swingTime += Time.deltaTime;
            bool decision = phase == PlayPhase.Decision;
            DeliveryResult result = match.LastResult;
            bool wicket = decision && result.Dismissal != Dismissal.None;
            bool boundary = decision && result.Boundary > 0;
            bool crossing = match.Runners != null && match.Runners.Crossing && !wicket && !boundary && !decision;
            bool runningContext = match.Runners != null && !boundary;
            bool newBatter = previousStriker != CharacterDatabase.Players[striker].Name;
            if ((phase == PlayPhase.Ready && t > 1.25f) || phase == PlayPhase.RunUp)
                previousStriker = CharacterDatabase.Players[striker].Name;

            PlayerCharacter facing = roster[striker];
            PlayerCharacter waiting = roster[partner];
            PlayerCharacter shooter = roster[bowler];
            Cricketer batter = CharacterDatabase.Players[striker];
            Vector3 near = RunningBetweenWickets.BattingGuard(batter);
            Vector3 far = RunningBetweenWickets.NonStrikerCrease;
            ActorPose nearPose = ActorPose.Stance;
            ActorPose farPose = ActorPose.Idle;
            float nearTime = Time.time;
            float farTime = Time.time;
            if (newBatter && phase == PlayPhase.Ready && t < .74f)
            {
                near.x += (batter.LeftHanded ? 1 : -1) * (1 - Mathf.SmoothStep(0, 1, t / .74f)) * 1.35f;
                nearPose = ActorPose.Walk;
                nearTime = t;
            }

            bool strikerDismissed = wicket && match.DismissedName == CharacterDatabase.Players[striker].Name;
            bool partnerDismissed = wicket && match.DismissedName == CharacterDatabase.Players[partner].Name;
            if (runningContext && (match.Runners.Attempted || match.Runners.Completed > 0))
            {
                near = match.Runners.StrikerPosition;
                far = match.Runners.PartnerPosition;
                if (crossing)
                {
                    nearPose = farPose = ActorPose.Run;
                    nearTime = farTime = Time.time;
                }
            }
            if (wicket && t > .45f)
            {
                float distance = (t - .45f) * 1.62f;
                if (strikerDismissed) { nearPose = ActorPose.Dismissed; near.x += distance; nearTime = t; }
                if (partnerDismissed) { farPose = ActorPose.Dismissed; far.x += distance; farTime = t; }
            }
            else if (boundary && t > .30f)
            {
                nearPose = ActorPose.Celebrate;
                nearTime = t;
            }
            if (swingTime >= .72f && (phase == PlayPhase.RunUp || phase == PlayPhase.Delivery) && nearPose == ActorPose.Stance)
            {
                nearPose = ActorPose.Prepare;
                nearTime = phase == PlayPhase.RunUp ? Mathf.Clamp01(t / match.RunUpDuration) * .48f :
                    Mathf.Lerp(.48f, 1f, match.TimingProgress);
            }
            if (swingTime < .72f && nearPose == ActorPose.Stance)
            {
                nearPose = Convert(stroke.Stroke);
                nearTime = swingTime;
            }

            facing.Root.position = near;
            waiting.Root.position = far;
            facing.Root.rotation = Quaternion.Euler(0, strikerDismissed && t > .45f ? 90 : nearPose == ActorPose.Walk ? (batter.LeftHanded ? -90 : 90) :
                crossing && (match.Runners.Completed % 2 == 1) ? 180 : 0, 0);
            waiting.Root.rotation = Quaternion.Euler(0, partnerDismissed && t > .45f ? 90 :
                crossing && (match.Runners.Completed % 2 == 1) ? 0 : 180, 0);
            bool swinging = nearPose >= ActorPose.Cover && nearPose <= ActorPose.Miss;
            Vector3? batContact = swinging && stroke.MadeContact ? facing.Root.InverseTransformPoint(impact) : (Vector3?)null;
            facing.Act(nearPose, nearTime, batter.LeftHanded, snap: swinging && swingTime < .05f,
                contact: batContact, shotDirection: swinging ? stroke.Direction : 0);
            waiting.Act(farPose, farTime);

            Vector3 shooterPosition = match.RunningStart;
            ActorPose bowlerPose = ActorPose.Idle;
            float bowlerTime = Time.time;
            if (phase == PlayPhase.RunUp)
            {
                float fraction = Mathf.Clamp01(t / match.RunUpDuration);
                shooterPosition = Vector3.Lerp(match.RunningStart, match.RunningRelease, fraction);
                bowlerPose = fraction < .58f ? ActorPose.Run : CharacterDatabase.IsSpin(match.Aim.Type) ? ActorPose.SpinRelease : ActorPose.FastRelease;
                bowlerTime = fraction < .58f ? t : Mathf.InverseLerp(.58f, 1, fraction);
            }
            else if (phase != PlayPhase.Ready)
            {
                shooterPosition = match.RunningRelease;
                if (phase == PlayPhase.Delivery)
                {
                    shooterPosition.z -= Mathf.SmoothStep(0, .87f, Mathf.Min(1, t * 3f));
                    if (t < .37f)
                    {
                        bowlerPose = CharacterDatabase.IsSpin(match.Aim.Type) ? ActorPose.SpinRelease : ActorPose.FastRelease;
                        bowlerTime = 1f + t / .37f;
                    }
                }
                if (wicket && t > .22f) { bowlerPose = ActorPose.Celebrate; bowlerTime = t; }
            }
            shooter.Root.position = shooterPosition;
            shooter.Root.rotation = Quaternion.Euler(0, 180, 0);
            shooter.Act(bowlerPose, bowlerTime, snap: phase == PlayPhase.RunUp && bowlerPose != ActorPose.Run);

            for (int i = 0; i < match.Fielders.Length; i++)
            {
                FielderAI state = match.Fielders[i];
                PlayerCharacter actor = field[1 - oldTeam][i];
                actor.Root.position = state.Position;
                Vector3 direction = state.Heading;
                ActorPose action = state.Speed > .65f ? ActorPose.Run : ActorPose.Idle;
                float actionTime = Time.time + i * .21f;
                if (match.ActiveFielder == i)
                {
                    if (phase == PlayPhase.Throw)
                    {
                        action = t < .19f ? ActorPose.Pickup : t < .67f ? ActorPose.Throw : ActorPose.Idle;
                        direction = Vector3.ProjectOnPlane(near - state.Position, Vector3.up).normalized;
                        actionTime = t;
                    }
                    else if (decision && t < .67f && (result.Dismissal == Dismissal.Caught || i == 0))
                    {
                        action = ActorPose.Catch;
                        actionTime = t;
                    }
                }
                if (direction.sqrMagnitude > .01f)
                    actor.Root.rotation = Quaternion.Slerp(actor.Root.rotation, Quaternion.LookRotation(direction), Time.deltaTime * 12f);
                actor.Act(action, actionTime);
            }

            umpire.Animate(match);
            if (wicket && result.Dismissal == Dismissal.Bowled) stadium.NearWicket.Animate(t);
            if (wicket && result.Dismissal == Dismissal.RunOut)
            {
                Wickets disturbed = result.WicketEnd == WicketEnd.Striker ? stadium.NearWicket : stadium.FarWicket;
                disturbed.Animate(t);
            }
            stadium.ShowAim(selectedAim, match.Bowler.Height, !match.HumanBatting && phase == PlayPhase.Ready);
            stadium.ShowBall(match.BallPosition, match.BallVisible, phase == PlayPhase.Flight || phase == PlayPhase.Delivery);
        }

        private static ActorPose Convert(Stroke selection)
        {
            switch (selection)
            {
                case Stroke.CoverDrive: return ActorPose.Cover;
                case Stroke.Cut: return ActorPose.Cut;
                case Stroke.Pull: return ActorPose.Pull;
                case Stroke.Flick: return ActorPose.Flick;
                case Stroke.OnDrive: return ActorPose.OnDrive;
                case Stroke.OffDrive: return ActorPose.OffDrive;
                case Stroke.Loft: return ActorPose.Loft;
                case Stroke.Defensive: return ActorPose.Defend;
                default: return ActorPose.Miss;
            }
        }
    }
}
