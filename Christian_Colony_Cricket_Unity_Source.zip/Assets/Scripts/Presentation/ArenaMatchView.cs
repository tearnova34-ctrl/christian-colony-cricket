using UnityEngine;

namespace ColonyCricket
{
    internal sealed class ArenaMatchView
    {
        private readonly Stadium stadium;
        private readonly PlayerCharacter batter, bowler;
        private readonly MatchManager match;
        private Shot stroke;

        public ArenaMatchView(Stadium stadium, PlayerCharacter[] roster, MatchManager match)
        {
            this.stadium = stadium;
            this.match = match;
            batter = roster[match.StrikerId];
            bowler = roster[match.BowlerId];
            batter.Root.gameObject.SetActive(true);
            batter.Dress(true);
            batter.Root.position = match.BattingGuard;
            bowler.Root.gameObject.SetActive(true);
            bowler.Dress(false);
            bowler.Root.rotation = Quaternion.Euler(0, 180, 0);
            match.Swing += shot => stroke = shot;
        }

        public void Draw()
        {
            PlayPhase phase = match.Phase;
            float t = match.PhaseTime;
            bool contact = phase == PlayPhase.Decision && match.ShotVelocity.sqrMagnitude > .01f;
            bool bowled = phase == PlayPhase.Decision && match.LastResult.Call == BallCall.Bowled;

            ActorPose pose = ActorPose.Stance;
            float swing = t;
            Vector3? impact = null;
            if (phase == PlayPhase.RunUp || phase == PlayPhase.Delivery)
            {
                pose = ActorPose.Prepare;
                swing = phase == PlayPhase.RunUp ? Mathf.Clamp01(t / match.RunUpDuration) * .46f :
                    Mathf.Lerp(.46f, 1f, match.TimingProgress);
            }
            if (contact && t < .74f)
            {
                pose = StrokePose(stroke.Stroke);
                impact = batter.Root.InverseTransformPoint(match.ContactPosition);
            }
            else if (phase == PlayPhase.Decision && (bowled || match.LastResult.Timing == Timing.Miss) &&
                match.LastResult.Call != BallCall.Wide && t < .45f)
            {
                pose = ActorPose.Miss;
            }
            batter.Act(pose, swing, match.Striker.LeftHanded, snap: contact && t < .037f,
                contact: impact, shotDirection: contact ? stroke.Direction : 0);

            ActorPose releasePose = CharacterDatabase.IsSpin(match.Aim.Type) ? ActorPose.SpinRelease : ActorPose.FastRelease;
            Vector3 position = MatchManager.RunningStart;
            ActorPose bowlPose = ActorPose.Idle;
            float bowlMoment = t;
            if (phase == PlayPhase.RunUp)
            {
                float fraction = Mathf.Clamp01(t / match.RunUpDuration);
                position = Vector3.Lerp(MatchManager.RunningStart, MatchManager.RunningRelease, fraction);
                bowlPose = fraction < .64f ? ActorPose.Run : releasePose;
                bowlMoment = bowlPose == ActorPose.Run ? t : Mathf.InverseLerp(.64f, 1f, fraction);
            }
            else if (phase != PlayPhase.Ready)
            {
                position = MatchManager.RunningRelease + Vector3.back *
                    (phase == PlayPhase.Delivery ? Mathf.SmoothStep(0f, .81f, t * 3f) : .81f);
                if (phase == PlayPhase.Delivery && t < .34f)
                {
                    bowlPose = releasePose;
                    bowlMoment = 1f + t / .34f;
                }
            }
            bowler.Root.position = position;
            bowler.Act(bowlPose, bowlMoment, snap: bowlPose == releasePose);
            stadium.NearWicket.Animate(bowled ? t : 0f);
            stadium.ShowLandingGuide(match.UpcomingBounce, match.ShowLandingPreview);
            stadium.ShowBall(match.BallPosition, match.BallVisible, contact || phase == PlayPhase.Delivery);
            stadium.ShowShotGuide(match.ContactPosition, match.ShotVelocity, contact && t < .86f, t);
        }

        private static ActorPose StrokePose(Stroke shot)
        {
            switch (shot)
            {
                case Stroke.CoverDrive: return ActorPose.Cover;
                case Stroke.Cut: return ActorPose.Cut;
                case Stroke.OffDrive: return ActorPose.OffDrive;
                case Stroke.Pull: return ActorPose.Pull;
                case Stroke.Flick: return ActorPose.Flick;
                case Stroke.OnDrive: return ActorPose.OnDrive;
                case Stroke.Loft: return ActorPose.Loft;
                default: return ActorPose.Defend;
            }
        }
    }
}
