using UnityEngine;

namespace ColonyCricket
{
    internal sealed class ArenaMatchView
    {
        private readonly Stadium stadium;
        private readonly PlayerCharacter batter, bowler, nonStriker;
        private readonly FieldingView fielders;
        private readonly UmpireView umpires;
        private readonly MatchManager match;
        private readonly LineRenderer evidenceLine;
        private BowlingAim? lastPreview;
        private Vector3 previewLanding;

        public ArenaMatchView(Stadium stadium, ArenaArt art, PlayerCharacter[] roster, MatchManager match,
            int battingSide, int partner)
        {
            this.stadium = stadium;
            this.match = match;
            batter = roster[match.StrikerId];
            bowler = roster[match.BowlerId];
            batter.Root.gameObject.SetActive(true);
            batter.Dress(true);
            bowler.Root.gameObject.SetActive(true);
            bowler.Dress(false);
            umpires = new UmpireView(stadium.Root, art);
            if (match.Competition)
            {
                fielders = new FieldingView(stadium.Root, art, 1 - battingSide);
                nonStriker = roster[partner];
                nonStriker.Root.gameObject.SetActive(true);
                nonStriker.Dress(false);
                evidenceLine = ArenaArt.Node("DRS trajectory", stadium.Root, Vector3.zero).gameObject.AddComponent<LineRenderer>();
                evidenceLine.sharedMaterial = art.Mat("DRS trajectory amber", new Color(1f, .62f, .11f), flat: true);
                evidenceLine.startWidth = .052f;
                evidenceLine.endWidth = .037f;
                evidenceLine.positionCount = 3;
                evidenceLine.enabled = false;
            }
        }

        public void Draw(BowlingAim? previewAim = null)
        {
            if (evidenceLine) evidenceLine.enabled = false;
            PlayPhase phase = match.Phase;
            float t = match.PhaseTime;
            bool reversed = match.ReverseEnd;
            bool contact = phase == PlayPhase.Decision && match.LastShot.MadeContact && match.ShotVelocity.sqrMagnitude > .01f;
            bool bowled = phase == PlayPhase.Decision && match.LastResult.Call == BallCall.Bowled;
            Vector3 position = match.BattingGuard;

            ActorPose pose = ActorPose.Stance;
            float swing = t;
            Vector3? impact = null;
            if (phase == PlayPhase.RunUp || phase == PlayPhase.Delivery)
            {
                pose = ActorPose.Prepare;
                swing = phase == PlayPhase.RunUp ? Mathf.Clamp01(t / match.RunUpDuration) * .46f :
                    Mathf.Lerp(.46f, 1f, match.TimingProgress);
            }
            if (contact && t < .74f)
            {
                pose = StrokePose(match.LastShot.Stroke);
                impact = match.World(match.ContactPosition);
            }
            else if (phase == PlayPhase.Decision && (bowled || match.LastResult.Timing == Timing.Miss) &&
                match.LastResult.Call != BallCall.Wide && t < .45f)
                pose = ActorPose.Miss;

            if (match.ShowingFifty)
            {
                pose = ActorPose.FiftyRaise;
                swing = t - match.FiftyAt;
                impact = null;
            }
            BatterPose(position, phase == PlayPhase.Decision ? match.LastResult : default, reversed, pose, swing,
                match.LastShot.Direction, impact, contact ? match.Fielding : default, t, match.CanMoveGuard ? match.GuardStep : 0f);

            BowlingAim aim = previewAim.HasValue && phase == PlayPhase.Ready ? previewAim.Value : match.Aim;
            bool spin = CharacterDatabase.IsSpin(aim.Type);
            Vector3 release = MatchManager.Crease(aim.Around);
            Vector3 bowlerPosition = release + Vector3.forward * 5.65f;
            ActorPose bowlPose = ActorPose.Idle;
            float bowlMoment = t;
            var releasePose = spin ? ActorPose.SpinRelease : ActorPose.FastRelease;
            if (phase == PlayPhase.RunUp)
            {
                float fraction = Mathf.Clamp01(t / match.RunUpDuration);
                bowlerPosition = Vector3.Lerp(bowlerPosition, release, fraction);
                bowlPose = fraction < .66f ? ActorPose.Run : releasePose;
                bowlMoment = bowlPose == ActorPose.Run ? t : Mathf.InverseLerp(.66f, 1f, fraction);
            }
            else if (phase != PlayPhase.Ready)
            {
                bowlerPosition = release + Vector3.back * (phase == PlayPhase.Delivery ? Mathf.SmoothStep(0f, .81f, t * 3f) : .81f);
                if (phase == PlayPhase.Delivery && t < .34f)
                {
                    bowlPose = releasePose;
                    bowlMoment = 1f + t / .34f;
                }
            }
            SetBowler(bowlerPosition, reversed, bowlPose, bowlMoment);

            SetWickets(reversed, bowled ? t : 0f);
            bool aiming = previewAim.HasValue && phase == PlayPhase.Ready;
            Vector3 landing = match.UpcomingBounce;
            if (aiming)
            {
                if (!lastPreview.HasValue || !lastPreview.Value.Equals(aim))
                {
                    var trajectory = new DeliveryTrajectory(aim, match.ReleaseFor(aim), match.Mission.Difficulty);
                    previewLanding = trajectory.Position(trajectory.TimeAtZ(aim.LandingZ));
                    lastPreview = aim;
                }
                landing = previewLanding;
            }
            stadium.ShowLandingGuide(match.World(landing), aiming || match.ShowLandingPreview);
            stadium.ShowBall(match.World(match.BallPosition), match.BallVisible, contact || phase == PlayPhase.Delivery);
            stadium.ShowShotGuide(match.World(match.ContactPosition), match.World(match.ShotVelocity), contact && t < 1.1f, t);
            fielders?.Draw(match.Fielding, t, contact, match.BallPosition, reversed);
            umpires.Draw(match.LastResult, Mathf.Max(0f, t - match.RevealAt), match.ShowingUmpire, reversed, match.Striker.LeftHanded);
        }

        public void DrawReplay(DeliveryReplay data, ReplayTimeline timeline, float time, bool review)
        {
            float after = time - data.DeliveryTime;
            bool reversed = data.ReverseEnd;
            Vector3 ball = timeline.Ball(time);
            Vector3 position = new Vector3(data.GuardX, 0f, -9.26f);
            bool contact = after >= 0f && data.Struck;
            bool bowled = after >= 0f && data.Result.Call == BallCall.Bowled;
            ActorPose pose = after < 0f ? ActorPose.Prepare : contact && after < .76f ? StrokePose(data.Shot.Stroke) :
                bowled && after < .42f ? ActorPose.Miss : ActorPose.Stance;
            float swing = after < 0f ? Mathf.Lerp(.35f, 1f, Mathf.InverseLerp(0f, data.DeliveryTime, time)) : after;
            Vector3? hit = contact ? MatchManager.World(data.Impact, reversed) : (Vector3?)null;
            BatterPose(position, data.Result, reversed, pose, swing, data.Shot.Direction, hit,
                contact ? data.Fielding : default, Mathf.Max(after, 0f), 0f);
            SetBowler(MatchManager.Crease(data.Aim.Around) + Vector3.back * Mathf.Clamp(time, 0f, .81f), reversed,
                time < .27f ? CharacterDatabase.IsSpin(data.Aim.Type) ? ActorPose.SpinRelease : ActorPose.FastRelease :
                ActorPose.Idle, 1f + time);
            stadium.ShowLandingGuide(Vector3.zero, false);
            stadium.ShowBall(MatchManager.World(ball, reversed), true, false);
            stadium.ShowShotGuide(Vector3.zero, Vector3.zero, false, 0f);
            SetWickets(reversed, bowled ? after : 0f);
            fielders?.Draw(data.Fielding, Mathf.Max(0f, after), contact, ball, reversed);
            umpires.Draw(data.Result, Mathf.Max(after, 0f), after > .22f, reversed, match.Striker.LeftHanded);
            if (!evidenceLine) return;
            evidenceLine.enabled = review && data.Evidence.Kind == Appeal.LegBefore && after >= 0f;
            if (evidenceLine.enabled)
            {
                evidenceLine.SetPosition(0, MatchManager.World(data.Evidence.Bounce, reversed));
                evidenceLine.SetPosition(1, MatchManager.World(data.Evidence.Impact, reversed));
                evidenceLine.SetPosition(2, MatchManager.World(data.Evidence.AtWicket, reversed));
            }
        }

        private void BatterPose(Vector3 guard, DeliveryResult result, bool reversed, ActorPose pose, float elapsed, int direction,
            Vector3? impact, FieldingSimulation.Play fielding, float time, float step)
        {
            bool running = nonStriker != null && pose != ActorPose.FiftyRaise && !result.Wicket && fielding.Collected && result.Runs > 0 && time > .42f;
            float legs = running ? Mathf.Clamp((time - .42f) / 1.60f, 0f, result.Runs) : 0f;
            float travel = Mathf.PingPong(legs, 1f);
            float runZ = Mathf.Lerp(-8.84f, 8.76f, travel);
            float turn = Mathf.FloorToInt(legs) % 2 == 0 ? 0f : 180f;
            float yaw = reversed ? 180f : 0f;
            Vector3 position = running ? new Vector3(-.89f, 0f, runZ) : guard;
            batter.Root.SetPositionAndRotation(MatchManager.World(position, reversed), Quaternion.Euler(0f, yaw + (running ? turn : 0f), 0f));
            batter.Dress(!running);
            batter.Act(running ? ActorPose.Run : pose, elapsed, !running && match.Striker.LeftHanded,
                snap: impact.HasValue && elapsed < .037f,
                contact: impact.HasValue && !running ? batter.Root.InverseTransformPoint(impact.Value) : (Vector3?)null,
                shotDirection: direction, sideStep: step);
            if (nonStriker == null) return;
            Vector3 partner = new Vector3(1.30f, 0f, running ? -runZ : 8.12f);
            nonStriker.Root.SetPositionAndRotation(MatchManager.World(partner, reversed), Quaternion.Euler(0f, yaw + (running ? turn : 0f) + 180f, 0f));
            nonStriker.Act(running ? ActorPose.Run : ActorPose.Idle, elapsed + .19f);
        }

        private void SetWickets(bool reversed, float dismissal)
        {
            stadium.NearWicket.Animate(reversed ? 0f : dismissal);
            stadium.FarWicket.Animate(reversed ? dismissal : 0f);
        }

        private void SetBowler(Vector3 position, bool reversed, ActorPose pose, float moment)
        {
            bowler.Root.SetPositionAndRotation(MatchManager.World(position, reversed), Quaternion.Euler(0f, reversed ? 0f : 180f, 0f));
            bowler.Act(pose, moment, snap: pose == ActorPose.FastRelease || pose == ActorPose.SpinRelease);
        }

        private static ActorPose StrokePose(Stroke shot)
        {
            switch (shot)
            {
                case Stroke.CoverDrive: return ActorPose.Cover;
                case Stroke.Cut: return ActorPose.Cut;
                case Stroke.OffDrive: return ActorPose.OffDrive;
                case Stroke.Pull: return ActorPose.Pull;
                case Stroke.Flick: return ActorPose.Flick;
                case Stroke.OnDrive: return ActorPose.OnDrive;
                case Stroke.Loft: return ActorPose.Loft;
                default: return ActorPose.Defend;
            }
        }
    }
}
