using System;
using UnityEngine;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class ScoreboardController
    {
        private readonly UIManager ui;
        private readonly MatchManager match;
        private readonly Text score, team, overs, target, names, call, timing, umpire, lastResult, aimStatus, deliveryName;
        private readonly RectTransform feedback, bowling, timingMeter, pointer, tutorial, interval, pausePanel;
        private readonly Text tip, intervalLabel;
        private readonly Text[] tokens = new Text[6];
        private int marked;
        private Timing lastTiming;
        private float feedbackAge = 9;
        private bool newBall;
        private readonly SettingsManager settings;

        public ScoreboardController(UIManager ui, MatchManager match, SettingsManager settings,
            Action nextDelivery, Action bowl, Action advance, Action pause, Action resume, Action mainMenu)
        {
            this.ui = ui;
            this.match = match;
            this.settings = settings;
            Transform screen = ui.Safe;
            ui.Graphic(screen, new Rect(0, 0, 1, .255f), "Fade");
            ui.Graphic(screen, new Rect(0, .75f, 1, .25f), "Fade", flipped: true);

            RectTransform board = ui.Panel(screen, new Rect(.037f, .021f, .926f, .168f), UIManager.Ink);
            ui.Panel(board, new Rect(.039f, .09f, .072f, .021f), UIManager.Gold, false);
            ui.Label(board, new Rect(.144f, .038f, .65f, .14f), "CHRISTIAN COLONY CRICKET", 15,
                UIManager.Ivory, alignment: TextAnchor.MiddleLeft);
            ui.Button(board, new Rect(.858f, .065f, .104f, .225f), "II", UIManager.PanelTint, UIManager.Ivory, pause, 20);
            RectTransform scoreboardLine = ui.Panel(board, new Rect(.036f, .328f, .928f, .49f), UIManager.PanelTint);
            team = ui.Label(scoreboardLine, new Rect(.035f, .10f, .29f, .34f), "", 17, UIManager.Muted, alignment: TextAnchor.MiddleLeft);
            score = ui.Label(scoreboardLine, new Rect(.034f, .43f, .34f, .54f), "", 39, UIManager.Ivory, alignment: TextAnchor.MiddleLeft);
            overs = ui.Label(scoreboardLine, new Rect(.371f, .48f, .26f, .40f), "", 16, UIManager.Ivory);
            ui.Label(scoreboardLine, new Rect(.378f, .17f, .24f, .29f), "OVERS", 11, UIManager.Muted);
            target = ui.Label(scoreboardLine, new Rect(.635f, .11f, .33f, .76f), "", 14, UIManager.Gold, alignment: TextAnchor.MiddleRight);
            names = ui.Label(board, new Rect(.046f, .823f, .905f, .155f), "", 13, UIManager.Muted,
                alignment: TextAnchor.MiddleLeft);

            feedback = UIManager.RectNode("Delivery call", screen, new Rect(.097f, .225f, .806f, .175f));
            call = ui.Label(feedback, new Rect(0, .25f, 1, .39f), "", 42, UIManager.Gold);
            timing = ui.Label(feedback, new Rect(.09f, .08f, .82f, .22f), "", 20, UIManager.Ivory);
            umpire = ui.Label(feedback, new Rect(.06f, .65f, .88f, .30f), "", 17, UIManager.Ivory);
            foreach (Text item in new[] { call, timing, umpire })
            {
                Outline outline = item.gameObject.AddComponent<Outline>();
                outline.effectColor = new Color(.018f, .04f, .10f, .92f);
                outline.effectDistance = new Vector2(1.8f, -1.8f);
            }

            RectTransform history = ui.Panel(screen, new Rect(.05f, .931f, .90f, .051f), UIManager.Ink);
            ui.Label(history, new Rect(.031f, .14f, .105f, .72f), "LAST", 10, UIManager.Muted, alignment: TextAnchor.MiddleLeft);
            for (int i = 0; i < tokens.Length; i++)
            {
                RectTransform cell = ui.Panel(history, new Rect(.134f + i * .082f, .19f, .072f, .62f), UIManager.PanelTint);
                tokens[i] = ui.Label(cell, new Rect(0, 0, 1, 1), "·", 15, UIManager.Muted);
            }
            lastResult = ui.Label(history, new Rect(.644f, .10f, .33f, .80f), "", 12, UIManager.Muted, alignment: TextAnchor.MiddleRight);

            timingMeter = ui.Panel(screen, new Rect(.174f, .876f, .652f, .022f), UIManager.Ink);
            ui.Panel(timingMeter, new Rect(.047f, .35f, .90f, .30f), UIManager.PanelTint);
            ui.Panel(timingMeter, new Rect(.78f, .31f, .17f, .38f), UIManager.Gold, false);
            pointer = ui.Panel(timingMeter, new Rect(.01f, .16f, .02f, .68f), UIManager.Ivory, false);

            bowling = ui.Panel(screen, new Rect(.05f, .777f, .90f, .137f), UIManager.Ink);
            aimStatus = ui.Label(bowling, new Rect(.04f, .075f, .92f, .27f), "", 13, UIManager.Muted);
            ui.Button(bowling, new Rect(.054f, .42f, .50f, .49f), "", UIManager.PanelTint, UIManager.Ivory, nextDelivery, out deliveryName, 17);
            ui.Button(bowling, new Rect(.595f, .42f, .346f, .49f), "BOWL", UIManager.Gold, UIManager.Ink, bowl, 19);

            tutorial = ui.Panel(screen, new Rect(.08f, .704f, .84f, .075f), UIManager.Ink);
            tip = ui.Label(tutorial, new Rect(.048f, .11f, .69f, .78f), "", 15, UIManager.Ivory, false, TextAnchor.MiddleLeft);
            ui.Button(tutorial, new Rect(.752f, .22f, .197f, .54f), "SKIP", UIManager.PanelTint, UIManager.Muted, Skip, 13);

            interval = Modal("End of innings");
            ui.Label(interval, new Rect(.06f, .10f, .88f, .16f), "INNINGS BREAK", 33, UIManager.Gold);
            intervalLabel = ui.Label(interval, new Rect(.083f, .32f, .834f, .33f), "", 22, UIManager.Ivory);
            ui.Button(interval, new Rect(.12f, .73f, .76f, .17f), "START BOWLING", UIManager.Gold, UIManager.Ink, advance);
            interval.gameObject.SetActive(false);

            pausePanel = Modal("Match paused");
            ui.Label(pausePanel, new Rect(.08f, .13f, .84f, .21f), "MATCH PAUSED", 34, UIManager.Gold);
            ui.Button(pausePanel, new Rect(.12f, .40f, .76f, .19f), "RESUME MATCH", UIManager.Gold, UIManager.Ink, resume);
            ui.Button(pausePanel, new Rect(.12f, .66f, .76f, .19f), "MAIN MENU", UIManager.PanelTint, UIManager.Ivory, mainMenu);
            pausePanel.gameObject.SetActive(false);

            match.Changed += Refresh;
            match.Decided += ShowResult;
            match.Swing += value => { lastTiming = value.Timing; feedbackAge = 0; newBall = false; };
            Refresh();
        }

        public void Draw(BowlingAim selected, bool paused)
        {
            if (!paused) feedbackAge += Time.deltaTime;
            float x = Mathf.Lerp(.045f, .935f, match.TimingProgress);
            pointer.anchorMin = new Vector2(x, .16f);
            pointer.anchorMax = new Vector2(x + .021f, .84f);
            timingMeter.gameObject.SetActive(match.HumanBatting && match.Phase == PlayPhase.Delivery && !paused);
            bowling.gameObject.SetActive(!match.HumanBatting && match.Phase == PlayPhase.Ready && !paused);
            if (bowling.gameObject.activeSelf)
            {
                string line = selected.Line < -.23f ? "LEFT LINE" : selected.Line > .23f ? "RIGHT LINE" : "ON STUMPS";
                string length = selected.LandingZ < -6.74f ? "FULL" : selected.LandingZ < -3.35f ? "GOOD LENGTH" : "SHORT";
                aimStatus.color = selected.Overstep ? UIManager.Red : UIManager.Muted;
                UIManager.SetText(aimStatus, selected.Overstep ? "OVERSTEP  ·  EASE BACK FOR A LEGAL BALL" : line + "  ·  " + length);
                UIManager.SetText(deliveryName, CharacterDatabase.DeliveryName(selected.Type).ToUpperInvariant() + "  ›");
            }

            bool showTip = !settings.TutorialSeen && !paused && match.Phase != PlayPhase.Interval &&
                (match.HumanBatting ? match.Rules.Current.LegalBalls <= 4 : match.Rules.Current.LegalBalls <= 3 && match.Phase == PlayPhase.Ready);
            tutorial.gameObject.SetActive(showTip);
            if (showTip)
                UIManager.SetText(tip, !match.HumanBatting ? "Drag on the pitch to aim. Release to bowl." :
                    match.Rules.Current.LegalBalls < 2 ? "Swipe left for off-side. Swipe right for leg-side." :
                    "Finish the swipe as the ball reaches the bat. Swipe farther for power.");
            bool showTiming = match.HumanBatting && !newBall && feedbackAge < 1.16f && !paused;
            UIManager.SetText(timing, showTiming ? ShotTimingSystem.Label(lastTiming) : "");
            timing.color = lastTiming == Timing.Perfect ? UIManager.Gold : lastTiming == Timing.Miss ? UIManager.Red : UIManager.Ivory;
            feedback.localScale = Vector3.one * (showTiming ? 1f + .20f * Mathf.Sin(Mathf.Min(1, feedbackAge * 5f) * Mathf.PI) : 1f);
            feedback.gameObject.SetActive(!paused && (showTiming || match.Phase == PlayPhase.Decision));
            pausePanel.gameObject.SetActive(paused);
            interval.gameObject.SetActive(!paused && match.Phase == PlayPhase.Interval);
        }

        private RectTransform Modal(string name)
        {
            RectTransform rect = ui.Panel(ui.Safe, new Rect(.065f, .31f, .87f, .36f), UIManager.Ink);
            rect.gameObject.name = name;
            ui.Panel(rect, new Rect(.10f, .06f, .80f, .010f), UIManager.Gold, false);
            return rect;
        }

        private void Refresh()
        {
            CricketRulesEngine engine = match.Rules;
            InningsScore current = engine.Current;
            bool decision = match.Phase == PlayPhase.Decision;
            if (match.Phase == PlayPhase.Ready)
            {
                newBall = true;
                call.text = "";
                umpire.text = "";
                if (current.LegalBalls == 0 && current.Extras == 0)
                {
                    foreach (Text cell in tokens) { cell.text = "·"; cell.color = UIManager.Muted; }
                    marked = 0;
                }
            }
            score.text = current.Runs + "/" + current.Wickets;
            team.text = engine.Innings == 0 ? "COLONY BLUE" : "COLONY GOLD";
            team.color = engine.Innings == 0 ? UIManager.Blue : UIManager.Gold;
            overs.text = current.Overs + " / " + engine.OversPerInnings + ".0";
            target.text = engine.Innings == 0 ? "1ST INNINGS" : "TARGET  " + engine.Target + "\nNEED " + engine.Required + " FROM " + engine.RemainingBalls;
            names.text = (decision ? match.BatsmanAtDecision : match.Striker.Name) + "  ·  batting     " +
                (decision ? match.BowlerAtDecision : match.Bowler.Name) + "  ·  bowling";
            if (match.Phase == PlayPhase.Interval)
                intervalLabel.text = "Blue " + current.Runs + "/" + current.Wickets + "  •  " + current.Overs + " overs\n\nGold needs " +
                    (current.Runs + 1) + " to win.";
        }

        private void ShowResult(DeliveryResult result)
        {
            string label;
            string symbol;
            if (result.Dismissal != Dismissal.None)
            {
                label = "WICKET!";
                symbol = "W";
            }
            else if (result.Boundary != 0)
            {
                label = result.Boundary == 6 ? "MASSIVE SIX!" : "FOUR!";
                symbol = result.Total.ToString();
            }
            else if (result.Extra != Extra.None)
            {
                label = result.Extra == Extra.Wide ? "WIDE" : "NO BALL";
                symbol = result.Extra == Extra.Wide ? "Wd" : "Nb";
            }
            else
            {
                label = result.RunningRuns == 0 ? "DOT BALL" : result.RunningRuns == 1 ? "1 RUN" : result.RunningRuns + " RUNS";
                symbol = result.RunningRuns.ToString();
            }

            call.text = label;
            call.color = result.Dismissal != Dismissal.None ? UIManager.Red : result.Boundary > 0 ? UIManager.Gold : UIManager.Ivory;
            string official = UmpireController.Decision(result);
            string detail = result.Dismissal == Dismissal.None ? "" : match.DismissedName + "  ·  " +
                (result.Dismissal == Dismissal.RunOut ? "Run out" : result.Dismissal.ToString()) +
                (result.Dismissal == Dismissal.RunOut ? "" : "  ·  " + match.BowlerAtDecision) + "\n";
            umpire.text = detail + official;
            if (marked >= tokens.Length)
            {
                for (int i = 0; i < tokens.Length - 1; i++)
                {
                    tokens[i].text = tokens[i + 1].text;
                    tokens[i].color = tokens[i + 1].color;
                }
                marked = tokens.Length - 1;
            }
            tokens[marked].text = symbol;
            tokens[marked].color = call.color;
            marked++;
            lastResult.text = label;
        }

        private void Skip()
        {
            settings.TutorialSeen = true;
            settings.Save();
        }
    }
}
