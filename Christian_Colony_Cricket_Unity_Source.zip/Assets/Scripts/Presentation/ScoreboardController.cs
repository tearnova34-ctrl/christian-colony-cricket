using System;
using UnityEngine;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class ScoreboardController
    {
        private static readonly Color Mint = new Color(.47f, .98f, .83f);
        private readonly MatchManager round;
        private readonly MatchSession session;
        private readonly Func<BowlingAim> selectedDelivery;
        private readonly Text total, balls, target, instructions, verdict, timing, direction, deliveryType, creaseText, umpire, batterLine, bowlerLine, overHeader, fiftyText;
        private readonly RectTransform meter, cursor, outcome, pausePanel, guardLeft, guardRight, bowlControls, releaseButton, replayButton, reviewButton, pausedReplay, fiftyCard;
        private readonly RawImage fourArt, sixArt, wicketArt, officialArt;

        public ScoreboardController(UIManager ui, MatchManager round, MatchSession session, Action pause, Action resume,
            Action menu, Action cycle, Action crease, Action bowl, Action release, Action replay, Action review, Action scorecard, Func<BowlingAim> selectedDelivery)
        {
            this.round = round;
            this.session = session;
            this.selectedDelivery = selectedDelivery;
            Transform root = ui.Safe;
            ui.Graphic(root, new Rect(0, 0, 1, .184f), "Fade");

            RectTransform board = ui.Card(root, new Rect(.038f, .022f, .924f, .159f), Palette.India);
            ui.Panel(board, new Rect(.04f, .135f, .012f, .359f), Mint, false);
            string batter = round.Striker.Name.ToUpperInvariant();
            ui.Label(board, new Rect(.075f, .062f, .40f, .172f), session.Competition
                ? MatchSession.Team(session.BattingTeam) : "QUICK MATCH", 15, Mint, alignment: TextAnchor.MiddleLeft);
            total = ui.Label(board, new Rect(.068f, .228f, .315f, .295f), "", 39, UIManager.Ivory,
                alignment: TextAnchor.MiddleLeft);
            target = ui.Label(board, new Rect(.368f, .081f, .426f, .25f), "", 18, UIManager.Gold,
                alignment: TextAnchor.MiddleRight);
            balls = ui.Label(board, new Rect(.357f, .357f, .44f, .163f), "", 13, UIManager.Ivory,
                alignment: TextAnchor.MiddleRight);
            ui.Button(board, new Rect(.832f, .086f, .124f, .20f), "Ⅱ", UIManager.PanelTint, UIManager.Ivory, pause, 19);
            ui.Button(board, new Rect(.832f, .326f, .124f, .195f), "STATS", UIManager.PanelTint, UIManager.Gold, scorecard, 11);
            ui.Panel(board, new Rect(.05f, .548f, .90f, .006f), new Color(.5f, .69f, .97f, .49f), false);

            ui.Graphic(board, new Rect(.055f, .612f, .097f, .287f), "AvatarBatter", fitted: true);
            ui.Graphic(board, new Rect(.512f, .612f, .097f, .287f), "AvatarBowler", fitted: true);
            ui.Label(board, new Rect(.163f, .595f, .33f, .159f), batter, 13, UIManager.Gold, alignment: TextAnchor.MiddleLeft);
            ui.Label(board, new Rect(.619f, .595f, .33f, .159f), round.Bowler.Name.ToUpperInvariant(), 13, UIManager.Gold,
                alignment: TextAnchor.MiddleLeft);
            batterLine = ui.Label(board, new Rect(.163f, .764f, .33f, .155f), "", 12, UIManager.Ivory, alignment: TextAnchor.MiddleLeft);
            bowlerLine = ui.Label(board, new Rect(.619f, .764f, .34f, .155f), "", 12, UIManager.Ivory, alignment: TextAnchor.MiddleLeft);
            overHeader = ui.Label(root, new Rect(.16f, .186f, .68f, .041f), "", 14, UIManager.Ivory);

            outcome = ui.Card(root, new Rect(.151f, .690f, .698f, .163f), Palette.Australia);
            timing = ui.Label(outcome, new Rect(.048f, .070f, .904f, .19f), "", 16, Mint);
            verdict = ui.Label(outcome, new Rect(.045f, .257f, .91f, .47f), "", 44, UIManager.Ivory);
            fourArt = ui.Graphic(outcome, new Rect(.07f, .244f, .86f, .47f), "AvatarFour", fitted: true);
            sixArt = ui.Graphic(outcome, new Rect(.05f, .244f, .90f, .47f), "AvatarSix", fitted: true);
            wicketArt = ui.Graphic(outcome, new Rect(.07f, .244f, .86f, .47f), "AvatarWicket", fitted: true);
            direction = ui.Label(outcome, new Rect(.065f, .742f, .87f, .207f), "", 16, UIManager.Gold);
            outcome.gameObject.SetActive(false);
            umpire = ui.Label(root, new Rect(.215f, .619f, .62f, .045f), "", 15, UIManager.Ivory);
            officialArt = ui.Graphic(root, new Rect(.125f, .598f, .107f, .075f), "AvatarKosar", fitted: true);

            fiftyCard = ui.Card(root, new Rect(.116f, .681f, .768f, .169f), Palette.Australia);
            ui.Graphic(fiftyCard, new Rect(.042f, -.047f, .22f, 1.02f), "AvatarCrowd", fitted: true);
            ui.Label(fiftyCard, new Rect(.29f, .106f, .67f, .39f), "HALF-CENTURY", 25, UIManager.Gold);
            fiftyText = ui.Label(fiftyCard, new Rect(.29f, .559f, .67f, .25f), "", 18, UIManager.Ivory);
            fiftyCard.gameObject.SetActive(false);

            replayButton = (RectTransform)ui.Button(root, new Rect(.067f, .877f, .42f, .080f), "REPLAY",
                UIManager.PanelTint, UIManager.Ivory, replay, 17).transform;
            reviewButton = (RectTransform)ui.Button(root, new Rect(.516f, .877f, .415f, .080f), "REVIEW",
                UIManager.Gold, UIManager.Ink, review, 17).transform;
            replayButton.SetAsLastSibling();
            reviewButton.SetAsLastSibling();

            RectTransform controls = ui.Panel(root, new Rect(.06f, .881f, .88f, .089f), UIManager.Ink);
            instructions = ui.Label(controls, new Rect(.18f, .13f, .64f, .74f), "", 15, UIManager.Ivory);
            bowlControls = UIManager.RectNode("Bowling controls", controls, new Rect(0f, 0f, 1f, 1f));
            ui.Label(bowlControls, new Rect(.045f, .050f, .91f, .24f), "DRAG ON PITCH TO AIM", 13, UIManager.Muted);
            ui.Button(bowlControls, new Rect(.025f, .37f, .30f, .51f), "", UIManager.PanelTint, UIManager.Ivory, cycle,
                out deliveryType, 17);
            ui.Button(bowlControls, new Rect(.345f, .37f, .288f, .51f), "", UIManager.PanelTint, UIManager.Ivory,
                crease, out creaseText, 15);
            ui.Button(bowlControls, new Rect(.651f, .37f, .323f, .51f), "RUN-UP", Mint, UIManager.Ink, bowl, 20);
            releaseButton = (RectTransform)ui.Button(controls, new Rect(.1f, .18f, .8f, .64f), "TAP TO RELEASE",
                UIManager.Gold, UIManager.Ink, release, 22).transform;
            replayButton.SetAsLastSibling();
            reviewButton.SetAsLastSibling();
            bowlControls.gameObject.SetActive(false);
            guardLeft = (RectTransform)ui.Button(controls, new Rect(.041f, .16f, .138f, .68f), "←",
                UIManager.PanelTint, Mint, () => round.MoveGuard(-1), 26).transform;
            guardRight = (RectTransform)ui.Button(controls, new Rect(.821f, .16f, .138f, .68f), "→",
                UIManager.PanelTint, Mint, () => round.MoveGuard(1), 26).transform;

            meter = ui.Panel(root, new Rect(.025f, .227f, .106f, .322f), UIManager.Ink);
            ui.Label(meter, new Rect(.025f, .038f, .95f, .073f), round.UserBowls ? "BOWL" : "LATE", 11, UIManager.Ivory);
            ui.Label(meter, new Rect(.025f, .892f, .95f, .066f), "EARLY", 11, UIManager.Ivory);
            RectTransform rail = UIManager.RectNode("Shot timing", meter, new Rect(.32f, .138f, .36f, .724f));
            ui.Panel(rail, new Rect(0, 0, 1, 1), UIManager.Red, false);
            if (round.UserBowls)
            {
                ui.Panel(rail, new Rect(0f, .04f, 1f, .36f), UIManager.Gold, false);
                ui.Panel(rail, new Rect(0f, .21f - round.PerfectWindow, 1f, 2f * round.PerfectWindow), Mint, false);
                ui.Panel(rail, new Rect(0f, .205f, 1f, .01f), UIManager.Ivory, false);
            }
            else
            {
                AddBand(ui, rail, ShotTimingSystem.MishitLimit, new Color(1f, .51f, .23f));
                AddBand(ui, rail, ShotTimingSystem.ContactLimit, UIManager.Gold);
                AddBand(ui, rail, ShotTimingSystem.GoodLimit, new Color(.70f, .93f, .43f));
                AddBand(ui, rail, ShotTimingSystem.PerfectLimit, Mint);
            }
            cursor = ui.Panel(rail, new Rect(-.37f, .49f, 1.74f, .025f), UIManager.Ivory, false);
            cursor.offsetMin = Vector2.zero;
            cursor.offsetMax = Vector2.zero;
            meter.gameObject.SetActive(false);

            RectTransform pauseCard = ui.Modal("Pause", .354f, Palette.Pakistan, out pausePanel);
            ui.Label(pauseCard, new Rect(.08f, .08f, .84f, .25f), "PAUSED", 37, UIManager.Ivory);
            ui.Button(pauseCard, new Rect(.10f, .303f, .80f, .165f), "RESUME", Mint, UIManager.Ink, resume);
            pausedReplay = (RectTransform)ui.Button(pauseCard, new Rect(.10f, .526f, .80f, .157f),
                "REPLAY LAST BALL", UIManager.PanelTint, UIManager.Ivory, replay).transform;
            ui.Button(pauseCard, new Rect(.10f, .744f, .80f, .161f), "SAVE & MAIN MENU", UIManager.PanelTint, UIManager.Ivory, menu);
            pausePanel.gameObject.SetActive(false);

            round.Decided += ShowOutcome;
            RefreshScore();
            if (round.Phase == PlayPhase.Decision) ShowOutcome(round.LastResult);
        }

        private static void AddBand(UIManager ui, Transform rail, float limit, Color color)
        {
            float edge = ShotTimingSystem.MeterPosition(-limit);
            ui.Panel(rail, new Rect(0f, edge, 1f, 1f - 2f * edge), color, false);
        }

        public void Draw(bool paused, bool interval, bool playingReplay)
        {
            bool delivering = round.Phase == PlayPhase.Delivery;
            bool deciding = round.Phase == PlayPhase.Decision;
            bool free = !paused && !interval && !playingReplay;
            bool reveal = deciding && free && round.PhaseTime >= round.RevealAt;
            bool runUp = round.UserBowls && round.Phase == PlayPhase.RunUp;
            pausePanel.gameObject.SetActive(paused && !playingReplay);
            pausedReplay.gameObject.SetActive(round.LastReplay != null);
            bool fifty = free && round.ShowingFifty;
            outcome.gameObject.SetActive(reveal && !fifty);
            umpire.gameObject.SetActive(reveal && round.ShowingUmpire && umpire.text.Length > 0);
            officialArt.gameObject.SetActive(reveal && round.ShowingUmpire);
            fiftyCard.gameObject.SetActive(fifty);
            if (fifty) UIManager.SetText(fiftyText, round.Striker.Name.ToUpperInvariant() + "  ·  " + round.Scorecard.BatRuns +
                " (" + round.Scorecard.BallsFaced + ")");
            if (free && round.Phase == PlayPhase.Ready && round.Rules.Balls != shownBalls) { RefreshScore(); shownBalls = round.Rules.Balls; }
            bool change = free && round.Competition && round.Rules.Balls > 0 && round.Rules.Balls % 6 == 0 &&
                (round.Phase == PlayPhase.Ready && round.PhaseTime < 2.2f ||
                round.Phase == PlayPhase.RunUp && round.PhaseTime < .7f);
            UIManager.SetText(overHeader, change ? "OVER " + (round.OverIndex + 1) + "  ·  ENDS SWITCHED" : "");
            bool showMeter = free && (round.UserBowls ? runUp || delivering :
                delivering || deciding && round.ShotMeterMark.HasValue);
            meter.gameObject.SetActive(showMeter);
            guardLeft.gameObject.SetActive(round.CanMoveGuard && free);
            guardRight.gameObject.SetActive(round.CanMoveGuard && free);
            bool aiming = round.UserBowls && round.Phase == PlayPhase.Ready;
            bool release = runUp && !round.ReleaseLocked;
            releaseButton.gameObject.SetActive(release && free);
            bowlControls.gameObject.SetActive(aiming && free);
            instructions.gameObject.SetActive(free && !aiming && !release && !reveal);
            replayButton.gameObject.SetActive(reveal && round.LastReplay != null);
            reviewButton.gameObject.SetActive(reveal && round.CanReview);
            if (aiming)
            {
                BowlingAim aim = selectedDelivery();
                UIManager.SetText(deliveryType, CharacterDatabase.DeliveryName(aim.Type).ToUpperInvariant() + " ↻");
                UIManager.SetText(creaseText, aim.Around ? "AROUND ↻" : "OVER ↻");
            }
            else UIManager.SetText(instructions, round.UserBowls ? round.ReleaseLocked ? round.ReleaseGrade :
                round.Bowler.Name.ToUpperInvariant() : round.CanMoveGuard ? "MOVE ON THE CREASE" :
                "SWIPE LEFT / RIGHT   •   TAP FOR STRAIGHT");
            if (showMeter)
            {
                float y = round.UserBowls ? round.ReleaseCursor : round.ShotMeterMark ?? round.TimingGuideProgress;
                cursor.anchorMin = new Vector2(-.37f, y - .013f);
                cursor.anchorMax = new Vector2(1.37f, y + .013f);
            }
            if (reveal)
            {
                if (!scoreRevealed) { RefreshScore(); scoreRevealed = true; }
                float u = Mathf.SmoothStep(0f, 1f, (round.PhaseTime - round.RevealAt) * 13f);
                outcome.localScale = Vector3.one * Mathf.Lerp(.94f, 1f, u);
            }
            else scoreRevealed = false;
        }

        private bool scoreRevealed;
        private int shownBalls = -1;

        private void ShowOutcome(DeliveryResult result)
        {
            if (round.PhaseTime >= round.RevealAt) RefreshScore();
            scoreRevealed = false;
            verdict.text = result.OutcomeLabel;
            verdict.gameObject.SetActive(!result.RequiresSignal);
            fourArt.gameObject.SetActive(result.Runs == 4);
            sixArt.gameObject.SetActive(result.Runs == 6);
            wicketArt.gameObject.SetActive(result.Wicket);
            Color color = result.Wicket ? UIManager.Red : result.Runs >= 4 ? Mint : UIManager.Ivory;
            verdict.color = color;
            timing.text = round.UserBowls ? round.ReleaseGrade : result.Call == BallCall.Wide ? "" : ShotTimingSystem.Label(result.Timing);
            timing.color = result.Timing == Timing.Perfect ? Mint : UIManager.Muted;
            float screenX = round.ShotVelocity.x * (round.UserBowls ? -1f : 1f);
            string arrow = result.Zone == ShotZone.Straight ? "↑" : screenX < 0f ? "←" : "→";
            direction.text = string.IsNullOrEmpty(result.DirectionLabel) ? result.Wicket ? result.OutcomeLabel : "" :
                arrow + " " + result.DirectionLabel + "  ·  " + result.ShotDistance.ToString("0.0") + " M";
            umpire.text = result.Wicket ? "KOSAR PARVEEN  —  OUT" : result.Runs == 6 ? "KOSAR PARVEEN  —  SIX" :
                result.Runs == 4 ? "KOSAR PARVEEN  —  FOUR" : "";
        }

        private void RefreshScore()
        {
            total.text = round.Rules.Runs + "/" + round.Rules.Wickets;
            OverFigure line = round.Scorecard.At(round.OverIndex);
            batterLine.text = round.Scorecard.BatRuns + " (" + round.Scorecard.BallsFaced + ")   ·   +" + line.BatRuns;
            bowlerLine.text = line.Wickets + " W  ·  " + line.BowlerRuns + " R  (OV " + (round.OverIndex + 1) + ")";
            target.text = round.Rules.Target == 0 ? "1ST INNINGS" : "TARGET " + round.Rules.Target;
            int remainingBalls = round.Rules.BallLimit - round.Rules.Balls;
            string overs = (round.Rules.Balls / 6) + "." + (round.Rules.Balls % 6) + " / " + session.Overs + " OV";
            balls.text = round.Rules.Target == 0 ? overs : round.Rules.Won ? "TARGET REACHED" :
                "NEED " + round.Rules.Remaining + "  ·  " + remainingBalls + " BALLS";
        }
    }
}
