using System;
using UnityEngine;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class ScoreboardController
    {
        private static readonly Color Mint = new Color(.47f, .98f, .83f);
        private readonly MatchManager round;
        private readonly Text total, balls, target, instructions, verdict, timing, direction;
        private readonly RectTransform meter, cursor, outcome, pausePanel, guardLeft, guardRight;

        public ScoreboardController(UIManager ui, MatchManager round, Action pause, Action resume, Action menu)
        {
            this.round = round;
            Transform root = ui.Safe;
            ui.Graphic(root, new Rect(0, 0, 1, .184f), "Fade");

            RectTransform board = ui.Panel(root, new Rect(.042f, .025f, .916f, .106f), UIManager.Ink);
            ui.Panel(board, new Rect(.04f, .16f, .012f, .67f), Mint, false);
            ui.Label(board, new Rect(.075f, .106f, .44f, .23f), round.Striker.Name.ToUpperInvariant(),
                16, Mint, alignment: TextAnchor.MiddleLeft);
            total = ui.Label(board, new Rect(.068f, .33f, .37f, .55f), "", 48, UIManager.Ivory,
                alignment: TextAnchor.MiddleLeft);
            target = ui.Label(board, new Rect(.391f, .151f, .396f, .35f), "", 19, UIManager.Gold,
                alignment: TextAnchor.MiddleRight);
            balls = ui.Label(board, new Rect(.328f, .523f, .460f, .31f), "", 14, UIManager.Ivory,
                alignment: TextAnchor.MiddleRight);
            ui.Button(board, new Rect(.822f, .265f, .132f, .50f), "Ⅱ", UIManager.PanelTint, UIManager.Ivory, pause, 22);

            outcome = ui.Panel(root, new Rect(.19f, .716f, .62f, .132f), UIManager.Ink);
            timing = ui.Label(outcome, new Rect(.048f, .070f, .904f, .19f), "", 16, Mint);
            verdict = ui.Label(outcome, new Rect(.045f, .257f, .91f, .47f), "", 44, UIManager.Ivory);
            direction = ui.Label(outcome, new Rect(.065f, .742f, .87f, .207f), "", 16, UIManager.Gold);
            outcome.gameObject.SetActive(false);

            RectTransform controls = ui.Panel(root, new Rect(.06f, .881f, .88f, .089f), UIManager.Ink);
            instructions = ui.Label(controls, new Rect(.18f, .13f, .64f, .74f), "", 15, UIManager.Ivory);
            guardLeft = (RectTransform)ui.Button(controls, new Rect(.041f, .16f, .138f, .68f), "←",
                UIManager.PanelTint, Mint, () => round.MoveGuard(-1), 26).transform;
            guardRight = (RectTransform)ui.Button(controls, new Rect(.821f, .16f, .138f, .68f), "→",
                UIManager.PanelTint, Mint, () => round.MoveGuard(1), 26).transform;

            meter = ui.Panel(root, new Rect(.028f, .294f, .118f, .389f), UIManager.Ink);
            ui.Label(meter, new Rect(.025f, .043f, .95f, .066f), "LATE", 11, UIManager.Ivory);
            ui.Label(meter, new Rect(.025f, .892f, .95f, .066f), "EARLY", 11, UIManager.Ivory);
            RectTransform rail = UIManager.RectNode("Shot timing", meter, new Rect(.32f, .138f, .36f, .724f));
            ui.Panel(rail, new Rect(0, 0, 1, 1), UIManager.Red, false);
            AddBand(ui, rail, ShotTimingSystem.MishitLimit, new Color(1f, .51f, .23f));
            AddBand(ui, rail, ShotTimingSystem.ContactLimit, UIManager.Gold);
            AddBand(ui, rail, ShotTimingSystem.GoodLimit, new Color(.70f, .93f, .43f));
            AddBand(ui, rail, ShotTimingSystem.PerfectLimit, Mint);
            cursor = ui.Panel(rail, new Rect(-.37f, .49f, 1.74f, .025f), UIManager.Ivory, false);
            cursor.offsetMin = Vector2.zero;
            cursor.offsetMax = Vector2.zero;
            meter.gameObject.SetActive(false);

            pausePanel = ui.Panel(root, new Rect(.075f, .36f, .85f, .27f), UIManager.Ink);
            ui.Label(pausePanel, new Rect(.08f, .08f, .84f, .25f), "PAUSED", 37, UIManager.Ivory);
            ui.Button(pausePanel, new Rect(.10f, .39f, .80f, .22f), "RESUME", Mint, UIManager.Ink, resume);
            ui.Button(pausePanel, new Rect(.10f, .68f, .80f, .22f), "MAIN MENU", UIManager.PanelTint, UIManager.Ivory, menu);
            pausePanel.gameObject.SetActive(false);

            round.Decided += ShowOutcome;
            RefreshScore();
            if (round.Phase == PlayPhase.Decision) ShowOutcome(round.LastResult);
        }

        private static void AddBand(UIManager ui, Transform rail, float limit, Color color)
        {
            float edge = ShotTimingSystem.MeterPosition(-limit);
            ui.Panel(rail, new Rect(0f, edge, 1f, 1f - 2f * edge), color, false);
        }

        public void Draw(bool paused)
        {
            bool delivery = round.Phase == PlayPhase.Delivery;
            bool deciding = round.Phase == PlayPhase.Decision;
            pausePanel.gameObject.SetActive(paused);
            outcome.gameObject.SetActive(deciding && !paused);
            bool showMeter = !paused && (delivery || deciding && round.ShotMeterMark.HasValue);
            meter.gameObject.SetActive(showMeter);
            guardLeft.gameObject.SetActive(round.CanMoveGuard && !paused);
            guardRight.gameObject.SetActive(round.CanMoveGuard && !paused);
            UIManager.SetText(instructions, round.CanMoveGuard ? "MOVE ON THE CREASE"
                : "SWIPE LEFT / RIGHT   •   TAP FOR STRAIGHT");
            if (showMeter)
            {
                float y = round.ShotMeterMark ?? round.TimingGuideProgress;
                cursor.anchorMin = new Vector2(-.37f, y - .013f);
                cursor.anchorMax = new Vector2(1.37f, y + .013f);
            }
            if (deciding)
            {
                float u = Mathf.SmoothStep(0f, 1f, round.PhaseTime * 13f);
                outcome.localScale = Vector3.one * Mathf.Lerp(.94f, 1f, u);
            }
        }

        private void ShowOutcome(DeliveryResult result)
        {
            RefreshScore();
            verdict.text = result.OutcomeLabel;
            Color color = result.Call == BallCall.Bowled ? UIManager.Red : result.Runs >= 4 ? Mint : UIManager.Ivory;
            verdict.color = color;
            timing.text = result.Call == BallCall.Wide ? "" : ShotTimingSystem.Label(result.Timing);
            timing.color = result.Timing == Timing.Perfect ? Mint : UIManager.Muted;
            string arrow = result.Zone == ShotZone.Straight ? "↑" : round.ShotVelocity.x < 0f ? "←" : "→";
            direction.text = string.IsNullOrEmpty(result.DirectionLabel) ? "" : arrow + "  " + result.DirectionLabel;
        }

        private void RefreshScore()
        {
            total.text = round.Rules.Runs + "/" + round.Rules.Wickets;
            target.text = "TARGET " + round.Rules.Target;
            int remainingBalls = round.Rules.BallLimit - round.Rules.Balls;
            balls.text = round.Rules.Won ? "TARGET REACHED" : "NEED " + round.Rules.Remaining + "  ·  " + remainingBalls + " BALLS";
        }
    }
}
