using System;
using UnityEngine;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class ScoreboardController
    {
        private readonly UIManager ui;
        private readonly MatchManager match;
        private readonly Text score, team, overs, target, chase, batter, bowler, partner, bowlingFigures;
        private readonly Text call, timing, umpire, aimStatus, deliveryName, status, commentary;
        private readonly RectTransform feedback, bowling, timingMeter, pointer, tutorial, interval, pausePanel;
        private readonly RectTransform commentaryStrip, progress, teamAccent;
        private readonly Text tip, intervalLabel;
        private readonly Text[] tokens = new Text[6];
        private readonly Image[] tokenTiles = new Image[6];
        private int marked;
        private Timing lastTiming;
        private float feedbackAge = 9;
        private bool newBall;
        private readonly SettingsManager settings;

        public ScoreboardController(UIManager ui, MatchManager match, SettingsManager settings,
            Action nextDelivery, Action bowl, Action advance, Action pause, Action resume, Action mainMenu)
        {
            this.ui = ui;
            this.match = match;
            this.settings = settings;
            Transform screen = ui.Safe;
            ui.Graphic(screen, new Rect(0, 0, 1, .205f), "Fade");
            ui.Graphic(screen, new Rect(0, .772f, 1, .228f), "Fade", flipped: true);

            RectTransform board = ui.Panel(screen, new Rect(.034f, .015f, .932f, .156f), UIManager.Ink);
            teamAccent = ui.Panel(board, new Rect(.022f, .091f, .009f, .818f), UIManager.Blue, false);
            ui.Label(board, new Rect(.049f, .045f, .77f, .157f), "CHRISTIAN COLONY CRICKET", 14,
                UIManager.Ivory, alignment: TextAnchor.MiddleLeft);
            ui.Button(board, new Rect(.858f, .037f, .100f, .219f), "Ⅱ", UIManager.PanelTint, UIManager.Ivory, pause, 21);
            team = ui.Label(board, new Rect(.053f, .24f, .38f, .15f), "", 13, UIManager.Blue,
                alignment: TextAnchor.MiddleLeft);
            score = ui.Label(board, new Rect(.047f, .363f, .36f, .37f), "", 43, UIManager.Ivory,
                alignment: TextAnchor.MiddleLeft);

            RectTransform overTile = ui.Panel(board, new Rect(.387f, .286f, .228f, .407f), UIManager.PanelTint);
            ui.Label(overTile, new Rect(.04f, .115f, .92f, .29f), "OVERS", 11, UIManager.Muted);
            overs = ui.Label(overTile, new Rect(.04f, .40f, .92f, .48f), "", 16, UIManager.Ivory);
            RectTransform targetTile = ui.Panel(board, new Rect(.637f, .286f, .321f, .407f), UIManager.PanelTint);
            target = ui.Label(targetTile, new Rect(.075f, .091f, .85f, .36f), "", 12, UIManager.Muted);
            chase = ui.Label(targetTile, new Rect(.058f, .468f, .884f, .38f), "", 17, UIManager.Gold);
            RectTransform progressTrack = ui.Panel(board, new Rect(.050f, .745f, .901f, .020f), UIManager.PanelTint, false);
            progress = ui.Panel(progressTrack, new Rect(0, 0, 0, 1), UIManager.Blue, false);
            status = ui.Label(board, new Rect(.051f, .799f, .899f, .142f), "", 12, UIManager.Muted, false,
                TextAnchor.MiddleLeft);

            feedback = UIManager.RectNode("Delivery call", screen, new Rect(.085f, .184f, .83f, .135f));
            call = ui.Label(feedback, new Rect(0, .27f, 1, .40f), "", 42, UIManager.Gold);
            timing = ui.Label(feedback, new Rect(.09f, .03f, .82f, .26f), "", 20, UIManager.Ivory);
            umpire = ui.Label(feedback, new Rect(.06f, .68f, .88f, .30f), "", 17, UIManager.Ivory);
            foreach (Text item in new[] { call, timing, umpire })
            {
                Outline outline = item.gameObject.AddComponent<Outline>();
                outline.effectColor = new Color(.018f, .04f, .10f, .92f);
                outline.effectDistance = new Vector2(1.8f, -1.8f);
            }

            RectTransform players = ui.Panel(screen, new Rect(.035f, .867f, .93f, .070f), UIManager.Ink);
            ui.Panel(players, new Rect(.502f, .15f, .003f, .70f), UIManager.PanelTint, false);
            batter = ui.Label(players, new Rect(.040f, .13f, .440f, .40f), "", 18, UIManager.Ivory, alignment: TextAnchor.MiddleLeft);
            bowler = ui.Label(players, new Rect(.523f, .13f, .432f, .40f), "", 18, UIManager.Ivory, alignment: TextAnchor.MiddleRight);
            partner = ui.Label(players, new Rect(.040f, .537f, .44f, .29f), "", 11, UIManager.Muted, alignment: TextAnchor.MiddleLeft);
            bowlingFigures = ui.Label(players, new Rect(.526f, .537f, .43f, .29f), "", 11, UIManager.Muted, alignment: TextAnchor.MiddleRight);

            RectTransform history = ui.Panel(screen, new Rect(.035f, .946f, .93f, .039f), UIManager.Ink);
            ui.Label(history, new Rect(.037f, .10f, .206f, .80f), "LAST 6 BALLS", 10, UIManager.Muted, alignment: TextAnchor.MiddleLeft);
            for (int i = 0; i < tokens.Length; i++)
            {
                RectTransform cell = ui.Panel(history, new Rect(.271f + i * .112f, .14f, .091f, .72f), UIManager.PanelTint);
                tokenTiles[i] = cell.GetComponent<Image>();
                tokens[i] = ui.Label(cell, new Rect(0, 0, 1, 1), "·", 15, UIManager.Muted);
            }

            commentaryStrip = ui.Panel(screen, new Rect(.074f, .783f, .852f, .042f), UIManager.Ink);
            commentary = ui.Label(commentaryStrip, new Rect(.042f, .06f, .916f, .88f), "", 15, UIManager.Ivory,
                alignment: TextAnchor.MiddleCenter);

            timingMeter = ui.Panel(screen, new Rect(.156f, .836f, .688f, .020f), UIManager.Ink);
            ui.Panel(timingMeter, new Rect(.047f, .35f, .90f, .30f), UIManager.PanelTint);
            ui.Panel(timingMeter, new Rect(.836f, .31f, .114f, .38f), UIManager.Gold, false);
            pointer = ui.Panel(timingMeter, new Rect(.01f, .16f, .02f, .68f), UIManager.Ivory, false);

            bowling = ui.Panel(screen, new Rect(.055f, .776f, .89f, .080f), UIManager.Ink);
            aimStatus = ui.Label(bowling, new Rect(.04f, .075f, .92f, .27f), "", 13, UIManager.Muted);
            ui.Button(bowling, new Rect(.054f, .42f, .50f, .49f), "", UIManager.PanelTint, UIManager.Ivory, nextDelivery, out deliveryName, 17);
            ui.Button(bowling, new Rect(.595f, .42f, .346f, .49f), "BOWL", UIManager.Gold, UIManager.Ink, bowl, 19);

            tutorial = ui.Panel(screen, new Rect(.080f, .686f, .84f, .064f), UIManager.Ink);
            tip = ui.Label(tutorial, new Rect(.048f, .11f, .69f, .78f), "", 15, UIManager.Ivory, false, TextAnchor.MiddleLeft);
            ui.Button(tutorial, new Rect(.752f, .22f, .197f, .54f), "SKIP", UIManager.PanelTint, UIManager.Muted, Skip, 13);

            interval = Modal("End of innings");
            ui.Label(interval, new Rect(.06f, .10f, .88f, .16f), "INNINGS BREAK", 33, UIManager.Gold);
            intervalLabel = ui.Label(interval, new Rect(.083f, .32f, .834f, .33f), "", 22, UIManager.Ivory);
            ui.Button(interval, new Rect(.12f, .73f, .76f, .17f), "START BOWLING", UIManager.Gold, UIManager.Ink, advance);
            interval.gameObject.SetActive(false);

            pausePanel = Modal("Match paused");
            ui.Label(pausePanel, new Rect(.08f, .13f, .84f, .21f), "MATCH PAUSED", 34, UIManager.Gold);
            ui.Button(pausePanel, new Rect(.12f, .40f, .76f, .19f), "RESUME MATCH", UIManager.Gold, UIManager.Ink, resume);
            ui.Button(pausePanel, new Rect(.12f, .66f, .76f, .19f), "MAIN MENU", UIManager.PanelTint, UIManager.Ivory, mainMenu);
            pausePanel.gameObject.SetActive(false);

            match.Changed += Refresh;
            match.Decided += ShowResult;
            match.Swing += value => { lastTiming = value.Timing; feedbackAge = 0; newBall = false; };
            Refresh();
        }

        public void Draw(BowlingAim selected, bool paused, string caption)
        {
            if (!paused) feedbackAge += Time.deltaTime;
            bool aiming = !match.HumanBatting && match.Phase == PlayPhase.Ready;
            commentaryStrip.gameObject.SetActive(!paused && !aiming && match.Phase != PlayPhase.Interval && !string.IsNullOrEmpty(caption));
            UIManager.SetText(commentary, caption);
            float x = Mathf.Lerp(.045f, .935f, match.TimingProgress);
            pointer.anchorMin = new Vector2(x, .16f);
            pointer.anchorMax = new Vector2(x + .021f, .84f);
            timingMeter.gameObject.SetActive(match.HumanBatting && match.Phase == PlayPhase.Delivery && !paused);
            bowling.gameObject.SetActive(!match.HumanBatting && match.Phase == PlayPhase.Ready && !paused);
            if (bowling.gameObject.activeSelf)
            {
                string line = selected.Line < -.23f ? "LEFT LINE" : selected.Line > .23f ? "RIGHT LINE" : "ON STUMPS";
                string length = selected.LandingZ < -6.74f ? "FULL" : selected.LandingZ < -3.35f ? "GOOD LENGTH" : "SHORT";
                aimStatus.color = selected.Overstep ? UIManager.Red : UIManager.Muted;
                UIManager.SetText(aimStatus, selected.Overstep ? "OVERSTEP  ·  EASE BACK FOR A LEGAL BALL" : line + "  ·  " + length);
                UIManager.SetText(deliveryName, CharacterDatabase.DeliveryName(selected.Type).ToUpperInvariant() + "  ›");
            }

            bool showTip = !settings.TutorialSeen && !paused && match.Phase != PlayPhase.Interval &&
                (match.HumanBatting ? match.Rules.Current.LegalBalls <= 4 : match.Rules.Current.LegalBalls <= 3 && match.Phase == PlayPhase.Ready);
            tutorial.gameObject.SetActive(showTip);
            if (showTip)
                UIManager.SetText(tip, !match.HumanBatting ? "Drag on the pitch to aim. Release to bowl." :
                    match.Rules.Current.LegalBalls < 2 ? "Swipe left for off-side. Swipe right for leg-side." :
                    "Finish the swipe as the ball reaches the bat. Swipe farther for power.");
            bool showTiming = match.HumanBatting && !newBall && feedbackAge < 1.16f && !paused;
            UIManager.SetText(timing, showTiming ? ShotTimingSystem.Label(lastTiming) : "");
            timing.color = lastTiming == Timing.Perfect ? UIManager.Gold : lastTiming == Timing.Miss ? UIManager.Red : UIManager.Ivory;
            feedback.localScale = Vector3.one * (showTiming ? 1f + .20f * Mathf.Sin(Mathf.Min(1, feedbackAge * 5f) * Mathf.PI) : 1f);
            feedback.gameObject.SetActive(!paused && (showTiming || match.Phase == PlayPhase.Decision));
            pausePanel.gameObject.SetActive(paused);
            interval.gameObject.SetActive(!paused && match.Phase == PlayPhase.Interval);
        }

        private RectTransform Modal(string name)
        {
            RectTransform rect = ui.Panel(ui.Safe, new Rect(.065f, .31f, .87f, .36f), UIManager.Ink);
            rect.gameObject.name = name;
            ui.Panel(rect, new Rect(.10f, .06f, .80f, .010f), UIManager.Gold, false);
            return rect;
        }

        private void Refresh()
        {
            CricketRulesEngine engine = match.Rules;
            InningsScore current = engine.Current;
            bool decision = match.Phase == PlayPhase.Decision;
            if (match.Phase == PlayPhase.Ready)
            {
                newBall = true;
                call.text = "";
                umpire.text = "";
                if (current.LegalBalls == 0 && current.Extras == 0)
                {
                    for (int i = 0; i < tokens.Length; i++)
                    {
                        tokens[i].text = "·";
                        tokens[i].color = UIManager.Muted;
                        tokenTiles[i].color = UIManager.PanelTint;
                    }
                    marked = 0;
                }
            }
            int batterId = decision ? match.StrikerAtDecision : match.StrikerId;
            int bowlerId = decision ? match.BowlerAtDecisionId : match.BowlerId;
            Color accent = engine.Innings == 0 ? UIManager.Blue : UIManager.Gold;
            score.text = current.Runs + "/" + current.Wickets;
            team.text = engine.Innings == 0 ? "COLONY BLUE" : "COLONY GOLD";
            team.color = accent;
            teamAccent.GetComponent<Image>().color = accent;
            progress.GetComponent<Image>().color = accent;
            progress.anchorMax = new Vector2((float)current.LegalBalls / (engine.OversPerInnings * 6), 1f);
            overs.text = current.Overs + " / " + engine.OversPerInnings + ".0";
            target.text = engine.Innings == 0 ? "RUN RATE" : "TARGET  " + engine.Target;
            chase.text = engine.Innings == 0
                ? current.LegalBalls == 0 ? "–" : (current.Runs * 6f / current.LegalBalls).ToString("0.00")
                : engine.Required + " off " + engine.RemainingBalls;
            status.text = engine.Innings == 0
                ? "1ST INNINGS  •  " + engine.RemainingBalls + " BALLS LEFT"
                : "BLUE " + engine.Scores[0].Runs + "/" + engine.Scores[0].Wickets + "  •  2ND INNINGS";
            batter.text = CharacterDatabase.Players[batterId].Name + "  " + engine.BattingRuns[batterId] +
                " (" + engine.BattingBalls[batterId] + ")";
            bowler.text = CharacterDatabase.Players[bowlerId].Name;
            partner.text = decision ? "ON STRIKE" : "WITH  " + match.Teams.Player(engine.Innings, current.NonStriker).Name;
            int balls = engine.BowlingBalls[bowlerId];
            bowlingFigures.text = engine.BowlingWickets[bowlerId] + "–" + engine.BowlingRuns[bowlerId] +
                "  •  " + balls / 6 + "." + balls % 6 + " OV";
            if (match.Phase == PlayPhase.Interval)
                intervalLabel.text = "Blue " + current.Runs + "/" + current.Wickets + "  •  " + current.Overs + " overs\n\nGold needs " +
                    (current.Runs + 1) + " to win.";
        }

        private void ShowResult(DeliveryResult result)
        {
            string label;
            string symbol;
            if (result.Dismissal != Dismissal.None)
            {
                label = "WICKET!";
                symbol = "W";
            }
            else if (result.Boundary != 0)
            {
                label = result.Boundary == 6 ? "MASSIVE SIX!" : "FOUR!";
                symbol = result.Total.ToString();
            }
            else if (result.Extra != Extra.None)
            {
                label = result.Extra == Extra.Wide ? "WIDE" : "NO BALL";
                symbol = result.Extra == Extra.Wide ? "Wd" : "Nb";
            }
            else
            {
                label = result.RunningRuns == 0 ? "DOT BALL" : result.RunningRuns == 1 ? "1 RUN" : result.RunningRuns + " RUNS";
                symbol = result.RunningRuns.ToString();
            }

            call.text = label;
            call.color = result.Dismissal != Dismissal.None ? UIManager.Red : result.Boundary > 0 ? UIManager.Gold : UIManager.Ivory;
            string official = UmpireController.Decision(result);
            string detail = result.Dismissal == Dismissal.None ? "" : match.DismissedName + "  ·  " +
                (result.Dismissal == Dismissal.RunOut ? "Run out" : result.Dismissal.ToString()) +
                (result.Dismissal == Dismissal.RunOut ? "" : "  ·  " + match.BowlerAtDecision) + "\n";
            umpire.text = detail + official;
            if (marked >= tokens.Length)
            {
                for (int i = 0; i < tokens.Length - 1; i++)
                {
                    tokens[i].text = tokens[i + 1].text;
                    tokens[i].color = tokens[i + 1].color;
                    tokenTiles[i].color = tokenTiles[i + 1].color;
                }
                marked = tokens.Length - 1;
            }
            tokens[marked].text = symbol;
            tokenTiles[marked].color = result.Dismissal != Dismissal.None ? UIManager.Red :
                result.Boundary > 0 ? UIManager.Gold : UIManager.PanelTint;
            tokens[marked].color = result.Dismissal != Dismissal.None || result.Boundary > 0 ? UIManager.Ink : call.color;
            marked++;
        }

        private void Skip()
        {
            settings.TutorialSeen = true;
            settings.Save();
        }
    }
}
