using UnityEngine;

namespace ColonyCricket
{
    internal sealed class FieldRadar
    {
        private readonly RectTransform background, ball, bowler, striker;
        private readonly RectTransform[] fielders;
        private readonly MatchManager match;

        public FieldRadar(UIManager ui, MatchManager match)
        {
            this.match = match;
            background = UIManager.RectNode("Field radar", ui.Safe, new Rect(.044f, .189f, .228f, .115f));
            ui.Graphic(background, new Rect(0, 0, 1, 1), "Radar", fitted: true);
            var square = UIManager.RectNode("Radar marks", background, new Rect(0, 0, 1, 1));
            var fitter = square.gameObject.AddComponent<UnityEngine.UI.AspectRatioFitter>();
            fitter.aspectRatio = 1;
            fitter.aspectMode = UnityEngine.UI.AspectRatioFitter.AspectMode.FitInParent;
            fielders = new RectTransform[match.Fielders.Length];
            for (int i = 0; i < fielders.Length; i++) fielders[i] = Dot(ui, square, UIManager.Ivory);
            striker = Dot(ui, square, UIManager.Gold);
            bowler = Dot(ui, square, UIManager.Blue);
            ball = Dot(ui, square, new Color(1f, .34f, .20f));
        }

        public void Draw(bool visible)
        {
            background.gameObject.SetActive(visible);
            if (!visible) return;
            float side = match.HumanBatting ? 1f : -1f;
            for (int i = 0; i < fielders.Length; i++)
                Position(fielders[i], match.Fielders[i].Position, side, .039f);
            Vector3 batterPosition = match.Runners == null
                ? RunningBetweenWickets.BattingGuard(match.Striker) : match.Runners.StrikerPosition;
            Position(striker, batterPosition, side, .061f);
            Vector3 shooter = match.Phase == PlayPhase.Ready ? match.RunningStart : match.RunningRelease;
            if (match.Phase == PlayPhase.RunUp)
                shooter = Vector3.Lerp(match.RunningStart, match.RunningRelease, match.PhaseTime / match.RunUpDuration);
            Position(bowler, shooter, side, .061f);
            ball.gameObject.SetActive(match.BallVisible);
            if (match.BallVisible) Position(ball, match.BallPosition, side, .069f);
        }

        private static RectTransform Dot(UIManager ui, Transform parent, Color color) =>
            ui.Panel(parent, new Rect(.475f, .475f, .05f, .05f), color);

        private static void Position(RectTransform dot, Vector3 position, float side, float size)
        {
            var relative = new Vector2(position.x / BallPhysicsController.FieldX, position.z / BallPhysicsController.FieldZ);
            var centre = Vector2.one * .5f + Vector2.ClampMagnitude(relative, 1f) * (.456f * side);
            Vector2 half = Vector2.one * (size * .5f);
            dot.anchorMin = centre - half;
            dot.anchorMax = centre + half;
        }
    }
}
