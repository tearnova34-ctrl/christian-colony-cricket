using UnityEngine;

namespace ColonyCricket
{
    internal sealed class CameraController
    {
        private readonly Camera camera;
        private Vector3 focus;
        private bool reset = true;
        private bool? previousInnings;
        private PlayPhase previousPhase;
        private Vector3 flightOrigin, flightDirection;

        public CameraController(Transform owner)
        {
            camera = ArenaArt.Node("Broadcast camera", owner, Vector3.zero).gameObject.AddComponent<Camera>();
            camera.gameObject.tag = "MainCamera";
            camera.gameObject.AddComponent<AudioListener>();
            camera.clearFlags = CameraClearFlags.Skybox;
            camera.nearClipPlane = .17f;
            camera.farClipPlane = 180f;
            camera.allowHDR = false;
        }

        public void ShowMenu(bool selection)
        {
            float orbit = Mathf.Sin(Time.time * .19f);
            Vector3 position = selection ? new Vector3(4.4f + orbit * .7f, 2.65f, -8.9f) : new Vector3(6.8f + orbit * 2.8f, 3.2f, -18.8f);
            Move(position, selection ? new Vector3(0f, 1.15f, -4.45f) : new Vector3(0, .75f, 4.8f), selection ? 46 : 43f);
        }

        public void ShowMatch(MatchManager match, bool powerful)
        {
            Vector3 ball = match.BallPosition;
            bool batting = match.HumanBatting;
            Cricketer striker = match.Phase == PlayPhase.Decision
                ? CharacterDatabase.Players[match.StrikerAtDecision] : match.Striker;
            float side = striker.LeftHanded ? -1f : 1f;
            float portraitWidth = Mathf.Clamp(.49f / camera.aspect, .83f, 1.18f);
            float battingLens = 43f * portraitWidth;
            float bowlingLens = 40f * portraitWidth;
            Vector3 position = batting
                ? new Vector3(-1.08f * side, 2.50f, -15.75f)
                : new Vector3(-1.26f, 2.29f, 21.20f);
            Vector3 target = batting
                ? new Vector3(.30f * side, .03f, -3.55f)
                : new Vector3(.10f, -.64f, -1.50f);
            float lens = batting ? battingLens : bowlingLens;
            float smoothing = 8f;

            if (previousInnings != batting)
            {
                reset = true;
                previousInnings = batting;
            }

            switch (match.Phase)
            {
                case PlayPhase.Ready:
                case PlayPhase.RunUp:
                case PlayPhase.Delivery:
                    if (!batting)
                    {
                        float approach = match.Phase == PlayPhase.RunUp
                            ? Mathf.SmoothStep(0, 1, match.PhaseTime / match.RunUpDuration)
                            : match.Phase == PlayPhase.Delivery ? 1f : 0f;
                        position.z -= approach * 3.2f;
                        position.y += approach * .14f;
                        // Keep the bowler on the left so the release and bounce have a clear sightline.
                    }
                    break;
                case PlayPhase.Flight:
                case PlayPhase.Throw:
                    if (previousPhase != match.Phase)
                    {
                        flightOrigin = ball;
                        if (match.Phase == PlayPhase.Flight) flightDirection = Vector3.zero;
                    }
                    Vector3 displacement = Vector3.ProjectOnPlane(ball - flightOrigin, Vector3.up);
                    if (match.Phase == PlayPhase.Flight && displacement.sqrMagnitude > .15f)
                        flightDirection = Vector3.Slerp(flightDirection, displacement.normalized, .32f).normalized;
                    if (flightDirection.sqrMagnitude < .01f) flightDirection = Vector3.forward;

                    float revealDelay = batting ? .22f : .12f;
                    float reveal = Mathf.SmoothStep(0, 1, (match.PhaseTime - revealDelay) / .50f);
                    if (match.Phase == PlayPhase.Throw) reveal = 1f;
                    Vector3 look = ball + flightDirection * (powerful ? 2.9f : 1.6f);
                    look.y = Mathf.Lerp(.25f, ball.y, .84f);
                    Vector3 chase = ball - flightDirection * (powerful ? 10.3f : 8.4f);
                    chase += Vector3.Cross(Vector3.up, flightDirection) * 3.15f;
                    chase.y = Mathf.Max(3.25f, ball.y * .80f + 3.3f);
                    position = Vector3.Lerp(position, chase, reveal);
                    target = Vector3.Lerp(target, look, reveal);
                    lens = Mathf.Lerp(lens, 43f * portraitWidth, reveal);
                    smoothing = Mathf.Lerp(8f, 14f, reveal);
                    break;
                case PlayPhase.Decision:
                    if (match.LastResult.Dismissal != Dismissal.None)
                    {
                        Vector3 end = match.LastResult.Dismissal == Dismissal.Caught ? ball :
                            new Vector3(0, .91f, match.LastResult.Dismissal == Dismissal.RunOut &&
                                match.LastResult.WicketEnd == WicketEnd.NonStriker ? 10f : DeliveryTrajectory.StumpsZ);
                        position = new Vector3(end.x - 3.25f, 2.35f, end.z - 4.8f);
                        target = end + Vector3.up * .18f;
                        lens = 43f * portraitWidth;
                    }
                    else if (match.LastResult.Boundary > 0)
                    {
                        Vector3 along = new Vector3(ball.x, 0, ball.z).normalized;
                        Vector3 across = Vector3.Cross(Vector3.up, along);
                        position = ball - along * 9.4f + across * (4.6f + match.PhaseTime);
                        position.y = match.LastResult.Boundary == 6 ? 7.2f : 4.65f;
                        target = new Vector3(ball.x, Mathf.Clamp(ball.y, .75f, 6f), ball.z) + along * 1.3f;
                        lens = 46f * portraitWidth;
                    }
                    break;
                case PlayPhase.Interval:
                case PlayPhase.Finished:
                    position = new Vector3(4.7f, 4.55f, -16.6f);
                    target = new Vector3(0, .90f, -.5f);
                    lens = 43f * portraitWidth;
                    break;
            }

            previousPhase = match.Phase;
            Move(position, target, lens, smoothing);
        }

        public void ShowResult()
        {
            float orbit = Mathf.Sin(Time.time * .24f);
            Move(new Vector3(1.2f + orbit * 2.0f, 2.64f, -10.6f), new Vector3(0, 1.41f, -3.2f), 50);
        }

        private void Move(Vector3 position, Vector3 target, float fieldOfView, float smoothing = 6.8f)
        {
            float dt = 1f - Mathf.Exp(-Time.deltaTime * smoothing);
            if (reset) { dt = 1f; reset = false; }
            camera.transform.position = Vector3.Lerp(camera.transform.position, position, dt);
            focus = Vector3.Lerp(focus, target, dt);
            camera.transform.rotation = Quaternion.LookRotation(focus - camera.transform.position, Vector3.up);
            camera.fieldOfView = Mathf.Lerp(camera.fieldOfView, fieldOfView, dt);
        }
    }
}
