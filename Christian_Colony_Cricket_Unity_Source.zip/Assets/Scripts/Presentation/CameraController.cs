using UnityEngine;

namespace ColonyCricket
{
    internal sealed class CameraController
    {
        private readonly Camera camera;
        private Vector3 focus;
        private bool reset = true;

        public CameraController(Transform owner)
        {
            camera = ArenaArt.Node("Broadcast camera", owner, Vector3.zero).gameObject.AddComponent<Camera>();
            camera.gameObject.tag = "MainCamera";
            camera.gameObject.AddComponent<AudioListener>();
            camera.clearFlags = CameraClearFlags.Skybox;
            camera.nearClipPlane = .17f;
            camera.farClipPlane = 180f;
            camera.allowHDR = false;
        }

        public void ShowMenu(bool selection)
        {
            float orbit = Mathf.Sin(Time.time * .19f);
            Vector3 position = selection ? new Vector3(4.4f + orbit * .7f, 2.65f, -8.9f) : new Vector3(6.8f + orbit * 2.8f, 3.2f, -18.8f);
            Move(position, selection ? new Vector3(0f, 1.15f, -4.45f) : new Vector3(0, .75f, 4.8f), selection ? 46 : 43f);
        }

        public void ShowMatch(MatchManager match, bool powerful)
        {
            Vector3 ball = match.BallPosition;
            bool batting = match.HumanBatting;
            Vector3 position = batting ? new Vector3(-.52f, 2.84f, -15.1f) :
                new Vector3(-1.64f, 4.52f, 17.0f);
            Vector3 target = batting ? new Vector3(.05f, 1.16f, 3.3f) : new Vector3(-.06f, .54f, -2.5f);
            float lens = batting ? 41.5f : 43f;
            switch (match.Phase)
            {
                case PlayPhase.Flight:
                case PlayPhase.Throw:
                    Vector3 focusBall = new Vector3(ball.x, Mathf.Min(ball.y, 5.5f), ball.z);
                    float following = match.Phase == PlayPhase.Throw ? .42f : powerful ? .83f : .59f;
                    float travel = Mathf.SmoothStep(0, 1, match.PhaseTime * 1.7f);
                    target = Vector3.Lerp(target, focusBall, following * travel);
                    position = Vector3.Lerp(position, new Vector3(ball.x * .68f, 6.5f + Mathf.Min(ball.y, 9) * .30f,
                        ball.z - (batting ? 12.0f : -13.0f)), travel * (powerful ? .77f : .50f));
                    lens = 47f;
                    break;
                case PlayPhase.Decision:
                    if (match.LastResult.Dismissal != Dismissal.None)
                    {
                        Vector3 end = match.LastResult.Dismissal == Dismissal.Caught ? ball :
                            new Vector3(0, 1.11f, match.LastResult.Dismissal == Dismissal.RunOut &&
                                match.LastResult.WicketEnd == WicketEnd.NonStriker ? 10 : -9.6f);
                        position = new Vector3(end.x - 3.55f, 2.57f, end.z - 5.3f);
                        target = end + Vector3.up * .28f;
                        lens = 48f;
                    }
                    else if (match.LastResult.Boundary > 0)
                    {
                        Vector3 along = new Vector3(ball.x, 0, ball.z).normalized;
                        Vector3 across = Vector3.Cross(Vector3.up, along);
                        position = ball - along * 8.6f + across * (7.1f + match.PhaseTime * 1.8f);
                        position.y = match.LastResult.Boundary == 6 ? 6.6f : 4.1f;
                        target = new Vector3(ball.x, Mathf.Min(5, ball.y), ball.z) + along * 3.3f;
                        lens = 54;
                    }
                    break;
                case PlayPhase.Interval:
                case PlayPhase.Finished:
                    position = new Vector3(3.0f, 5.1f, -16.0f);
                    target = new Vector3(0, .8f, 3f);
                    break;
            }
            Move(position, target, lens);
        }

        public void ShowResult()
        {
            float orbit = Mathf.Sin(Time.time * .24f);
            Move(new Vector3(1.2f + orbit * 2.0f, 2.64f, -10.6f), new Vector3(0, 1.41f, -3.2f), 50);
        }

        private void Move(Vector3 position, Vector3 target, float fieldOfView)
        {
            float dt = 1f - Mathf.Exp(-Time.deltaTime * 6.8f);
            if (reset) { dt = 1f; reset = false; }
            camera.transform.position = Vector3.Lerp(camera.transform.position, position, dt);
            focus = Vector3.Lerp(focus, target, dt);
            camera.transform.rotation = Quaternion.LookRotation(focus - camera.transform.position, Vector3.up);
            camera.fieldOfView = Mathf.Lerp(camera.fieldOfView, fieldOfView, dt);
        }
    }
}
