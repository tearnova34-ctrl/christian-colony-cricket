using UnityEngine;

namespace ColonyCricket
{
    internal sealed class CameraController
    {
        private readonly Camera camera;
        private Vector3 focus;
        private bool reset = true;
        public CameraController(Transform owner)
        {
            camera = ArenaArt.Node("Broadcast camera", owner, Vector3.zero).gameObject.AddComponent<Camera>();
            camera.gameObject.tag = "MainCamera";
            camera.gameObject.AddComponent<AudioListener>();
            camera.clearFlags = CameraClearFlags.Skybox;
            camera.nearClipPlane = .17f;
            camera.farClipPlane = 180f;
            camera.allowHDR = false;
        }

        public void ShowMenu(bool selection)
        {
            float orbit = Mathf.Sin(Time.time * .19f);
            Vector3 position = selection ? new Vector3(.74f + orbit * .48f, 1.71f, -8.58f) : new Vector3(6.8f + orbit * 2.8f, 3.2f, -18.8f);
            Move(position, selection ? new Vector3(.02f, 1.20f, -4.86f) : new Vector3(0, .75f, 4.8f), selection ? 46 : 43f);
        }

        public void ShowMatch(bool bowling = false)
        {
            float portrait = Mathf.Clamp(.48f / camera.aspect, .95f, 1.17f);
            Vector3 position = bowling ? new Vector3(0f, 3.12f, 20.25f) : new Vector3(0f, 2.62f, -16.24f);
            Vector3 target = bowling ? new Vector3(0f, .11f, -2.2f) : new Vector3(0f, .12f, -3.65f);
            camera.transform.SetPositionAndRotation(position, Quaternion.LookRotation(target - position, Vector3.up));
            camera.fieldOfView = 46f * portrait;
        }

        public void ShowCeremony()
        {
            Move(new Vector3(0f, 2.02f, -8.5f), new Vector3(0f, 1.13f, -4.25f), 47f, 8f);
        }

        public void ShowResult()
        {
            float orbit = Mathf.Sin(Time.time * .24f);
            Move(new Vector3(1.2f + orbit * 2.0f, 2.64f, -10.6f), new Vector3(0, 1.41f, -3.2f), 50);
        }

        private void Move(Vector3 position, Vector3 target, float fieldOfView, float smoothing = 6.8f)
        {
            float dt = 1f - Mathf.Exp(-Time.deltaTime * smoothing);
            if (reset) { dt = 1f; reset = false; }
            camera.transform.position = Vector3.Lerp(camera.transform.position, position, dt);
            focus = Vector3.Lerp(focus, target, dt);
            camera.transform.rotation = Quaternion.LookRotation(focus - camera.transform.position, Vector3.up);
            camera.fieldOfView = Mathf.Lerp(camera.fieldOfView, fieldOfView, dt);
        }
    }
}
