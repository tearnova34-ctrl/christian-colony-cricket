using System;
using UnityEngine;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class ReplayOverlay
    {
        private readonly RectTransform root, fill;
        private readonly Text heading, detail;
        private readonly ArenaMatchView arena;
        private readonly CameraController camera;
        private DeliveryReplay data;
        private ReplayTimeline timeline;
        private float clock;
        private bool review, overturned;

        public bool Active => root.gameObject.activeSelf;

        public ReplayOverlay(UIManager ui, ArenaMatchView arena, CameraController camera, Action close)
        {
            this.arena = arena;
            this.camera = camera;
            root = ui.Panel(ui.Safe, new Rect(0f, 0f, 1f, 1f), Color.clear, false);
            root.GetComponent<Image>().raycastTarget = true;
            RectTransform header = ui.Card(root, new Rect(.08f, .029f, .84f, .113f), Palette.India);
            heading = ui.Label(header, new Rect(.045f, .095f, .91f, .42f), "", 24, UIManager.Gold);
            detail = ui.Label(header, new Rect(.04f, .553f, .92f, .32f), "", 15, UIManager.Ivory);
            RectTransform bottom = ui.Card(root, new Rect(.072f, .843f, .856f, .111f), Palette.Australia);
            RectTransform rail = ui.Panel(bottom, new Rect(.072f, .13f, .856f, .078f), UIManager.PanelTint, false);
            fill = ui.Panel(rail, new Rect(0f, 0f, 1f, 1f), UIManager.Gold, false);
            ui.Button(bottom, new Rect(.055f, .337f, .40f, .51f), "RESTART", UIManager.PanelTint, UIManager.Ivory, () => clock = 0f, 16);
            ui.Button(bottom, new Rect(.505f, .337f, .44f, .51f), "BACK TO MATCH", UIManager.Gold, UIManager.Ink, close, 15);
            root.gameObject.SetActive(false);
        }

        public void Start(DeliveryReplay replay, bool isReview, bool changed)
        {
            data = replay;
            timeline = new ReplayTimeline(replay);
            review = isReview;
            overturned = changed;
            clock = 0f;
            root.SetAsLastSibling();
            root.gameObject.SetActive(true);
            Draw();
        }

        public void Draw()
        {
            if (!Active) return;
            float speed = review ? (clock > data.DeliveryTime - .21f ? .35f : .74f) : .72f;
            clock = Mathf.Min(timeline.Duration, clock + Mathf.Min(.06f, Time.unscaledDeltaTime) * speed);
            fill.anchorMax = new Vector2(clock / Mathf.Max(.01f, timeline.Duration), 1f);
            arena.DrawReplay(data, timeline, clock, review);
            camera.ShowReplay(data, timeline.Ball(clock), clock, review);
            if (!review)
            {
                UIManager.SetText(heading, "LAST BALL REPLAY");
                UIManager.SetText(detail, data.Result.OutcomeLabel + "  •  SLOW MOTION");
                return;
            }

            bool evidenceReady = data.Evidence.Kind == Appeal.Catch
                ? clock >= data.DeliveryTime + data.Evidence.GloveTime : clock >= data.DeliveryTime + .24f;
            UIManager.SetText(heading, evidenceReady ? (overturned ? "DECISION OVERTURNED" : "DECISION STANDS") : "THIRD UMPIRE REVIEW");
            string evidence = data.Evidence.Kind == Appeal.Catch
                ? data.Evidence.ActualOut ? "GLOVE BEFORE GROUND" : "BALL TOUCHED GRASS FIRST"
                : (data.Evidence.PitchedLegal ? "PITCH LEGAL" : "OUTSIDE LEG") + "  ·  " +
                  (data.Evidence.ImpactInline ? "IN LINE" : "IMPACT OUTSIDE") + "  ·  " +
                  (data.Evidence.HitsWicket ? "HITTING" : "MISSING");
            UIManager.SetText(detail, evidenceReady ? (data.Evidence.ActualOut ? "OUT  —  " : "NOT OUT  —  ") + evidence :
                data.Evidence.Kind == Appeal.Catch ? "CHECKING THE LOW CATCH" : "CHECKING PITCH, IMPACT AND WICKETS");
        }

        public void Close()
        {
            root.gameObject.SetActive(false);
            data = null;
            timeline = null;
        }
    }
}
