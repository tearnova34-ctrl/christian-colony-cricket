using System.Collections.Generic;
using UnityEngine;

namespace ColonyCricket
{
    internal sealed class CricketerFace
    {
        private readonly Transform[] eyes = new Transform[2];
        private readonly float blinkOffset;

        public CricketerFace(Transform head, ArenaArt art, Material skin, Material hair, int id)
        {
            blinkOffset = id * .39f;
            Color tone = skin.color;
            Material complexion = art.Mat("Face skin " + id, tone, "Skin");
            Material eyeWhite = art.Mat("Eye white", new Color(.78f, .744f, .703f));
            Material iris = art.Mat("Iris", new Color(.185f, .105f, .071f));
            Material pupil = art.Mat("Pupil", new Color(.034f, .024f, .022f));
            Material lips = art.Mat("Lips " + id, Color.Lerp(tone, new Color(.63f, .24f, .23f), .28f));
            Material crease = art.Mat("Face creases " + id, Color.Lerp(tone, new Color(.25f, .082f, .064f), .42f));

            ArenaArt.Part("Sculpted face", head, Sculpt(id), complexion, Vector3.zero, Vector3.one);
            for (int i = 0; i < 2; i++)
            {
                int side = i == 0 ? -1 : 1;
                ArenaArt.Part("Outer ear", head, Forms.Ball, complexion, new Vector3(side * .130f, .112f, -.009f),
                    new Vector3(.042f, .073f, .055f), false).localRotation = Quaternion.Euler(0, side * 22f, side * 10f);
                ArenaArt.Part("Inner ear", head, Forms.Ball, crease, new Vector3(side * .145f, .136f, .015f),
                    new Vector3(.019f, .042f, .017f), false);
                Transform eye = ArenaArt.Node("Blink rig", head, new Vector3(side * .056f, .171f, .118f));
                eye.localRotation = Quaternion.Euler(0, side * 11f, side * 5f);
                eyes[i] = eye;
                ArenaArt.Part("Eye", eye, Forms.Ball, eyeWhite, new Vector3(0, 0, -.003f), new Vector3(.044f, .013f, .018f), false);
                ArenaArt.Part("Iris", eye, Forms.Ball, iris, new Vector3(.001f, .0014f, .007f), new Vector3(.015f, .013f, .010f), false);
                ArenaArt.Part("Pupil", eye, Forms.Ball, pupil, new Vector3(.001f, .004f, .012f), new Vector3(.008f, .008f, .007f), false);
                Transform brow = ArenaArt.Part("Eyebrow", head, Forms.Ball, hair,
                    new Vector3(side * .061f, .204f, .127f), new Vector3(.045f, .0056f, .008f), false);
                brow.localRotation = Quaternion.Euler(0, side * 12f, side * 7f);
                ArenaArt.Part("Nostril", head, Forms.Ball, crease, new Vector3(side * .015f, .124f, .152f),
                    new Vector3(.010f, .007f, .008f), false);
            }
            ArenaArt.Part("Lower lip", head, Forms.Ball, lips, new Vector3(0, .077f, .113f),
                new Vector3(.057f, .015f, .014f), false);
            ArenaArt.Part("Mouth line", head, Forms.Ball, crease, new Vector3(0, .087f, .119f),
                new Vector3(.062f, .005f, .010f), false);
            if (id == 0 || id == 2 || id == 3 || id == 5)
                ArenaArt.Part("Temples and hairline", head, Forms.Cap, hair, new Vector3(0f, .212f, -.009f),
                    new Vector3(.278f, .113f, .295f));
            else
                ArenaArt.Part("Tied hair", head, Forms.Ball, hair, new Vector3(.013f, .068f, -.134f),
                    new Vector3(.110f, .173f, .079f));
        }

        public void Animate(float time)
        {
            float phase = Mathf.Repeat(time + blinkOffset, 3.87f);
            float closed = Mathf.Clamp01(1f - Mathf.Abs(phase - .11f) / .095f);
            Vector3 scale = new Vector3(1f, 1f - closed * .92f, 1f);
            foreach (Transform eye in eyes) eye.localScale = scale;
        }

        private static Mesh Sculpt(int id)
        {
            const int rings = 38;
            const int sides = 52;
            float breadth = 1f + ((id * 3 % 7) - 3) * .018f;
            float nose = .030f + .004f * (id % 3);
            float jawLength = 1f + ((id * 7 % 5) - 2) * .021f;
            float jaw = id == 0 || id == 2 || id == 3 || id == 5 ? 1f : .91f;
            var vertices = new Vector3[(rings + 1) * (sides + 1)];
            var uv = new Vector2[vertices.Length];
            var triangles = new List<int>(rings * sides * 6);
            for (int r = 0; r <= rings; r++)
            {
                float t = (float)r / rings;
                float h = t * .329f;
                float dome = Mathf.Max(.007f, Mathf.Sin(Mathf.PI * Mathf.Pow(t, .84f)));
                float chin = Mathf.Lerp(jaw * .74f, 1f, Mathf.SmoothStep(0f, 1f, t * 2.2f));
                for (int s = 0; s <= sides; s++)
                {
                    float u = (float)s / sides;
                    float a = u * 2f * Mathf.PI;
                    float x = Mathf.Cos(a) * .137f * breadth * dome * chin;
                    float z = Mathf.Sin(a) * .129f * dome;
                    if (z > 0f)
                    {
                        float front = Mathf.Pow(Mathf.Clamp01(Mathf.Sin(a)), 3f);
                        z += front * (nose * Lump(x, h, 0, .137f, .024f, .026f) +
                            .013f * Lump(x, h, 0, .174f, .020f, .037f) +
                            .013f * Lump(Mathf.Abs(x), h, .072f, .129f, .039f, .036f) -
                            .016f * Lump(Mathf.Abs(x), h, .054f, .174f, .033f, .023f) +
                            .008f * Lump(x, h, 0, .082f, .045f, .022f) +
                            .011f * Lump(x, h, 0, .044f, .054f, .023f));
                    }
                    int k = r * (sides + 1) + s;
                    vertices[k] = new Vector3(x, h - .006f + (jawLength - 1f) * .26f * Mathf.Max(0f, .52f - t), z);
                    uv[k] = new Vector2(u, t);
                    if (r == rings || s == sides) continue;
                    int next = k + sides + 1;
                    triangles.Add(k); triangles.Add(next); triangles.Add(k + 1);
                    triangles.Add(k + 1); triangles.Add(next); triangles.Add(next + 1);
                }
            }
            return Forms.Make("Cricketer anatomy " + id, vertices, triangles.ToArray(), uv);
        }

        private static float Lump(float x, float y, float cx, float cy, float width, float height)
        {
            float u = (x - cx) / width;
            float v = (y - cy) / height;
            return Mathf.Exp(-(u * u + v * v));
        }
    }
}
