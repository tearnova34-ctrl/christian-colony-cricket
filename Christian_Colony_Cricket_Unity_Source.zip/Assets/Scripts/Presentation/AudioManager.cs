using System.Collections.Generic;
using UnityEngine;

namespace ColonyCricket
{
    internal sealed class AudioManager
    {
        private readonly AudioSource effects, audience, music;
        private readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>();
        private readonly SettingsManager settings;
        private static readonly string[] Names =
            { "Bat", "Bounce", "Release", "Stumps", "Catch", "Crowd", "Cheer", "Victory", "Tap", "Music" };

        public AudioManager(Transform parent, SettingsManager settings, bool menu)
        {
            this.settings = settings;
            foreach (string name in Names) clips.Add(name, Resources.Load<AudioClip>("Audio/" + name));
            effects = Channel(parent, "Match effects", null, false, .85f);
            audience = Channel(parent, "Stadium ambience", clips["Crowd"], true, menu ? .19f : .32f);
            music = Channel(parent, "Theme", clips["Music"], true, menu ? .46f : .23f);
            Sync();
        }

        public void Play(string clip, float level = 1f)
        {
            if (settings.Sound && clips.TryGetValue(clip, out AudioClip audio) && audio)
                effects.PlayOneShot(audio, level);
        }

        public void Sync()
        {
            Apply(audience, settings.Sound);
            Apply(music, settings.Music);
        }

        private static void Apply(AudioSource source, bool on)
        {
            if (on && !source.isPlaying) source.Play();
            if (!on && source.isPlaying) source.Stop();
        }

        private static AudioSource Channel(Transform parent, string name, AudioClip clip, bool loop, float volume)
        {
            AudioSource channel = ArenaArt.Node(name, parent, Vector3.zero).gameObject.AddComponent<AudioSource>();
            channel.clip = clip;
            channel.loop = loop;
            channel.volume = volume;
            channel.playOnAwake = false;
            return channel;
        }
    }
}
