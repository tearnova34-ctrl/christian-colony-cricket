using System;
using UnityEngine;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class MissionMenu
    {
        private readonly RectTransform root;
        private readonly SettingsManager settings;
        private readonly Button[] lengths = new Button[BattingMission.Lengths.Length];
        private readonly Button[] levels = new Button[3];

        public bool IsOpen => root.gameObject.activeSelf;

        public MissionMenu(UIManager ui, SettingsManager settings, Action start)
        {
            this.settings = settings;
            root = ui.Panel(ui.Safe, new Rect(0, 0, 1, 1), new Color(.011f, .028f, .046f, .82f), false);
            root.GetComponent<Image>().raycastTarget = true;
            RectTransform card = ui.Panel(root, new Rect(.06f, .265f, .88f, .443f), UIManager.Ink);
            ui.Label(card, new Rect(.055f, .043f, .89f, .134f), "BATTING MISSION", 34, UIManager.Ivory);
            ui.Label(card, new Rect(.073f, .215f, .85f, .07f), "OVERS", 15, UIManager.Muted, alignment: TextAnchor.MiddleLeft);
            for (int i = 0; i < lengths.Length; i++)
            {
                int choice = i;
                lengths[i] = ui.Button(card, new Rect(.07f + .223f * i, .293f, .197f, .117f),
                    BattingMission.Lengths[i].ToString(), UIManager.PanelTint, UIManager.Ivory,
                    () => { settings.Length = choice; Refresh(); }, 23);
            }

            ui.Label(card, new Rect(.073f, .457f, .85f, .07f), "DIFFICULTY", 15, UIManager.Muted, alignment: TextAnchor.MiddleLeft);
            for (int i = 0; i < levels.Length; i++)
            {
                Difficulty level = (Difficulty)i;
                levels[i] = ui.Button(card, new Rect(.07f + .295f * i, .542f, .27f, .112f),
                    level.ToString().ToUpperInvariant(), UIManager.PanelTint, UIManager.Ivory,
                    () => { settings.Difficulty = level; Refresh(); }, 16);
            }

            ui.Button(card, new Rect(.07f, .725f, .86f, .131f), "START MISSION", UIManager.Gold, UIManager.Ink, start, 24);
            ui.Button(card, new Rect(.27f, .876f, .46f, .089f), "BACK", UIManager.PanelTint, UIManager.Muted, Close, 15);
            Close();
        }

        public void Open()
        {
            root.SetAsLastSibling();
            Refresh();
            root.gameObject.SetActive(true);
        }

        public void Close() => root.gameObject.SetActive(false);

        private void Refresh()
        {
            for (int i = 0; i < lengths.Length; i++) Style(lengths[i], i == settings.Length);
            for (int i = 0; i < levels.Length; i++) Style(levels[i], i == (int)settings.Difficulty);
        }

        private static void Style(Button button, bool selected)
        {
            button.targetGraphic.color = selected ? UIManager.Gold : UIManager.PanelTint;
            button.GetComponentInChildren<Text>().color = selected ? UIManager.Ink : UIManager.Ivory;
        }
    }
}
