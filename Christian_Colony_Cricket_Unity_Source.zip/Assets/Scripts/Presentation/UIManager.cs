using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class UIManager
    {
        public static readonly Color Ink = new Color(.025f, .068f, .125f, .96f);
        public static readonly Color PanelTint = new Color(.047f, .119f, .215f, .93f);
        public static readonly Color Muted = new Color(.67f, .79f, .89f);
        public static readonly Color Ivory = new Color(.96f, .973f, .99f);
        public static readonly Color Gold = new Color(1f, .75f, .26f);
        public static readonly Color Blue = new Color(.23f, .52f, 1f);
        public static readonly Color Red = new Color(1f, .37f, .35f);
        public readonly RectTransform Safe;
        private readonly RectTransform canvasRoot;
        private readonly Font regular, bold;
        private readonly Sprite corner;
        private readonly AudioManager audio;
        private Rect lastSafe;

        public UIManager(Transform owner, AudioManager audio)
        {
            this.audio = audio;
            regular = Resources.Load<Font>("Art/Interface");
            bold = Resources.Load<Font>("Art/InterfaceBold");
            var obj = new GameObject("Portrait HUD", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            obj.transform.SetParent(owner, false);
            Canvas canvas = obj.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = obj.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(480, 920);
            scaler.matchWidthOrHeight = .22f;
            canvasRoot = obj.GetComponent<RectTransform>();
            var panel = Resources.Load<Texture2D>("Art/Panel");
            corner = Sprite.Create(panel, new Rect(0, 0, panel.width, panel.height),
                Vector2.one * .5f, 100, 0, SpriteMeshType.FullRect, new Vector4(25, 25, 25, 25));
            Safe = RectNode("Safe area", canvasRoot, new Rect(0, 0, 1, 1));
            var events = new GameObject("Touch and pointer events", typeof(EventSystem), typeof(StandaloneInputModule));
            events.transform.SetParent(owner, false);
            InsetSafeArea();
        }

        public void InsetSafeArea()
        {
            Rect rect = Screen.safeArea;
            if (rect == lastSafe || Screen.width <= 0 || Screen.height <= 0) return;
            lastSafe = rect;
            Safe.anchorMin = new Vector2(rect.xMin / Screen.width, rect.yMin / Screen.height);
            Safe.anchorMax = new Vector2(rect.xMax / Screen.width, rect.yMax / Screen.height);
            Safe.offsetMin = Safe.offsetMax = Vector2.zero;
        }

        // Rect coordinates use a normalized frame measured down from the top.
        public static RectTransform RectNode(string name, Transform parent, Rect frame)
        {
            var node = new GameObject(name, typeof(RectTransform)).GetComponent<RectTransform>();
            node.SetParent(parent, false);
            node.anchorMin = new Vector2(frame.xMin, 1 - frame.yMax);
            node.anchorMax = new Vector2(frame.xMax, 1 - frame.yMin);
            node.offsetMin = node.offsetMax = Vector2.zero;
            return node;
        }

        public RectTransform Panel(Transform parent, Rect box, Color tint, bool rounded = true)
        {
            RectTransform rect = RectNode("Panel", parent, box);
            Image image = rect.gameObject.AddComponent<Image>();
            image.color = tint;
            image.raycastTarget = false;
            if (rounded)
            {
                image.sprite = corner;
                image.type = Image.Type.Sliced;
                image.pixelsPerUnitMultiplier = 1.64f;
            }
            return rect;
        }

        public Text Label(Transform parent, Rect box, string text, int size, Color color, bool heavy = true,
            TextAnchor alignment = TextAnchor.MiddleCenter)
        {
            RectTransform rect = RectNode("Text " + (string.IsNullOrEmpty(text) ? "dynamic" : text.Replace("\n", " ")), parent, box);
            Text label = rect.gameObject.AddComponent<Text>();
            label.font = heavy ? bold : regular;
            label.fontSize = size;
            label.resizeTextForBestFit = true;
            label.resizeTextMinSize = Mathf.Max(8, Mathf.RoundToInt(size * .57f));
            label.resizeTextMaxSize = size;
            label.supportRichText = false;
            label.alignment = alignment;
            label.color = color;
            label.horizontalOverflow = HorizontalWrapMode.Wrap;
            label.verticalOverflow = VerticalWrapMode.Truncate;
            label.raycastTarget = false;
            label.text = text;
            return label;
        }

        public void Graphic(Transform parent, Rect box, string name, bool fitted = false, bool flipped = false)
        {
            RectTransform rect = RectNode(name, parent, box);
            if (fitted) rect = RectNode(name + " aspect", rect, new Rect(0, 0, 1, 1));
            RawImage graphic = rect.gameObject.AddComponent<RawImage>();
            graphic.texture = Resources.Load<Texture2D>("Art/" + name);
            graphic.raycastTarget = false;
            if (flipped) graphic.uvRect = new Rect(0, 1, 1, -1);
            if (fitted)
            {
                AspectRatioFitter aspect = rect.gameObject.AddComponent<AspectRatioFitter>();
                aspect.aspectMode = AspectRatioFitter.AspectMode.FitInParent;
                aspect.aspectRatio = 1;
            }
        }

        public Button Button(Transform parent, Rect box, string text, Color background, Color foreground, Action onClick, out Text label, int size = 19)
        {
            RectTransform rect = Panel(parent, box, background);
            Image image = rect.GetComponent<Image>();
            image.raycastTarget = true;
            Button button = rect.gameObject.AddComponent<Button>();
            button.targetGraphic = image;
            ColorBlock colors = button.colors;
            colors.highlightedColor = new Color(.88f, .93f, 1);
            colors.pressedColor = new Color(.69f, .79f, .97f);
            colors.selectedColor = Color.white;
            colors.disabledColor = new Color(.63f, .67f, .72f);
            button.colors = colors;
            button.navigation = new Navigation { mode = Navigation.Mode.None };
            label = Label(rect, new Rect(.036f, .08f, .928f, .84f), text, size, foreground);
            button.onClick.AddListener(() => { audio.Play("Tap", .48f); onClick(); });
            return button;
        }

        public Button Button(Transform parent, Rect box, string text, Color background, Color foreground, Action onClick, int size = 19) =>
            Button(parent, box, text, background, foreground, onClick, out _, size);

        public static void SetText(Text label, string text)
        {
            if (label.text != text) label.text = text;
        }
    }
}
