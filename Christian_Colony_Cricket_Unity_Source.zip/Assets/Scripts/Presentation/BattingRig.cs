using UnityEngine;

namespace ColonyCricket
{
    public readonly struct BatGrip
    {
        public const float BottomSocket = .701f;
        public const float TopSocket = .808f;
        public const float CentreSocket = (BottomSocket + TopSocket) * .5f;
        public const float SweetSpot = .375f;

        public readonly Vector3 Origin;
        public readonly Quaternion Rotation;
        public Vector3 Top => Origin + Rotation * Vector3.up * TopSocket;
        public Vector3 Bottom => Origin + Rotation * Vector3.up * BottomSocket;

        public BatGrip(Vector3 centre, Vector3 axis, Vector3 bladeFace)
        {
            Vector3 normal = Vector3.ProjectOnPlane(bladeFace, axis);
            if (normal.sqrMagnitude < .001f)
                normal = Vector3.ProjectOnPlane(Mathf.Abs(axis.z) < .85f ? Vector3.forward : Vector3.right, axis);
            Rotation = Quaternion.LookRotation(normal.normalized, axis);
            Origin = centre - Rotation * Vector3.up * CentreSocket;
        }
    }

    public static class BattingRig
    {
        public static Vector3 FitGrip(Vector3 centre, Vector3 axis, Vector3 left, Vector3 right, bool mirrored)
        {
            float offset = (BatGrip.TopSocket - BatGrip.BottomSocket) * .5f;
            Vector3 topOffset = axis * (mirrored ? -offset : offset);
            // Each shoulder constrains its own hand socket. Move the handle as a unit.
            for (int i = 0; i < 4; i++)
            {
                centre = left + Vector3.ClampMagnitude(centre + topOffset - left, .599f) - topOffset;
                centre = right + Vector3.ClampMagnitude(centre - topOffset - right, .599f) + topOffset;
            }
            return centre;
        }

        public static Vector3 Hinge(Vector3 root, Vector3 target, Vector3 bendHint, float first, float second)
        {
            Vector3 span = target - root;
            Vector3 line = span.sqrMagnitude > .000001f ? span.normalized : Vector3.down;
            float reach = Mathf.Clamp(span.magnitude, Mathf.Abs(first - second) + .001f, first + second - .001f);
            Vector3 bend = Vector3.ProjectOnPlane(bendHint, line);
            if (bend.sqrMagnitude < .00001f)
                bend = Vector3.ProjectOnPlane(Mathf.Abs(line.z) < .8f ? Vector3.forward : Vector3.right, line);
            float along = (first * first - second * second + reach * reach) / (2f * reach);
            float across = Mathf.Sqrt(Mathf.Max(0f, first * first - along * along));
            return root + line * along + bend.normalized * across;
        }
    }
}
