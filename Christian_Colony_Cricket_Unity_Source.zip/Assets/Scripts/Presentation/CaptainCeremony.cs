using UnityEngine;

namespace ColonyCricket
{
    internal sealed class CaptainCeremony
    {
        public const float TossDuration = 7.35f;
        public const float ResultDuration = 5.65f;
        private readonly PlayerCharacter pakistan, india;
        private readonly Transform coin;
        private readonly float started = Time.unscaledTime;
        private readonly bool toss;
        private readonly int winner;

        public CaptainCeremony(PlayerCharacter pakistan, PlayerCharacter india, ArenaArt art, Transform root, bool toss, int winner)
        {
            this.pakistan = pakistan;
            this.india = india;
            this.toss = toss;
            this.winner = winner;
            pakistan.Root.gameObject.SetActive(true);
            india.Root.gameObject.SetActive(true);
            pakistan.Dress(false);
            india.Dress(false);
            if (toss)
            {
                Material brass = art.Mat("Toss coin brass", new Color(.99f, .67f, .16f));
                coin = ArenaArt.Part("Toss coin", root, Forms.Tube, brass, Vector3.zero, new Vector3(.18f, .019f, .18f));
                Material ring = art.Mat("Toss coin relief", new Color(.97f, .83f, .48f));
                ArenaArt.Part("Coin face", coin, Forms.Tube, ring, new Vector3(0f, 1.02f, 0f), new Vector3(.72f, .15f, .72f), false);
            }
        }

        public float Elapsed => Time.unscaledTime - started;

        public void Draw()
        {
            float t = Elapsed;
            float approach = Mathf.SmoothStep(0f, 1f, t / 1.80f);
            float spread = Mathf.Lerp(1.57f, .56f, approach);
            int victoriousTeam = winner;
            float shakeStart = toss ? 5.12f : 2.13f;
            float relax = Mathf.SmoothStep(0f, 1f, (t - (shakeStart + 1.12f)) / .87f);
            spread += relax * .21f;
            pakistan.Root.SetPositionAndRotation(new Vector3(-spread, 0f, -4.32f), Quaternion.Euler(0f, 90f + 28f * relax, 0f));
            india.Root.SetPositionAndRotation(new Vector3(spread, 0f, -4.13f), Quaternion.Euler(0f, -90f - 28f * relax, 0f));

            float shake = Mathf.Clamp01((t - shakeStart) / .36f) * (1f - Mathf.Clamp01((t - shakeStart - 1.03f) / .27f));
            Vector3 joint = new Vector3(.014f, 1.17f + shake * .047f * Mathf.Sin((t - shakeStart) * 11f), -4.25f);
            float flip = (t - 2.43f) / 2.26f;
            if (coin)
            {
                bool inAir = flip >= 0 && flip <= 1;
                coin.gameObject.SetActive(inAir);
                if (inAir)
                {
                    float lift = 4f * flip * (1f - flip);
                    coin.SetPositionAndRotation(new Vector3(-.24f + .25f * flip, 1.49f + lift * 1.10f, -4.23f),
                        Quaternion.Euler(flip * 1440f, flip * 530f, 18f));
                }
            }

            ActorPose Pose(int team)
            {
                if (t < 1.72f) return ActorPose.Run;
                if (shake > 0f) return ActorPose.Handshake;
                if (toss && team == 0 && flip > -.14f && flip < 1.08f) return ActorPose.Toss;
                if (!toss && relax > .42f)
                    return victoriousTeam == team ? ActorPose.Celebrate : ActorPose.Applaud;
                return ActorPose.Idle;
            }

            void SetPose(PlayerCharacter player, int team)
            {
                Vector3 wait = player.Root.TransformPoint(new Vector3(.28f, 1.01f, .19f));
                ActorPose pose = Pose(team);
                player.Act(pose, pose == ActorPose.Toss ? flip : t * .64f,
                    greeting: shake > 0f ? Vector3.Lerp(wait, joint, Mathf.SmoothStep(0f, 1f, shake)) : (Vector3?)null);
            }

            SetPose(pakistan, 0);
            SetPose(india, 1);
        }

        public void Close()
        {
            if (coin) Object.Destroy(coin.gameObject);
        }
    }
}
