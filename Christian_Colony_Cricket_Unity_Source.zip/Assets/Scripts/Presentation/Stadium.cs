using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace ColonyCricket
{
    internal sealed class Stadium
    {
        private readonly ArenaArt art;
        public readonly Transform Root;
        public readonly Light Sun;
        public readonly Wickets NearWicket, FarWicket;
        public readonly Transform Ball;
        private readonly Transform crowd;
        private readonly Transform highCrowd;
        private readonly TrailRenderer seamTrail;
        private readonly LineRenderer shotGuide;
        private readonly Transform ballGroundMarker, landingGuide;
        private readonly Material[] boards;

        public Stadium(ArenaArt art)
        {
            this.art = art;
            Root = ArenaArt.Node("Christian Colony Arena", null, Vector3.zero);
            Forms.Initialize();
            Material sky = new Material(Resources.Load<Shader>("Art/ArenaSky"));
            RenderSettings.skybox = sky;
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogColor = new Color(.52f, .64f, .71f);
            RenderSettings.fogDensity = .0041f;
            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.69f, .79f, .94f);
            RenderSettings.ambientEquatorColor = new Color(.53f, .60f, .62f);
            RenderSettings.ambientGroundColor = new Color(.30f, .34f, .27f);
            Sun = ArenaArt.Node("Afternoon sun", Root, Vector3.zero).gameObject.AddComponent<Light>();
            Sun.type = LightType.Directional;
            Sun.transform.rotation = Quaternion.Euler(38, -50, 0);
            Sun.color = new Color(1f, .91f, .77f);
            Sun.intensity = 1.38f;
            Sun.shadows = LightShadows.Soft;
            Sun.shadowNormalBias = .33f;
            RenderSettings.sun = Sun;

            boards = new Material[4];
            for (int i = 0; i < 4; i++) boards[i] = art.Mat("Arena lettering " + i, Color.white, "Board" + i, flat: true);
            BuildField();
            crowd = ArenaArt.Node("Lower stand audience", Root, Vector3.zero);
            highCrowd = ArenaArt.Node("Upper stand audience", Root, Vector3.zero);
            BuildBowl();
            NearWicket = new Wickets(Root, art, new Vector3(0, 0, DeliveryTrajectory.StumpsZ));
            FarWicket = new Wickets(Root, art, new Vector3(0, 0, 10));
            Ball = BuildBall();

            ballGroundMarker = ArenaArt.Part("Ball depth cue", Root, Ring("Ball depth cue", 0, .17f, 1, 20, 0),
                art.Mat("Ball marker", new Color(.13f, .19f, .16f), flat: true),
                Vector3.zero, Vector3.one, false);
            ballGroundMarker.gameObject.SetActive(false);

            var chalk = art.Mat("Delivery guide paint", new Color(.88f, .96f, 1f), flat: true);
            landingGuide = ArenaArt.Node("Projected bounce guide", Root, Vector3.zero);
            ArenaArt.Part("Outer bounce ring", landingGuide, Ring("Bounce ring", .56f, .63f, 1f, 48, 0f),
                chalk, Vector3.zero, Vector3.one, false);
            ArenaArt.Part("Inner bounce ring", landingGuide, Ring("Bounce centre", .22f, .248f, 1f, 26, 0f),
                chalk, Vector3.zero, Vector3.one, false);
            ArenaArt.Part("Bounce crossbar", landingGuide, Forms.Box, chalk,
                Vector3.zero, new Vector3(.31f, .003f, .022f), false);
            ArenaArt.Part("Bounce centre line", landingGuide, Forms.Box, chalk,
                Vector3.zero, new Vector3(.022f, .003f, .31f), false);
            landingGuide.gameObject.SetActive(false);

            shotGuide = ArenaArt.Node("Shot direction guide", Root, Vector3.zero).gameObject.AddComponent<LineRenderer>();
            shotGuide.sharedMaterial = art.Mat("Shot tracer", new Color(.44f, .94f, .90f), flat: true);
            shotGuide.positionCount = 12;
            shotGuide.startWidth = .072f;
            shotGuide.endWidth = .013f;
            shotGuide.numCapVertices = 2;
            shotGuide.shadowCastingMode = ShadowCastingMode.Off;
            shotGuide.receiveShadows = false;
            shotGuide.enabled = false;

            seamTrail = Ball.gameObject.AddComponent<TrailRenderer>();
            seamTrail.sharedMaterial = art.Mat("Ball trail", new Color(1f, .67f, .26f, .65f), flat: true);
            seamTrail.time = .093f;
            seamTrail.startWidth = .115f;
            seamTrail.endWidth = .017f;
            seamTrail.numCapVertices = 1;
            seamTrail.minVertexDistance = .10f;
            seamTrail.shadowCastingMode = ShadowCastingMode.Off;
            seamTrail.receiveShadows = false;
            Ball.gameObject.SetActive(false);
        }

        public void Quality(int quality)
        {
            crowd.gameObject.SetActive(true);
            highCrowd.gameObject.SetActive(quality == 2);
            Sun.shadows = quality == 0 ? LightShadows.None : quality == 1 ? LightShadows.Hard : LightShadows.Soft;
            seamTrail.enabled = quality > 0;
        }

        public void ShowBall(Vector3 position, bool visible, bool streak)
        {
            if (Ball.gameObject.activeSelf != visible)
            {
                Ball.position = position;
                seamTrail.Clear();
                Ball.gameObject.SetActive(visible);
            }
            ballGroundMarker.gameObject.SetActive(visible && position.y < 3.25f);
            if (!visible) return;
            Ball.position = position;
            ballGroundMarker.position = new Vector3(position.x, .029f, position.z);
            ballGroundMarker.localScale = Vector3.one * Mathf.Lerp(.95f, .51f, position.y / 3.25f);
            Ball.Rotate(540 * Time.deltaTime, 590 * Time.deltaTime, 50 * Time.deltaTime, Space.Self);
            seamTrail.emitting = streak;
        }

        public void ShowLandingGuide(Vector3 point, bool visible)
        {
            if (landingGuide.gameObject.activeSelf != visible) landingGuide.gameObject.SetActive(visible);
            if (!visible) return;
            landingGuide.position = new Vector3(point.x, .043f, point.z);
            landingGuide.localScale = Vector3.one * (.94f + .06f * Mathf.Sin(Time.time * 10f));
        }

        public void ShowShotGuide(Vector3 contact, Vector3 velocity, bool visible, float elapsed)
        {
            shotGuide.enabled = visible;
            if (!visible) return;
            Vector3 direction = Vector3.ProjectOnPlane(velocity, Vector3.up).normalized;
            float length = Mathf.Lerp(1.3f, 11f, Mathf.Clamp01(elapsed * 4f));
            for (int i = 0; i < shotGuide.positionCount; i++)
            {
                float progress = i / (float)(shotGuide.positionCount - 1);
                Vector3 point = contact + direction * (length * progress);
                point.y = .062f + .18f * Mathf.Sin(progress * Mathf.PI);
                shotGuide.SetPosition(i, point);
            }
        }

        private void BuildField()
        {
            Material rough = art.Mat("Arena perimeter", new Color(.70f, .84f, .67f), "Turf", tile: 18);
            ArenaArt.Part("Outer apron", Root, Ring("Outer apron mesh", 0, 1, 1, 108, -.055f), rough,
                Vector3.zero, new Vector3(66, 1, 72), false);
            float halfWidth = BallPhysicsController.FieldX + 1.8f;
            float halfLength = BallPhysicsController.FieldZ + 1.8f;
            Material lawnA = art.Mat("Cut grass in light", new Color(.91f, 1.00f, .88f), "Turf");
            Material lawnB = art.Mat("Cut grass in shade", new Color(.82f, .94f, .80f), "Turf");
            var zones = new[] { new List<CombineInstance>(), new List<CombineInstance>() };
            const int cuts = 28;
            for (int row = 0; row < cuts; row++)
            {
                float z0 = Mathf.Lerp(-halfLength, halfLength, (float)row / cuts);
                float z1 = Mathf.Lerp(-halfLength, halfLength, (float)(row + 1) / cuts);
                float span0 = halfWidth * Mathf.Sqrt(Mathf.Max(0, 1 - z0 * z0 / (halfLength * halfLength)));
                float span1 = halfWidth * Mathf.Sqrt(Mathf.Max(0, 1 - z1 * z1 / (halfLength * halfLength)));
                Vector3[] points = {
                    new Vector3(-span0, -.014f, z0), new Vector3(-span1, -.014f, z1),
                    new Vector3(span1, -.014f, z1), new Vector3(span0, -.014f, z0)
                };
                Vector2[] uv = System.Array.ConvertAll(points, p => new Vector2(p.x * .32f, p.z * .32f));
                zones[row % 2].Add(new CombineInstance { mesh = Forms.Make("Grass strip", points, new[] { 0, 1, 2, 0, 2, 3 }, uv),
                    transform = Matrix4x4.identity });
            }
            Batch("Grass mowing A", Root, zones[0], lawnA);
            Batch("Grass mowing B", Root, zones[1], lawnB);

            Material clay = art.Mat("Rolled clay", Color.white, "Pitch", tile: 2);
            Material crease = art.Mat("Lime crease marks", new Color(.96f, .95f, .87f));
            Box("The square", Root, new Vector3(0, -.013f, 0), new Vector3(7.8f, .038f, 25.4f),
                art.Mat("The square grass", new Color(.89f, .99f, .81f), "Turf", tile: 4), false);
            Box("Prepared strip", Root, new Vector3(0, .001f, 0), new Vector3(3.08f, .022f, 23.9f), clay, false);
            for (int sign = -1; sign <= 1; sign += 2)
            {
                Box("Popping crease", Root, new Vector3(0, .016f, sign * DeliveryTrajectory.BowlerCreaseZ), new Vector3(2.99f, .012f, .052f), crease, false);
                Box("Bowling crease", Root, new Vector3(0, .016f, sign * 10), new Vector3(2.70f, .012f, .049f), crease, false);
                for (int side = -1; side <= 1; side += 2)
                    Box("Return crease", Root, new Vector3(side * 1.29f, .016f, sign * 9.96f), new Vector3(.046f, .012f, 2.32f), crease, false);
            }

            Material plaster = art.Mat("Ivory boundary rope", new Color(.95f, .89f, .72f));
            Mesh rope = Ring("Oval rope", .997f, 1f, 1, 144, .035f);
            ArenaArt.Part("Boundary rope", Root, rope, plaster, Vector3.zero,
                new Vector3(BallPhysicsController.FieldX, 1, BallPhysicsController.FieldZ), false);
            ArenaArt.Part("Raised rope edge", Root, Ring("Raised rope", .998f, 1f, 1, 144, .064f), plaster, Vector3.zero,
                new Vector3(BallPhysicsController.FieldX, 1, BallPhysicsController.FieldZ), false);
        }

        private Transform BuildBall()
        {
            Transform root = ArenaArt.Node("Red cricket ball", Root, Vector3.zero);
            float d = DeliveryTrajectory.Radius * 2;
            ArenaArt.Part("Crimson leather", root, Forms.Ball, art.Mat("Red leather", new Color(.92f, .10f, .115f)),
                new Vector3(0, -d * .5f, 0), Vector3.one * d, false);
            Mesh band = Ring("Ball seam", .96f, 1.015f, 1, 26, 0);
            Material cotton = art.Mat("Ball seam thread", new Color(1f, .88f, .68f));
            ArenaArt.Part("Seam A", root, band, cotton, new Vector3(0, .010f, 0), Vector3.one * DeliveryTrajectory.Radius, false);
            ArenaArt.Part("Seam B", root, band, cotton, new Vector3(0, -.010f, 0), Vector3.one * DeliveryTrajectory.Radius, false);
            return root;
        }

        private void BuildBowl()
        {
            var random = new System.Random(139);
            Material concrete = art.Mat("Structural concrete", Color.white, "Concrete", tile: 4);
            Material trim = art.Mat("Navy steel", ArenaArt.Navy);
            Material stripe = art.Mat("Gold painted steel", ArenaArt.Gold);
            Material bluePlastic = art.Mat("Blue seating", new Color(.18f, .48f, .67f));
            Material tealPlastic = art.Mat("Teal seating", new Color(.17f, .50f, .46f));
            Material[] fans = {
                art.Mat("Audience light shirts", new Color(.85f,.86f,.80f)),
                art.Mat("Audience blue shirts", new Color(.25f,.50f,.78f)),
                art.Mat("Audience ochre shirts", new Color(.92f,.62f,.26f)),
                art.Mat("Audience rose shirts", new Color(.63f,.29f,.31f))
            };

            const int sectors = 26;
            var hardware = new List<CombineInstance>();
            var railings = new List<CombineInstance>();
            var canopy = new List<CombineInstance>();
            var glazing = new List<CombineInstance>();
            var frame = new List<CombineInstance>();
            Material canopyMetal = art.Mat("Cool aluminium roof", new Color(.47f, .62f, .70f));
            Material blueGlass = art.Mat("Media deck glazing", new Color(.08f, .28f, .40f));
            var chairs = new[] { new List<CombineInstance>(), new List<CombineInstance>() };
            for (int section = 0; section < sectors; section++)
            {
                float start = (float)section / sectors * 2 * Mathf.PI;
                float end = (float)(section + 1) / sectors * 2 * Mathf.PI;
                float mid = (start + end) * .5f;
                Vector3 toField = -StadiumPoint(mid, 1, 1, 0).normalized;
                Quaternion along = Quaternion.LookRotation(-toField);
                Vector3 signCentre = StadiumPoint(mid, 44.5f, 50.5f, .80f);
                Box("Score-side board backing", Root, signCentre - toField * .04f, new Vector3(7.2f, 1.45f, .095f), trim, false).rotation = along;
                ArenaArt.Part("Ground sponsor sign", Root, Forms.Quad, boards[section % 4], signCentre + toField * .045f,
                    new Vector3(7f, 1.31f, 1), false).rotation = along;

                Vector3 tubePost = StadiumPoint(start, 53.2f, 59.2f, 3.65f);
                railings.Add(Combine(Forms.Box, tubePost, along, new Vector3(.20f, 7.3f, .22f)));
                for (int row = 0; row < 9; row++)
                {
                    float hx = 47.4f + row * 1.34f;
                    float hz = 53.4f + row * 1.34f;
                    float y = .48f + row * .72f;
                    Vector3 tread = StadiumPoint(mid, hx, hz, y);
                    float width = (StadiumPoint(end, hx, hz, y) - StadiumPoint(start, hx, hz, y)).magnitude;
                    bool aisle = row == 4;
                    hardware.Add(Combine(Forms.Box, tread, along, new Vector3(width * .99f, .36f, 1.46f)));
                    if (aisle) continue;
                    chairs[section % 2].Add(Combine(Forms.Box, tread + Vector3.up * .24f, along, new Vector3(width * .88f, .24f, .71f)));
                }

                var people = new[] { new List<CombineInstance>(), new List<CombineInstance>(), new List<CombineInstance>(), new List<CombineInstance>() };
                for (int row = 0; row < 9; row++)
                {
                    if (row == 4) continue;
                    float hx = 47.4f + row * 1.34f;
                    float hz = 53.4f + row * 1.34f;
                    float y = .77f + row * .72f;
                    for (int col = 1; col <= 11; col++)
                    {
                        if (random.NextDouble() < .23) continue;
                        float angle = Mathf.Lerp(start, end, (col + (float)random.NextDouble() * .24f) / 12);
                        Vector3 sitting = StadiumPoint(angle, hx, hz, y);
                        int kind = random.Next(4);
                        people[kind].Add(Combine(Forms.CrowdBody, sitting, along, new Vector3(.47f, .60f, .40f)));
                        people[kind].Add(Combine(Forms.CrowdHead, sitting + Vector3.up * .53f, along, new Vector3(.30f, .34f, .29f)));
                    }
                    if (row != 3 && row != 8) continue;
                    Transform parent = row == 3 ? crowd : highCrowd;
                    for (int i = 0; i < people.Length; i++)
                    {
                        Batch("Seated audience", parent, people[i], fans[i]);
                        people[i].Clear();
                    }
                }

                int pavilion = section % 13;
                if (pavilion >= 1 && pavilion <= 5)
                {
                    Vector3 pressBox = StadiumPoint(mid, 60.2f, 66.2f, 8.2f);
                    float span = (StadiumPoint(start, 60.2f, 66.2f, 0) - StadiumPoint(end, 60.2f, 66.2f, 0)).magnitude;
                    canopy.Add(Combine(Forms.Box, pressBox, along, new Vector3(span * .994f, 1.95f, 2.3f)));
                    glazing.Add(Combine(Forms.Box, pressBox + toField * 1.20f + Vector3.up * .14f, along,
                        new Vector3(span * .946f, 1.00f, .19f)));
                    Vector3 roof = pressBox + toField * 2.4f + Vector3.up * 1.76f;
                    canopy.Add(Combine(Forms.Box, roof, along * Quaternion.Euler(-6f, 0, 0),
                        new Vector3(span * 1.033f, .23f, 7.15f)));
                    int posts = 5;
                    for (int bay = 0; bay <= posts; bay++)
                    {
                        Vector3 post = pressBox + along * Vector3.right * ((bay / (float)posts - .5f) * span * .96f);
                        frame.Add(Combine(Forms.Box, post + toField * 1.28f, along, new Vector3(.13f, 2.10f, .19f)));
                    }
                    frame.Add(Combine(Forms.Box, roof + toField * 3.35f + Vector3.up * .25f, along,
                        new Vector3(span * 1.009f, .32f, .22f)));
                }

                if (section % 6 != 0) continue;
                Vector3 lamp = StadiumPoint(mid, 62f, 68f, 11.6f);
                Box("Floodlight mast", Root, lamp, new Vector3(.43f, 23.2f, .43f), trim).rotation = along;
                Box("Floodlight bank", Root, lamp + Vector3.up * 11.5f, new Vector3(4.7f, 1.45f, .52f), trim).rotation = along;
                Material lampFace = art.Mat("Floodlight porcelain", new Color(1f, .91f, .64f), flat: true);
                for (int i = -2; i <= 2; i++)
                    Box("Lamp cell", Root, lamp + Vector3.up * 11.5f + along * new Vector3(i * .88f, 0, -.29f),
                        new Vector3(.67f, .92f, .07f), lampFace, false).rotation = along;
            }
            Batch("Raked grandstand terraces", Root, hardware, concrete);
            Batch("Structural posts", Root, railings, stripe);
            Batch("Pavilion roof and press deck", Root, canopy, canopyMetal);
            Batch("Press deck glazing", Root, glazing, blueGlass);
            Batch("Pavilion metalwork", Root, frame, trim);
            Batch("Blue seating banks", Root, chairs[0], bluePlastic);
            Batch("Teal seating banks", Root, chairs[1], tealPlastic);

            Transform marquee = ArenaArt.Part("Christian Colony Arena marquee", Root, Forms.Quad, boards[0],
                new Vector3(0, 11.2f, 61.7f), new Vector3(24f, 4.5f, 1f), false);
            Box("Marquee support", Root, marquee.position + Vector3.forward * .31f, new Vector3(24.8f, 5.18f, .57f), trim);
            Box("Marquee truss", Root, marquee.position + new Vector3(0, -3.95f, .39f), new Vector3(18, 3.7f, .52f), concrete);
        }

        private static Vector3 StadiumPoint(float a, float rx, float rz, float y) =>
            new Vector3(Mathf.Sin(a) * rx, y, Mathf.Cos(a) * rz);

        private static Mesh Ring(string name, float inner, float outer, float aspect, int sides, float height)
        {
            var verts = new Vector3[(sides + 1) * 2];
            var uv = new Vector2[verts.Length];
            var tris = new int[sides * 6];
            for (int i = 0; i <= sides; i++)
            {
                float a = (float)i / sides * Mathf.PI * 2;
                int v = i * 2;
                Vector3 direction = new Vector3(Mathf.Cos(a), 0, Mathf.Sin(a) * aspect);
                verts[v] = direction * inner + Vector3.up * height;
                verts[v + 1] = direction * outer + Vector3.up * height;
                uv[v] = new Vector2(verts[v].x * .5f + .5f, verts[v].z * .5f + .5f);
                uv[v + 1] = new Vector2(verts[v + 1].x * .5f + .5f, verts[v + 1].z * .5f + .5f);
                if (i == sides) continue;
                int t = i * 6;
                tris[t] = v; tris[t + 1] = v + 2; tris[t + 2] = v + 1;
                tris[t + 3] = v + 1; tris[t + 4] = v + 2; tris[t + 5] = v + 3;
            }
            return Forms.Make(name, verts, tris, uv);
        }

        private static Transform Box(string name, Transform parent, Vector3 position, Vector3 size, Material material, bool shadow = true) =>
            ArenaArt.Part(name, parent, Forms.Box, material, position, size, shadow);

        private static CombineInstance Combine(Mesh mesh, Vector3 position, Quaternion rotation, Vector3 scale) =>
            new CombineInstance { mesh = mesh, transform = Matrix4x4.TRS(position, rotation, scale) };

        private static void Batch(string label, Transform parent, List<CombineInstance> parts, Material material)
        {
            if (parts.Count == 0) return;
            var mesh = new Mesh { name = label, indexFormat = IndexFormat.UInt32 };
            mesh.CombineMeshes(parts.ToArray(), true, true);
            ArenaArt.Part(label, parent, mesh, material, Vector3.zero, Vector3.one, false);
        }
    }

    internal sealed class Wickets
    {
        private readonly Transform[] bails = new Transform[2];
        public Wickets(Transform parent, ArenaArt art, Vector3 point)
        {
            Transform root = ArenaArt.Node("Wicket", parent, point);
            Material wood = art.Mat("Stump willow", new Color(.97f, .91f, .77f), "Willow");
            Material lacquer = art.Mat("Royal blue stump lacquer", new Color(.018f, .24f, .89f));
            Material trim = art.Mat("Gold wicket markings", new Color(1f, .70f, .19f));
            Material illuminated = art.Mat("Wicket light band", new Color(.34f, .75f, 1f), flat: true);
            for (int i = -1; i <= 1; i++)
            {
                ArenaArt.Part("Stump", root, Forms.Tube, lacquer, new Vector3(i * .128f, 0, 0), new Vector3(.052f, .745f, .052f));
                ArenaArt.Part("Gold wicket cap", root, Forms.Tube, trim, new Vector3(i * .128f, .707f, 0), new Vector3(.056f, .037f, .056f));
                ArenaArt.Part("Shoulder band", root, Forms.Tube, illuminated, new Vector3(i * .128f, .618f, 0),
                    new Vector3(.055f, .057f, .055f), false);
                ArenaArt.Part("Base band", root, Forms.Tube, trim, new Vector3(i * .128f, .083f, 0),
                    new Vector3(.055f, .035f, .055f), false);
            }
            for (int i = 0; i < bails.Length; i++)
                bails[i] = ArenaArt.Part("Bail " + i, root, Forms.Tube, wood, Vector3.zero, new Vector3(.026f, .153f, .029f));
            Animate(0);
        }

        public void Animate(float elapsed)
        {
            for (int i = 0; i < bails.Length; i++)
            {
                float sign = 2 * i - 1;
                float t = Mathf.Min(.63f, elapsed);
                float y = Mathf.Max(.035f, .745f + 1.22f * t - 4.20f * t * t);
                bails[i].localPosition = new Vector3(-.141f + .137f * i + sign * t * .48f, y, t * (.64f + i * .45f));
                bails[i].localRotation = Quaternion.Euler(t * (620 + i * 180), t * 360, -90 + t * sign * 720);
            }
        }
    }
}
