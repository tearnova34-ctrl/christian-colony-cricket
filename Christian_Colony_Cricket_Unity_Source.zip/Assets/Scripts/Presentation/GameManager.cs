using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class GameManager
    {
        private static readonly TeamManager Teams = new TeamManager();
        private static MatchManager finished;
        private readonly string screen;
        private readonly ArenaArt art;
        private readonly Stadium stadium;
        private readonly CameraController camera;
        private readonly SettingsManager settings;
        private readonly AudioManager audio;
        private readonly UIManager ui;
        private readonly PlayerCharacter[] roster = new PlayerCharacter[8];
        private readonly MatchManager match;
        private readonly ArenaMatchView matchView;
        private readonly ScoreboardController scoreboard;
        private readonly MatchCommentary commentary;
        private readonly Transform owner;
        private RectTransform menuPanel, settingsPanel, teamList;
        private MissionMenu missions;
        private WinConfetti confetti;
        private Vector2 pointerStart;
        private bool paused, tracking;
        private int finger = -1, selectedTeam = -1, selectedSlot = -1;

        public GameManager(Transform owner)
        {
            this.owner = owner;
            screen = SceneManager.GetActiveScene().name;
            if (screen == "MatchResult" && finished == null)
            {
                Load("MainMenu");
                return;
            }
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Input.simulateMouseWithTouches = false;
            settings = new SettingsManager();
            settings.ApplyGraphics();
            art = new ArenaArt();
            stadium = new Stadium(art);
            stadium.Quality(settings.Quality);
            camera = new CameraController(owner);
            audio = new AudioManager(owner, settings, screen != "CricketMatch");
            ui = new UIManager(owner, audio);
            PopulateRoster();

            switch (screen)
            {
                case "CricketMatch":
                    match = new MatchManager(Teams, settings.RollMission(), System.Environment.TickCount);
                    matchView = new ArenaMatchView(stadium, roster, match);
                    commentary = new MatchCommentary(owner, match, settings);
                    scoreboard = new ScoreboardController(ui, match, TogglePause, TogglePause, () => Load("MainMenu"));
                    match.Changed += MatchChanged;
                    match.Swing += _ => audio.Play("Bat", .71f);
                    match.Bounce += () => audio.Play("Bounce", .61f);
                    match.Release += () => audio.Play("Release", .46f);
                    match.Decided += OnDecision;
                    matchView.Draw();
                    camera.ShowMatch();
                    break;
                case "TeamSelection": TeamsScreen(); break;
                case "MatchResult": ResultScreen(); break;
                default: MenuScreen(); break;
            }

            if (match == null)
            {
                if (screen == "MatchResult") camera.ShowResult();
                else camera.ShowMenu(screen == "TeamSelection");
            }
        }

        public void Update()
        {
            if (ui == null) return;
            ui.InsetSafeArea();
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (match != null) TogglePause();
                else if (missions != null && missions.IsOpen) missions.Close();
                else if (screen != "MainMenu") Load("MainMenu");
                else if (settingsPanel != null && settingsPanel.gameObject.activeSelf) ToggleSettings(false);
            }

            if (match == null)
            {
                if (screen == "MatchResult") camera.ShowResult();
                else camera.ShowMenu(screen == "TeamSelection");
                AnimateLineup();
                confetti?.Draw();
                return;
            }

            if (!paused)
            {
                ReadPointer();
                match.Tick(Time.deltaTime);
            }
            audio.MixCommentary(commentary.Speaking);
            scoreboard.Draw(paused);
            if (!paused) matchView.Draw();
        }

        private void MatchChanged()
        {
            if (match.Phase == PlayPhase.Ready)
            {
                tracking = false;
                finger = -1;
            }
            if (match.Phase != PlayPhase.Finished) return;
            finished = match;
            Load("MatchResult");
        }

        private void OnDecision(DeliveryResult result)
        {
            if (result.Call == BallCall.Bowled) audio.Play("Stumps", .43f);
            if (result.Runs >= 4) audio.Play("Cheer", .33f);
        }

        private void TogglePause()
        {
            if (match.Phase == PlayPhase.Finished) return;
            paused = !paused;
            tracking = false;
            finger = -1;
            commentary.SetPaused(paused);
        }

        private void ReadPointer()
        {
            if (Input.touchCount > 0)
            {
                for (int i = 0; i < Input.touchCount; i++)
                {
                    Touch touch = Input.GetTouch(i);
                    if (touch.phase == TouchPhase.Began && !tracking) BeginPointer(touch.position, touch.fingerId);
                    if (!tracking || touch.fingerId != finger) continue;
                    if (touch.phase == TouchPhase.Ended) EndPointer(touch.position);
                    if (touch.phase == TouchPhase.Canceled) tracking = false;
                }
                return;
            }
#if UNITY_EDITOR || UNITY_STANDALONE
            if (Input.GetMouseButtonDown(0)) BeginPointer(Input.mousePosition, -1);
            if (Input.GetMouseButtonUp(0) && tracking) EndPointer(Input.mousePosition);
#endif
        }

        private void BeginPointer(Vector2 position, int id)
        {
            if (match.Phase != PlayPhase.RunUp && match.Phase != PlayPhase.Delivery) return;
            if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(id)) return;
            Rect area = Screen.safeArea;
            float y = (position.y - area.yMin) / area.height;
            if (y < .105f || y > .862f) return;
            pointerStart = position;
            tracking = true;
            finger = id;
        }

        private void EndPointer(Vector2 position)
        {
            match.SubmitSwipe(pointerStart, position, Screen.width, Time.deltaTime);
            tracking = false;
            finger = -1;
        }

        private void PopulateRoster()
        {
            for (int team = 0; team < 2; team++)
            {
                for (int slot = 0; slot < 4; slot++) CreatePlayer(team, slot);
            }
        }

        private void CreatePlayer(int team, int slot)
        {
            int id = Teams.PlayerId(team, slot);
            if (roster[id] != null)
            {
                roster[id].Root.gameObject.SetActive(false);
                Object.Destroy(roster[id].Root.gameObject);
            }
            roster[id] = new PlayerCharacter(stadium.Root, art, CharacterDatabase.Players[id].Name, id, team, CharacterDatabase.Players[id]);
            roster[id].Root.gameObject.SetActive(false);
        }

        private void MenuScreen()
        {
            Transform screenRoot = ui.Safe;
            ui.Graphic(screenRoot, new Rect(0, 0, 1, .48f), "Fade");
            ui.Graphic(screenRoot, new Rect(0, .53f, 1, .47f), "Fade", flipped: true);
            menuPanel = UIManager.RectNode("Main menu", screenRoot, new Rect(0, 0, 1, 1));
            ui.Graphic(menuPanel, new Rect(.347f, .036f, .306f, .160f), "Crest", fitted: true);
            ui.Label(menuPanel, new Rect(.06f, .208f, .88f, .059f), "CHRISTIAN COLONY", 36, UIManager.Ivory);
            ui.Label(menuPanel, new Rect(.07f, .259f, .86f, .085f), "CRICKET", 70, UIManager.Gold);
            ui.Panel(menuPanel, new Rect(.352f, .354f, .296f, .0045f), UIManager.Gold, false);

            RectTransform actions = ui.Panel(menuPanel, new Rect(.062f, .666f, .876f, .267f), UIManager.Ink);
            ui.Button(actions, new Rect(.059f, .111f, .882f, .323f), "PLAY MISSION", UIManager.Gold, UIManager.Ink,
                OpenMissions, 27);
            ui.Button(actions, new Rect(.059f, .506f, .882f, .199f), "SELECT PLAYERS", UIManager.PanelTint, UIManager.Ivory,
                () => Load("TeamSelection"));
            ui.Button(actions, new Rect(.059f, .756f, .882f, .167f), "SETTINGS", UIManager.PanelTint, UIManager.Ivory,
                () => ToggleSettings(true), 17);
            ui.Label(menuPanel, new Rect(.10f, .95f, .8f, .028f), "CHRISTIAN COLONY ARENA", 12, UIManager.Muted);
            BuildSettings();
            ShowSolo(Teams.PlayerId(0, 0), Teams.PlayerId(1, 0));
        }

        private void OpenMissions()
        {
            if (missions == null) missions = new MissionMenu(ui, settings, () => Load("CricketMatch"));
            missions.Open();
        }

        private void BuildSettings()
        {
            settingsPanel = ui.Panel(ui.Safe, new Rect(.054f, .245f, .892f, .512f), UIManager.Ink);
            ui.Label(settingsPanel, new Rect(.075f, .043f, .85f, .088f), "SETTINGS", 37, UIManager.Gold);
            SettingsRow(.203f, "Effects", () => settings.Sound ? "ON" : "OFF",
                () => { settings.Sound = !settings.Sound; audio.Sync(); });
            SettingsRow(.347f, "Commentary", () => settings.Commentary ? "ON" : "OFF",
                () => settings.Commentary = !settings.Commentary);
            SettingsRow(.491f, "Menu music", () => settings.Music ? "ON" : "OFF",
                () => { settings.Music = !settings.Music; audio.Sync(); });
            SettingsRow(.635f, "Graphics", () => SettingsManager.QualityNames[settings.Quality].ToUpperInvariant(),
                () => { settings.Quality = (settings.Quality + 1) % 3; settings.ApplyGraphics(); stadium.Quality(settings.Quality); });
            ui.Button(settingsPanel, new Rect(.14f, .852f, .72f, .098f), "DONE", UIManager.Gold, UIManager.Ink, () => ToggleSettings(false));
            settingsPanel.gameObject.SetActive(false);
        }

        private void SettingsRow(float y, string caption, System.Func<string> value, System.Action update)
        {
            RectTransform tile = ui.Panel(settingsPanel, new Rect(.063f, y, .874f, .098f), UIManager.PanelTint);
            ui.Label(tile, new Rect(.059f, 0, .44f, 1), caption, 19, UIManager.Ivory, false, TextAnchor.MiddleLeft);
            Text output = null;
            ui.Button(tile, new Rect(.50f, .08f, .47f, .84f), value(), UIManager.Ink, UIManager.Gold,
                () => { update(); output.text = value(); settings.Save(); }, out output, 16);
        }

        private void ToggleSettings(bool show)
        {
            menuPanel.gameObject.SetActive(!show);
            settingsPanel.gameObject.SetActive(show);
        }

        private void TeamsScreen()
        {
            Transform root = ui.Safe;
            ui.Graphic(root, new Rect(0, 0, 1, .37f), "Fade");
            ui.Graphic(root, new Rect(0, .45f, 1, .55f), "Fade", flipped: true);
            ui.Button(root, new Rect(.038f, .03f, .22f, .052f), "‹  MENU", UIManager.Ink, UIManager.Ivory, () => Load("MainMenu"), 15);
            ui.Label(root, new Rect(.06f, .116f, .88f, .065f), "SELECT PLAYERS", 37, UIManager.Ivory);
            ui.Label(root, new Rect(.085f, .18f, .83f, .042f), "Swap a player into the top batting or bowling slot.", 16, UIManager.Ivory, false);
            ui.Button(root, new Rect(.069f, .89f, .862f, .065f), "PLAY MISSION", UIManager.Gold, UIManager.Ink,
                OpenMissions, 23);
            ShowSolo(Teams.PlayerId(0, 0), Teams.PlayerId(1, 0));
            DrawTeams();
        }

        private void DrawTeams()
        {
            if (teamList)
            {
                teamList.gameObject.SetActive(false);
                Object.Destroy(teamList.gameObject);
            }
            teamList = ui.Panel(ui.Safe, new Rect(.053f, .497f, .894f, .367f), UIManager.Ink);
            for (int team = 0; team < 2; team++)
            {
                int selectionTeam = team;
                float x = team == 0 ? .044f : .519f;
                Color accent = team == 0 ? UIManager.Blue : UIManager.Gold;
                ui.Label(teamList, new Rect(x, .047f, .437f, .11f), team == 0 ? "COLONY BLUE" : "COLONY GOLD", 18, accent);
                for (int slot = 0; slot < 4; slot++)
                {
                    int selectionSlot = slot;
                    Cricketer player = Teams.Player(team, slot);
                    bool selected = team == selectedTeam && slot == selectedSlot;
                    Color tile = selected ? accent : UIManager.PanelTint;
                    Color ink = selected ? UIManager.Ink : UIManager.Ivory;
                    Button pick = ui.Button(teamList, new Rect(x, .188f + slot * .184f, .437f, .162f), "", tile, ink,
                        () => Pick(selectionTeam, selectionSlot));
                    Transform card = pick.transform;
                    ui.Label(card, new Rect(.073f, .09f, .85f, .55f), player.Name, 20, ink, alignment: TextAnchor.MiddleLeft);
                    string handed = player.LeftHanded ? "LH" : "RH";
                    ui.Label(card, new Rect(.073f, .63f, .89f, .26f), handed + "  ·  " + CharacterDatabase.DeliveryName(player.Deliveries[0]), 12,
                        selected ? UIManager.Ink : UIManager.Muted, false, TextAnchor.MiddleLeft);
                }
            }
        }

        private void Pick(int team, int slot)
        {
            if (selectedTeam < 0)
            {
                selectedTeam = team;
                selectedSlot = slot;
                ShowSolo(Teams.PlayerId(0, team == 0 ? slot : 0), Teams.PlayerId(1, team == 1 ? slot : 0));
            }
            else
            {
                if (team != selectedTeam || slot != selectedSlot)
                {
                    Teams.SwapPlayers(selectedTeam, selectedSlot, team, slot);
                    CreatePlayer(selectedTeam, selectedSlot);
                    CreatePlayer(team, slot);
                }
                selectedTeam = selectedSlot = -1;
                ShowSolo(Teams.PlayerId(0, 0), Teams.PlayerId(1, 0));
            }
            DrawTeams();
        }

        private void ShowSolo(int blue, int gold)
        {
            foreach (PlayerCharacter actor in roster) actor.Root.gameObject.SetActive(false);
            PlayerCharacter first = roster[blue];
            PlayerCharacter second = roster[gold];
            first.Root.gameObject.SetActive(true);
            second.Root.gameObject.SetActive(true);
            bool selection = screen == "TeamSelection";
            first.Root.position = new Vector3(-.80f, 0, selection ? -5.25f : -8.6f);
            second.Root.position = new Vector3(1.25f, 0, selection ? -4.98f : -5.3f);
            first.Root.rotation = Quaternion.Euler(0, selection ? 163 : 9, 0);
            second.Root.rotation = Quaternion.Euler(0, selection ? 188 : 207, 0);
            first.Dress(!selection);
            second.Dress(false);
        }

        private void ResultScreen()
        {
            Transform root = ui.Safe;
            ui.Graphic(root, new Rect(0, 0, 1, .535f), "Fade");
            ui.Graphic(root, new Rect(0, .46f, 1, .54f), "Fade", flipped: true);
            bool won = finished.Rules.Won;
            Color accent = won ? UIManager.Gold : UIManager.Red;
            if (won) confetti = new WinConfetti(ui);
            ui.Graphic(root, new Rect(.37f, .038f, .26f, .13f), "Crest", fitted: true);
            ui.Label(root, new Rect(.062f, .179f, .876f, .09f), won ? "MISSION WON" : "MISSION LOST", 45, accent);
            RectTransform panel = ui.Panel(root, new Rect(.073f, .53f, .854f, .397f), UIManager.Ink);
            ui.Label(panel, new Rect(.065f, .052f, .87f, .105f),
                finished.Mission.Overs + " OV  ·  " + finished.Mission.Difficulty.ToString().ToUpperInvariant(), 15, UIManager.Muted);
            ui.Label(panel, new Rect(.065f, .16f, .87f, .21f), finished.Rules.Runs + "/" + finished.Rules.Wickets, 60, UIManager.Ivory);
            ui.Label(panel, new Rect(.065f, .373f, .87f, .10f),
                "TARGET " + finished.Rules.Target + "  ·  " + finished.Rules.Balls + " BALLS FACED", 16, UIManager.Muted);
            string summary = won
                ? (finished.Rules.BallLimit - finished.Rules.Balls) + " BALLS LEFT"
                : finished.Rules.Remaining + (finished.Rules.Remaining == 1 ? " RUN SHORT" : " RUNS SHORT");
            ui.Label(panel, new Rect(.065f, .479f, .87f, .09f), summary, 16, accent);
            ui.Button(panel, new Rect(.085f, .614f, .83f, .14f), "PLAY AGAIN", UIManager.Gold, UIManager.Ink,
                () => Load("CricketMatch"), 23);
            ui.Button(panel, new Rect(.085f, .793f, .83f, .134f), "MAIN MENU", UIManager.PanelTint, UIManager.Ivory,
                () => Load("MainMenu"));

            PlayerCharacter batter = roster[finished.StrikerId];
            batter.Root.position = new Vector3(0f, 0f, -4.25f);
            batter.Root.rotation = Quaternion.Euler(0f, 173f, 0f);
            batter.Root.gameObject.SetActive(true);
            if (won)
            {
                audio.Play("Victory", .75f);
                audio.Play("Cheer", .55f);
            }
            else audio.Play("MissionLost", .65f);
        }

        private void AnimateLineup()
        {
            for (int i = 0; i < roster.Length; i++)
                if (roster[i].Root.gameObject.activeSelf)
                    roster[i].Act(screen == "MatchResult" ? (finished.Rules.Won ? ActorPose.Celebrate : ActorPose.Regroup) : screen == "MainMenu" && i == Teams.PlayerId(0, 0) ?
                        ActorPose.Stance : ActorPose.Idle, Time.time + i * .28f, CharacterDatabase.Players[i].LeftHanded);
        }

        private static void Load(string scene) => SceneManager.LoadScene(scene, LoadSceneMode.Single);
    }
}
