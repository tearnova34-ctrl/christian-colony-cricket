using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class GameManager
    {
        private static readonly TeamManager Teams = new TeamManager();
        private static MatchSession finished;
        private readonly string screen;
        private readonly ArenaArt art;
        private readonly Stadium stadium;
        private readonly CameraController camera;
        private readonly SettingsManager settings;
        private readonly AudioManager audio;
        private readonly UIManager ui;
        private readonly PlayerCharacter[] roster = new PlayerCharacter[8];
        private readonly MatchManager match;
        private readonly MatchSession session;
        private readonly ArenaMatchView matchView;
        private readonly ScoreboardController scoreboard;
        private readonly MatchCommentary commentary;
        private readonly ReplayOverlay playback;
        private MatchStatsOverlay scorecard;
        private int cameraShot;
        private bool cameraEnd, fiftyCheered;
        private readonly Transform owner;
        private RectTransform menuPanel, settingsPanel, settingsCard, teamList, tossLayer, tossChoices, inningsLayer, resultPanel;
        private MissionMenu quickMenu, competitionMenu;
        private CaptainCeremony ceremony;
        private BowlingAim bowlingAim;
        private bool leavingMatch, announced, resultCheered;
        private Text tossStatus;
        private HighScoresMenu highScores;
        private WinConfetti confetti;
        private Vector2 pointerStart;
        private bool paused, tracking;
        private int finger = -1, selectedTeam = -1, selectedSlot = -1;

        public GameManager(Transform owner)
        {
            this.owner = owner;
            screen = SceneManager.GetActiveScene().name;
            if (screen == "MatchResult" && finished == null)
            {
                Load("MainMenu");
                return;
            }
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Input.simulateMouseWithTouches = false;
            settings = new SettingsManager();
            settings.ApplyGraphics();
            art = new ArenaArt();
            stadium = new Stadium(art);
            stadium.Quality(settings.Quality);
            camera = new CameraController(owner);
            audio = new AudioManager(owner, settings, screen != "CricketMatch");
            ui = new UIManager(owner, audio);
            PopulateRoster();

            switch (screen)
            {
                case "CricketMatch":
                    session = MatchSave.Read();
                    if (session == null)
                    {
                        Load("MainMenu");
                        return;
                    }
                    RestoreCaptainKits(session);
                    match = MatchManager.Resume(session);
                    bowlingAim = match.Rules.Deliveries == 0 && match.Phase == PlayPhase.Ready
                        ? match.StumpsAim(match.Bowler.Deliveries[0], false) : match.Aim;
                    bowlingAim.SpeedScale = 1f;
                    int partner = Teams.PlayerId(session.BattingTeam, 1);
                    if (partner == match.StrikerId || partner == match.BowlerId)
                        partner = System.Array.FindIndex(roster, r => r != roster[match.StrikerId] && r != roster[match.BowlerId]);
                    if (match.Competition) BuildPlayer(partner, session.BattingTeam);
                    matchView = new ArenaMatchView(stadium, art, roster, match, session.BattingTeam, partner);
                    commentary = new MatchCommentary(owner, settings);
                    scoreboard = new ScoreboardController(ui, match, session, TogglePause, TogglePause, SuspendMission,
                        CycleDelivery, SwitchCrease, Bowl, ReleaseBowl, PlayLastBall, RequestReview, OpenScorecard, () => bowlingAim);
                    playback = new ReplayOverlay(ui, matchView, camera, CloseReplay);
                    match.Changed += MatchChanged;
                    match.Swing += _ => audio.Play("Bat", .71f);
                    match.Bounce += () => audio.Play("Bounce", .61f);
                    match.Release += () => audio.Play("Release", .46f);
                    match.Decided += OnDecision;
                    matchView.Draw(match.UserBowls ? bowlingAim : (BowlingAim?)null);
                    camera.ShowMatch(match.UserBowls, match.ReverseEnd);
                    cameraEnd = match.ReverseEnd;
                    if (session.Interval) OpenInningsBreak();
                    break;
                case "TeamSelection": TeamsScreen(); break;
                case "MatchResult": ResultScreen(); break;
                default: MenuScreen(); break;
            }

            if (match == null)
            {
                if (ceremony != null) camera.ShowCeremony();
                else if (screen == "MatchResult") camera.ShowResult();
                else camera.ShowMenu(screen == "TeamSelection");
            }
        }

        public void Update()
        {
            if (ui == null || leavingMatch) return;
            ui.InsetSafeArea();
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (scorecard != null && scorecard.Active) CloseScorecard();
                else if (playback != null && playback.Active) CloseReplay();
                else if (match != null)
                {
                    if (paused || session.Interval) SuspendMission();
                    else TogglePause();
                }
                else if (tossLayer != null && tossLayer.gameObject.activeSelf) CloseToss();
                else if (highScores != null && highScores.IsOpen) highScores.Close();
                else if (quickMenu != null && quickMenu.IsOpen) quickMenu.Close();
                else if (competitionMenu != null && competitionMenu.IsOpen) competitionMenu.Close();
                else if (screen != "MainMenu") Load("MainMenu");
                else if (settingsPanel != null && settingsPanel.gameObject.activeSelf) ToggleSettings(false);
            }

            if (scorecard != null && scorecard.Active) return;

            if (match == null)
            {
                if (ceremony != null)
                {
                    camera.ShowCeremony(ceremony.Elapsed);
                    ceremony.Draw();
                    if (tossChoices != null)
                    {
                        tossChoices.gameObject.SetActive(ceremony.Elapsed >= CaptainCeremony.TossDuration);
                        if (tossStatus != null) UIManager.SetText(tossStatus, ceremony.Elapsed < 2.4f ? "CAPTAINS AT THE CREASE"
                            : ceremony.Elapsed < 5.1f ? "COIN IN THE AIR" : "THE TOSS IS DECIDED");
                    }
                    if (resultPanel != null)
                    {
                        bool ready = ceremony.Elapsed >= CaptainCeremony.ResultDuration;
                        resultPanel.gameObject.SetActive(ready);
                        if (ready && !resultCheered) PlayResultSound();
                        if (ready && confetti != null) confetti.Draw();
                    }
                    return;
                }
                if (screen == "MatchResult") camera.ShowResult();
                else camera.ShowMenu(screen == "TeamSelection");
                AnimateLineup();
                confetti?.Draw();
                return;
            }

            if (playback.Active)
            {
                scoreboard.Draw(paused, session.Interval, true);
                playback.Draw();
                return;
            }

            if (!paused && !session.Interval)
            {
                ReadPointer();
                match.Tick(Time.deltaTime);
            }
            audio.MixCommentary(commentary.Speaking);
            scoreboard.Draw(paused, session.Interval, false);
            if (!paused)
            {
                bool fieldCamera = match.Competition && match.Phase == PlayPhase.Decision && match.ShotVelocity.sqrMagnitude > .05f &&
                    match.PhaseTime >= .57f && match.PhaseTime < match.RevealAt + .62f &&
                    (match.BallPosition - match.ContactPosition).sqrMagnitude > 8f;
                bool reversed = match.ReverseEnd;
                int shot = match.ShowingFifty ? 3 : match.ShowingUmpire ? 2 : fieldCamera ? 1 : 0;
                switch (shot)
                {
                    case 3:
                        camera.ShowFifty(match.BattingGuard, reversed, cameraShot != shot);
                        if (!fiftyCheered)
                        {
                            audio.Play("Cheer", .64f);
                            fiftyCheered = true;
                        }
                        break;
                    case 2: camera.ShowUmpire(reversed, cameraShot != shot); break;
                    case 1: camera.FollowField(match.BallPosition, reversed); break;
                    default: camera.ShowMatch(match.UserBowls, reversed, cameraEnd != reversed || cameraShot >= 2); break;
                }
                cameraShot = shot;
                cameraEnd = reversed;
                matchView.Draw(match.UserBowls ? bowlingAim : (BowlingAim?)null);
                if (!announced && match.Phase == PlayPhase.Decision && match.PhaseTime >= match.RevealAt)
                {
                    announced = true;
                    AnnounceOutcome(match.LastResult);
                }
            }
        }

        private void MatchChanged()
        {
            if (match.Phase == PlayPhase.Ready)
            {
                tracking = false;
                finger = -1;
            }
            if (match.Phase != PlayPhase.Finished || leavingMatch) return;
            leavingMatch = true;
            session.Round = match.Capture();
            if (session.Competition && !session.SecondInnings)
            {
                session.StartChase();
                MatchSave.Write(session);
                Load("CricketMatch");
                return;
            }

            finished = session;
            if (!session.Competition) ChaseHighScores.Record(match.Mission, match.Rules);
            MatchSave.Clear();
            Load("MatchResult");
        }

        private void OnDecision(DeliveryResult result)
        {
            announced = fiftyCheered = false;
            SaveActiveMatch();
        }

        private void AnnounceOutcome(DeliveryResult result)
        {
            if (result.Call == BallCall.Bowled) audio.Play("Stumps", .43f);
            if (result.Wicket || result.Runs >= 4) audio.Play("Cheer", result.Runs == 6 ? .52f : .34f);
            commentary.Announce(result);
        }

        private void OpenScorecard()
        {
            MatchSession statsSession = match != null ? session : finished;
            if (statsSession == null || (playback != null && playback.Active)) return;
            if (scorecard == null) scorecard = new MatchStatsOverlay(ui, CloseScorecard);
            tracking = false;
            finger = -1;
            commentary?.SetPaused(true);
            scorecard.Open(statsSession, match);
        }

        private void CloseScorecard()
        {
            scorecard.Close();
            commentary?.SetPaused(paused || session.Interval);
        }

        private void PlayLastBall()
        {
            if (match.LastReplay == null || session.Interval) return;
            playback.Start(match.LastReplay, false, false);
            tracking = false;
            commentary.SetPaused(true);
        }

        private void RequestReview()
        {
            if (!match.CanReview || match.LastReplay == null) return;
            bool overturned = match.Review();
            SaveActiveMatch();
            playback.Start(match.LastReplay, true, overturned);
            tracking = false;
            commentary.SetPaused(true);
        }

        private void CloseReplay()
        {
            playback.Close();
            commentary.SetPaused(paused);
        }

        public void OnApplicationPause(bool background)
        {
            if (!background || match == null || leavingMatch) return;
            if (!paused && !session.Interval) TogglePause();
            else SaveActiveMatch();
        }

        public void SaveActiveMatch()
        {
            if (match == null || leavingMatch) return;
            session.Round = match.Capture();
            MatchSave.Write(session);
        }

        private void TogglePause()
        {
            if (match.Phase == PlayPhase.Finished || session.Interval) return;
            paused = !paused;
            tracking = false;
            finger = -1;
            commentary.SetPaused(paused);
            if (paused) SaveActiveMatch();
        }

        private void SuspendMission()
        {
            if ((!paused && !session.Interval) || leavingMatch) return;
            SaveActiveMatch();
            leavingMatch = true;
            Load("MainMenu");
        }

        private static void ResumeMission()
        {
            if (MatchSave.Read() != null) Load("CricketMatch");
        }

        private static void BeginMatch(MatchSession matchSession)
        {
            MatchSave.Write(matchSession);
            Load("CricketMatch");
        }

        private void StartQuickMatch() =>
            BeginMatch(MatchSession.Create(Teams, settings.RollMission(), System.Environment.TickCount));

        private void OpenInningsBreak()
        {
            RectTransform card = ui.Modal("Innings break", .34f, Palette.Australia, out inningsLayer);
            ui.Label(card, new Rect(.08f, .07f, .84f, .16f), "INNINGS BREAK", 32, UIManager.Ivory);
            ui.Label(card, new Rect(.07f, .249f, .86f, .14f),
                MatchSession.Team(session.BattingFirst) + "  " + session.FirstScore.Score, 22, UIManager.Gold);
            ui.Label(card, new Rect(.08f, .38f, .84f, .15f),
                MatchSession.Team(session.BattingTeam) + " NEED " + match.Rules.Target + " TO WIN", 20, UIManager.Ivory);
            ui.Button(card, new Rect(.09f, .575f, .82f, .17f), match.UserBowls ? "START BOWLING" : "START CHASE",
                UIManager.Gold, UIManager.Ink, () =>
                {
                    session.Interval = false;
                    inningsLayer.gameObject.SetActive(false);
                    SaveActiveMatch();
                }, 22);
            ui.Button(card, new Rect(.09f, .79f, .39f, .14f), "SCORECARD", UIManager.PanelTint, UIManager.Ivory, OpenScorecard, 15);
            ui.Button(card, new Rect(.52f, .79f, .39f, .14f), "SAVE & EXIT", UIManager.PanelTint, UIManager.Ivory, SuspendMission, 15);
        }

        private void CycleDelivery()
        {
            if (match.Phase != PlayPhase.Ready || paused || session.Interval) return;
            DeliveryType[] available = match.Bowler.Deliveries;
            int index = System.Array.IndexOf(available, bowlingAim.Type);
            bowlingAim = match.StumpsAim(available[(index + 1) % available.Length], bowlingAim.Around);
        }

        private void SwitchCrease()
        {
            if (match.Phase != PlayPhase.Ready || paused || session.Interval) return;
            bowlingAim = match.StumpsAim(bowlingAim.Type, !bowlingAim.Around);
        }

        private void ReleaseBowl()
        {
            if (paused || session.Interval) return;
            match.LockRelease();
            SaveActiveMatch();
        }

        private void Bowl()
        {
            if (!match.UserBowls || match.Phase != PlayPhase.Ready || paused || session.Interval) return;
            match.StartBowl(bowlingAim);
            SaveActiveMatch();
        }

        private void ReadPointer()
        {
            if (Input.touchCount > 0)
            {
                for (int i = 0; i < Input.touchCount; i++)
                {
                    Touch touch = Input.GetTouch(i);
                    if (touch.phase == TouchPhase.Began && !tracking) BeginPointer(touch.position, touch.fingerId);
                    if (!tracking || touch.fingerId != finger) continue;
                    if (touch.phase == TouchPhase.Moved && match.UserBowls) AimFromPointer(touch.position);
                    if (touch.phase == TouchPhase.Ended) EndPointer(touch.position);
                    if (touch.phase == TouchPhase.Canceled) tracking = false;
                }
                return;
            }
#if UNITY_EDITOR || UNITY_STANDALONE
            if (Input.GetMouseButtonDown(0)) BeginPointer(Input.mousePosition, -1);
            if (Input.GetMouseButton(0) && tracking && match.UserBowls) AimFromPointer(Input.mousePosition);
            if (Input.GetMouseButtonUp(0) && tracking) EndPointer(Input.mousePosition);
#endif
        }

        private void BeginPointer(Vector2 position, int id)
        {
            if (match.UserBowls ? match.Phase != PlayPhase.Ready :
                match.Phase != PlayPhase.RunUp && match.Phase != PlayPhase.Delivery) return;
            if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(id)) return;
            Rect area = Screen.safeArea;
            float y = (position.y - area.yMin) / area.height;
            if (y < .105f || y > .862f) return;
            pointerStart = position;
            tracking = true;
            finger = id;
            if (match.UserBowls) AimFromPointer(position);
        }

        private void AimFromPointer(Vector2 position)
        {
            Rect area = Screen.safeArea;
            float x = (position.x - area.center.x) / area.width;
            float y = (position.y - area.yMin) / area.height;
            bool around = bowlingAim.Around;
            bowlingAim = BowlingController.Aim(bowlingAim.Type, new Vector2(-x * 4.25f,
                Mathf.Lerp(.8f, -8.03f, (y - .19f) / .59f)), false);
            bowlingAim.Around = around;
        }

        private void EndPointer(Vector2 position)
        {
            if (match.UserBowls) AimFromPointer(position);
            else match.SubmitSwipe(pointerStart, position, Screen.width, Time.deltaTime);
            tracking = false;
            finger = -1;
        }

        private void PopulateRoster()
        {
            for (int team = 0; team < 2; team++)
            {
                for (int slot = 0; slot < 4; slot++) CreatePlayer(team, slot);
            }
        }

        private void CreatePlayer(int team, int slot)
        {
            BuildPlayer(Teams.PlayerId(team, slot), team);
        }

        private void RestoreCaptainKits(MatchSession saved)
        {
            BuildPlayer(saved.PakistanCaptain, 0);
            BuildPlayer(saved.IndiaCaptain, 1);
        }

        private void BuildPlayer(int id, int team)
        {
            if (roster[id] != null)
            {
                roster[id].Root.gameObject.SetActive(false);
                Object.Destroy(roster[id].Root.gameObject);
            }
            roster[id] = new PlayerCharacter(stadium.Root, art, CharacterDatabase.Players[id].Name, id, team, CharacterDatabase.Players[id]);
            roster[id].Root.gameObject.SetActive(false);
        }

        private void MenuScreen()
        {
            Transform screenRoot = ui.Safe;
            ui.Graphic(screenRoot, new Rect(0, 0, 1, .48f), "Fade");
            ui.Graphic(screenRoot, new Rect(0, .53f, 1, .47f), "Fade", flipped: true);
            menuPanel = UIManager.RectNode("Main menu", screenRoot, new Rect(0, 0, 1, 1));
            ui.Graphic(menuPanel, new Rect(.347f, .036f, .306f, .160f), "Crest", fitted: true);
            ui.Label(menuPanel, new Rect(.06f, .208f, .88f, .059f), "CHRISTIAN COLONY", 36, UIManager.Ivory);
            ui.Label(menuPanel, new Rect(.07f, .259f, .86f, .085f), "CRICKET", 70, UIManager.Gold);
            ui.Panel(menuPanel, new Rect(.352f, .354f, .296f, .0045f), UIManager.Gold, false);
            ui.Graphic(menuPanel, new Rect(.04f, .379f, .92f, .201f), "AvatarStadium", fitted: true);

            bool canResume = MatchSave.Read() != null;
            RectTransform actions = ui.Card(menuPanel,
                canResume ? new Rect(.062f, .594f, .876f, .342f) : new Rect(.062f, .645f, .876f, .291f),
                Palette.Australia);
            float offset = canResume ? .227f : 0f;
            if (canResume)
                ui.Button(actions, new Rect(.059f, .066f, .882f, .175f), "RESUME MATCH",
                    new Color(.51f, .91f, .66f), UIManager.Ink, ResumeMission, 24);
            ui.Button(actions, new Rect(.059f, .088f + offset, .882f, canResume ? .15f : .224f),
                "QUICK MATCH", new Color(.10f, .38f, .275f), UIManager.Ivory, () => OpenMissions(false), 24);
            ui.Button(actions, new Rect(.059f, canResume ? .505f : .355f, .882f, canResume ? .15f : .205f),
                "COMPETITION", new Color(.14f, .25f, .47f), UIManager.Ivory, () => OpenMissions(true), 23);
            ui.Button(actions, new Rect(.059f, canResume ? .697f : .626f, .882f, canResume ? .109f : .125f),
                "TOP CHASES", UIManager.PanelTint, UIManager.Gold, OpenHighScores, 16);
            ui.Button(actions, new Rect(.059f, .84f, .53f, .105f), "SELECT PLAYERS", UIManager.PanelTint,
                UIManager.Ivory, () => Load("TeamSelection"), 15);
            ui.Button(actions, new Rect(.625f, .84f, .316f, .105f), "SETTINGS", UIManager.PanelTint,
                UIManager.Ivory, () => ToggleSettings(true), 15);
            ui.Label(menuPanel, new Rect(.10f, .95f, .8f, .028f), "CHRISTIAN COLONY ARENA", 12, UIManager.Muted);
            BuildSettings();
            ShowSolo(Teams.PlayerId(0, 0), Teams.PlayerId(1, 0));
        }

        private void OpenMissions(bool competition)
        {
            if (competition)
            {
                if (competitionMenu == null) competitionMenu = new MissionMenu(ui, settings, true, OpenToss);
                competitionMenu.Open();
            }
            else
            {
                if (quickMenu == null) quickMenu = new MissionMenu(ui, settings, false, StartQuickMatch);
                quickMenu.Open();
            }
        }

        private void OpenToss()
        {
            competitionMenu?.Close();
            if (menuPanel != null) menuPanel.gameObject.SetActive(false);
            else
            {
                foreach (Transform child in ui.Safe) child.gameObject.SetActive(false);
            }

            if (tossLayer != null) Object.Destroy(tossLayer.gameObject);
            ceremony?.Close();
            tossLayer = ui.Panel(ui.Safe, new Rect(0, 0, 1, 1), Color.clear, false);
            tossLayer.GetComponent<Image>().raycastTarget = true;
            ui.Label(tossLayer, new Rect(.09f, .063f, .82f, .10f), "THE TOSS", 40, UIManager.Gold);
            ui.Label(tossLayer, new Rect(.16f, .16f, .68f, .048f), "PAKISTAN  VS  INDIA", 21, UIManager.Ivory);
            ui.Graphic(tossLayer, new Rect(.038f, .159f, .128f, .099f), "AvatarKosar", fitted: true);
            ui.Graphic(tossLayer, new Rect(.834f, .159f, .128f, .099f), "AvatarRazia", fitted: true);
            tossStatus = ui.Label(tossLayer, new Rect(.07f, .759f, .86f, .047f), "CAPTAINS AT THE CREASE", 16, UIManager.Ivory);
            ui.Button(tossLayer, new Rect(.053f, .853f, .25f, .056f), "‹ BACK", UIManager.Ink, UIManager.Ivory, CloseToss, 16);
            int tossWinner = Random.Range(0, 2);
            int aiChoice = Random.Range(0, 2);
            string coinSide = Random.Range(0, 2) == 0 ? "HEADS" : "TAILS";
            var mission = new BattingMission(BattingMission.Lengths[settings.Length], settings.Difficulty, 0);
            if (screen == "MatchResult") resultPanel = null;
            ceremony = new CaptainCeremony(roster[Teams.PlayerId(0, 0)], roster[Teams.PlayerId(1, 0)], art, stadium.Root, true, tossWinner);
            tossChoices = ui.Card(tossLayer, new Rect(.075f, .342f, .85f, .316f), Palette.India);
            ui.Label(tossChoices, new Rect(.07f, .11f, .86f, .36f), coinSide + "\n" + MatchSession.Team(tossWinner) + " WON THE TOSS",
                26, UIManager.Ivory);
            void Start(int first) => BeginMatch(MatchSession.Create(Teams, mission, System.Environment.TickCount, true, tossWinner, first));
            if (tossWinner == 0)
            {
                ui.Button(tossChoices, new Rect(.09f, .56f, .39f, .27f), "BAT FIRST", UIManager.Gold, UIManager.Ink, () => Start(0), 20);
                ui.Button(tossChoices, new Rect(.52f, .56f, .39f, .27f), "BOWL FIRST", UIManager.PanelTint, UIManager.Ivory, () => Start(1), 18);
            }
            else
            {
                ui.Label(tossChoices, new Rect(.09f, .405f, .82f, .18f), aiChoice == 1 ? "India chose to bat first." : "India chose to bowl first.",
                    18, UIManager.Muted, false);
                ui.Button(tossChoices, new Rect(.10f, .65f, .80f, .22f), "START MATCH", UIManager.Gold, UIManager.Ink, () => Start(aiChoice), 21);
            }
            tossChoices.gameObject.SetActive(false);
        }

        private void CloseToss()
        {
            ceremony?.Close();
            ceremony = null;
            Load(screen == "TeamSelection" ? "TeamSelection" : "MainMenu");
        }

        private void OpenHighScores()
        {
            if (highScores == null) highScores = new HighScoresMenu(ui, settings.Length, settings.Difficulty);
            highScores.Open();
        }

        private void BuildSettings()
        {
            settingsCard = ui.Modal("Settings", .512f, Palette.Australia, out settingsPanel);
            ui.Label(settingsCard, new Rect(.075f, .043f, .85f, .088f), "SETTINGS", 37, UIManager.Gold);
            SettingsRow(.203f, "Effects", () => settings.Sound ? "ON" : "OFF",
                () => { settings.Sound = !settings.Sound; audio.Sync(); });
            SettingsRow(.347f, "Commentary", () => settings.Commentary ? "ON" : "OFF",
                () => settings.Commentary = !settings.Commentary);
            SettingsRow(.491f, "Menu music", () => settings.Music ? "ON" : "OFF",
                () => { settings.Music = !settings.Music; audio.Sync(); });
            SettingsRow(.635f, "Graphics", () => SettingsManager.QualityNames[settings.Quality].ToUpperInvariant(),
                () => { settings.Quality = (settings.Quality + 1) % 3; settings.ApplyGraphics(); stadium.Quality(settings.Quality); });
            ui.Button(settingsCard, new Rect(.14f, .852f, .72f, .098f), "DONE", UIManager.Gold, UIManager.Ink, () => ToggleSettings(false));
            settingsPanel.gameObject.SetActive(false);
        }

        private void SettingsRow(float y, string caption, System.Func<string> value, System.Action update)
        {
            RectTransform tile = ui.Panel(settingsCard, new Rect(.063f, y, .874f, .098f), UIManager.PanelTint);
            ui.Label(tile, new Rect(.059f, 0, .44f, 1), caption, 19, UIManager.Ivory, false, TextAnchor.MiddleLeft);
            Text output = null;
            ui.Button(tile, new Rect(.50f, .08f, .47f, .84f), value(), UIManager.Ink, UIManager.Gold,
                () => { update(); output.text = value(); settings.Save(); }, out output, 16);
        }

        private void ToggleSettings(bool show)
        {
            menuPanel.gameObject.SetActive(!show);
            settingsPanel.gameObject.SetActive(show);
        }

        private void TeamsScreen()
        {
            Transform root = ui.Safe;
            ui.Graphic(root, new Rect(0, 0, 1, .37f), "Fade");
            ui.Graphic(root, new Rect(0, .45f, 1, .55f), "Fade", flipped: true);
            ui.Button(root, new Rect(.038f, .03f, .22f, .052f), "‹  MENU", UIManager.Ink, UIManager.Ivory, () => Load("MainMenu"), 15);
            ui.Label(root, new Rect(.06f, .116f, .88f, .065f), "SELECT PLAYERS", 37, UIManager.Ivory);
            ui.Label(root, new Rect(.085f, .18f, .83f, .042f), "Swap a player into the top batting or bowling slot.", 16, UIManager.Ivory, false);
            ui.Button(root, new Rect(.069f, .89f, .862f, .065f), "QUICK MATCH", UIManager.Gold, UIManager.Ink,
                () => OpenMissions(false), 23);
            ShowSolo(Teams.PlayerId(0, 0), Teams.PlayerId(1, 0));
            DrawTeams();
        }

        private void DrawTeams()
        {
            if (teamList)
            {
                teamList.gameObject.SetActive(false);
                Object.Destroy(teamList.gameObject);
            }
            teamList = ui.Panel(ui.Safe, new Rect(.053f, .497f, .894f, .367f), UIManager.Ink);
            for (int team = 0; team < 2; team++)
            {
                int selectionTeam = team;
                float x = team == 0 ? .044f : .519f;
                Color accent = team == 0 ? new Color(.56f, .93f, .69f) : new Color(.48f, .72f, 1f);
                ui.Label(teamList, new Rect(x, .047f, .437f, .11f), MatchSession.Team(team), 18, accent);
                for (int slot = 0; slot < 4; slot++)
                {
                    int selectionSlot = slot;
                    Cricketer player = Teams.Player(team, slot);
                    bool selected = team == selectedTeam && slot == selectedSlot;
                    Color tile = selected ? accent : UIManager.PanelTint;
                    Color ink = selected ? UIManager.Ink : UIManager.Ivory;
                    Button pick = ui.Button(teamList, new Rect(x, .188f + slot * .184f, .437f, .162f), "", tile, ink,
                        () => Pick(selectionTeam, selectionSlot));
                    Transform card = pick.transform;
                    ui.Label(card, new Rect(.073f, .09f, .85f, .55f), player.Name, 20, ink, alignment: TextAnchor.MiddleLeft);
                    string handed = player.LeftHanded ? "LH" : "RH";
                    ui.Label(card, new Rect(.073f, .63f, .89f, .26f), handed + "  ·  " + CharacterDatabase.DeliveryName(player.Deliveries[0]), 12,
                        selected ? UIManager.Ink : UIManager.Muted, false, TextAnchor.MiddleLeft);
                }
            }
        }

        private void Pick(int team, int slot)
        {
            if (selectedTeam < 0)
            {
                selectedTeam = team;
                selectedSlot = slot;
                ShowSolo(Teams.PlayerId(0, team == 0 ? slot : 0), Teams.PlayerId(1, team == 1 ? slot : 0));
            }
            else
            {
                if (team != selectedTeam || slot != selectedSlot)
                {
                    Teams.SwapPlayers(selectedTeam, selectedSlot, team, slot);
                    CreatePlayer(selectedTeam, selectedSlot);
                    CreatePlayer(team, slot);
                }
                selectedTeam = selectedSlot = -1;
                ShowSolo(Teams.PlayerId(0, 0), Teams.PlayerId(1, 0));
            }
            DrawTeams();
        }

        private void ShowSolo(int blue, int gold)
        {
            foreach (PlayerCharacter actor in roster) actor.Root.gameObject.SetActive(false);
            PlayerCharacter first = roster[blue];
            PlayerCharacter second = roster[gold];
            first.Root.gameObject.SetActive(true);
            second.Root.gameObject.SetActive(true);
            bool selection = screen == "TeamSelection";
            first.Root.position = new Vector3(-.80f, 0, selection ? -5.25f : -8.6f);
            second.Root.position = new Vector3(1.25f, 0, selection ? -4.98f : -5.3f);
            first.Root.rotation = Quaternion.Euler(0, selection ? 163 : 9, 0);
            second.Root.rotation = Quaternion.Euler(0, selection ? 188 : 207, 0);
            first.Dress(!selection);
            second.Dress(false);
        }

        private void ResultScreen()
        {
            Transform root = ui.Safe;
            ui.Graphic(root, new Rect(0, 0, 1, .46f), "Fade");
            ui.Graphic(root, new Rect(0, .49f, 1, .51f), "Fade", flipped: true);
            bool won = finished.Winner == 0;
            bool tied = finished.Winner < 0;
            Color accent = won || tied ? UIManager.Gold : UIManager.Red;
            if (won) confetti = new WinConfetti(ui);
            if (finished.Competition)
            {
                RestoreCaptainKits(finished);
                ceremony = new CaptainCeremony(roster[finished.PakistanCaptain], roster[finished.IndiaCaptain],
                    art, stadium.Root, false, finished.Winner);
            }
            else
            {
                PlayerCharacter batter = roster[finished.PakistanCaptain];
                batter.Root.position = new Vector3(0f, 0f, -4.25f);
                batter.Root.rotation = Quaternion.Euler(0f, 173f, 0f);
                batter.Root.gameObject.SetActive(true);
            }

            resultPanel = UIManager.RectNode("Result", root, new Rect(0, 0, 1, 1));
            ui.Graphic(resultPanel, new Rect(.37f, .038f, .26f, .13f), "Crest", fitted: true);
            string title = finished.Competition
                ? tied ? "MATCH TIED" : MatchSession.Team(finished.Winner) + " WIN" : won ? "CHASE WON" : "CHASE LOST";
            ui.Label(resultPanel, new Rect(.06f, .178f, .88f, .084f), title, 44, accent);
            ui.Graphic(resultPanel, new Rect(.03f, .376f, .26f, .172f), "AvatarCrowd", fitted: true);
            RectTransform panel = ui.Card(resultPanel, new Rect(.073f, .54f, .854f, .395f), Palette.Australia);
            ui.Label(panel, new Rect(.065f, .050f, .87f, .091f),
                finished.Overs + " OV  ·  " + finished.Difficulty.ToString().ToUpperInvariant(), 15, UIManager.Muted);
            string scoreLine = finished.Competition ? "PAK  " + finished.Score(0).Score + "     IND  " + finished.Score(1).Score
                : finished.Round.Total.Score;
            ui.Label(panel, new Rect(.065f, .158f, .87f, .195f), scoreLine, 42, UIManager.Ivory);
            ui.Label(panel, new Rect(.065f, .391f, .87f, .17f), ResultSummary(), 17, accent);
            ui.Button(panel, new Rect(.085f, .594f, .83f, .153f), "PLAY AGAIN", UIManager.Gold, UIManager.Ink,
                finished.Competition ? OpenToss : StartQuickMatch, 23);
            ui.Button(panel, new Rect(.085f, .786f, .397f, .137f), "SCORECARD", UIManager.PanelTint, UIManager.Gold, OpenScorecard, 16);
            ui.Button(panel, new Rect(.518f, .786f, .397f, .137f), "MAIN MENU", UIManager.PanelTint, UIManager.Ivory, () => Load("MainMenu"), 16);
            resultPanel.gameObject.SetActive(!finished.Competition);
            if (!finished.Competition) PlayResultSound();
        }

        private void PlayResultSound()
        {
            resultCheered = true;
            if (finished.Winner == 0)
            {
                audio.Play("Victory", .75f);
                audio.Play("Cheer", .64f);
            }
            else if (finished.Winner > 0) audio.Play("MissionLost", .65f);
        }

        private static string ResultSummary()
        {
            var final = finished.Round.Total;
            if (!finished.Competition)
            {
                string result = finished.Winner == 0 ? (finished.Overs * 6 - final.Balls) + " BALLS LEFT"
                    : (finished.Round.Target - final.Runs) + " RUNS SHORT";
                return "TARGET " + finished.Round.Target + "  ·  " + result;
            }
            if (finished.Winner < 0) return "BOTH TEAMS SCORED " + final.Runs;
            return finished.Winner == finished.BattingTeam
                ? "WON BY " + (3 - final.Wickets) + (final.Wickets == 2 ? " WICKET" : " WICKETS")
                : "WON BY " + (finished.FirstScore.Runs - final.Runs) +
                    (finished.FirstScore.Runs - final.Runs == 1 ? " RUN" : " RUNS");
        }

        private void AnimateLineup()
        {
            for (int i = 0; i < roster.Length; i++)
                if (roster[i].Root.gameObject.activeSelf)
                    roster[i].Act(screen == "MatchResult" ? (finished.Winner == 0 ? ActorPose.Celebrate : ActorPose.Regroup) :
                        screen == "MainMenu" && i == Teams.PlayerId(0, 0) ? ActorPose.Stance : ActorPose.Idle,
                        Time.time + i * .28f, CharacterDatabase.Players[i].LeftHanded);
        }

        private static void Load(string scene) => SceneManager.LoadScene(scene, LoadSceneMode.Single);
    }
}
