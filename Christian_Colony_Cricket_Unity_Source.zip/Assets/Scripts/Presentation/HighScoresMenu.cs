using UnityEngine;
using UnityEngine.UI;

namespace ColonyCricket
{
    internal sealed class HighScoresMenu
    {
        private readonly RectTransform root;
        private readonly Button[] lengths = new Button[BattingMission.Lengths.Length];
        private readonly Button[] levels = new Button[3];
        private readonly Text[] scores = new Text[ChaseHighScores.Capacity];
        private readonly Text[] details = new Text[ChaseHighScores.Capacity];
        private readonly Text empty;
        private int length;
        private Difficulty difficulty;

        public bool IsOpen => root.gameObject.activeSelf;

        public HighScoresMenu(UIManager ui, int length, Difficulty difficulty)
        {
            this.length = length;
            this.difficulty = difficulty;
            root = ui.Panel(ui.Safe, new Rect(0, 0, 1, 1), new Color(.011f, .028f, .046f, .88f), false);
            root.GetComponent<Image>().raycastTarget = true;
            RectTransform card = ui.Panel(root, new Rect(.06f, .145f, .88f, .711f), UIManager.Ink);
            ui.Label(card, new Rect(.07f, .046f, .86f, .072f), "TOP CHASES", 37, UIManager.Gold);

            for (int i = 0; i < lengths.Length; i++)
            {
                int choice = i;
                lengths[i] = ui.Button(card, new Rect(.067f + .226f * i, .151f, .188f, .067f),
                    BattingMission.Lengths[i] + " OV", UIManager.PanelTint, UIManager.Ivory,
                    () => { this.length = choice; Refresh(); }, 17);
            }
            for (int i = 0; i < levels.Length; i++)
            {
                Difficulty choice = (Difficulty)i;
                levels[i] = ui.Button(card, new Rect(.067f + .296f * i, .236f, .272f, .067f),
                    choice.ToString().ToUpperInvariant(), UIManager.PanelTint, UIManager.Ivory,
                    () => { this.difficulty = choice; Refresh(); }, 17);
            }

            for (int i = 0; i < scores.Length; i++)
            {
                RectTransform row = ui.Panel(card, new Rect(.067f, .343f + i * .102f, .866f, .085f), UIManager.PanelTint);
                ui.Label(row, new Rect(.025f, .10f, .12f, .80f), (i + 1).ToString(), 20, UIManager.Gold);
                scores[i] = ui.Label(row, new Rect(.175f, .09f, .29f, .82f), "", 27, UIManager.Ivory,
                    alignment: TextAnchor.MiddleLeft);
                details[i] = ui.Label(row, new Rect(.46f, .10f, .50f, .80f), "", 14, UIManager.Muted,
                    alignment: TextAnchor.MiddleRight);
            }

            empty = ui.Label(card, new Rect(.08f, .37f, .84f, .27f), "No successful chases yet.", 21, UIManager.Muted);
            ui.Button(card, new Rect(.25f, .906f, .50f, .062f), "BACK", UIManager.PanelTint, UIManager.Ivory, Close, 17);
            Close();
        }

        public void Open()
        {
            root.SetAsLastSibling();
            Refresh();
            root.gameObject.SetActive(true);
        }

        public void Close() => root.gameObject.SetActive(false);

        private void Refresh()
        {
            for (int i = 0; i < lengths.Length; i++) Style(lengths[i], i == length);
            for (int i = 0; i < levels.Length; i++) Style(levels[i], i == (int)difficulty);
            var entries = ChaseHighScores.Read(BattingMission.Lengths[length], difficulty);
            empty.gameObject.SetActive(entries.Count == 0);
            for (int i = 0; i < scores.Length; i++)
            {
                bool filled = i < entries.Count;
                scores[i].transform.parent.gameObject.SetActive(filled);
                if (!filled) continue;
                ChaseScore chase = entries[i];
                scores[i].text = chase.Runs + "/" + chase.Wickets;
                details[i].text = chase.Balls + (chase.Balls == 1 ? " BALL" : " BALLS") + "  ·  TARGET " + chase.Target;
            }
        }

        private static void Style(Button button, bool selected)
        {
            button.targetGraphic.color = selected ? UIManager.Gold : UIManager.PanelTint;
            button.GetComponentInChildren<Text>().color = selected ? UIManager.Ink : UIManager.Ivory;
        }
    }
}
