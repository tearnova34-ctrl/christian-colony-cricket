using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace ColonyCricket
{
    public sealed class SettingsManager
    {
        private const string Key = "CCC.";
        public static readonly string[] QualityNames = { "Low", "Medium", "High" };

        public int Length = Mathf.Clamp(PlayerPrefs.GetInt(Key + "Length", 1), 0, BattingMission.Lengths.Length - 1);
        public int Quality = Mathf.Clamp(PlayerPrefs.GetInt(Key + "Quality", 2), 0, 2);
        public Difficulty Difficulty = (Difficulty)Mathf.Clamp(PlayerPrefs.GetInt(Key + "Difficulty", 1), 0, 2);
        public bool Sound = PlayerPrefs.GetInt(Key + "Sound", 1) > 0;
        public bool Commentary = PlayerPrefs.GetInt(Key + "Commentary", 1) > 0;
        public bool Music = PlayerPrefs.GetInt(Key + "Music", 1) > 0;

        public void Save()
        {
            PlayerPrefs.SetInt(Key + "Length", Length);
            PlayerPrefs.SetInt(Key + "Quality", Quality);
            PlayerPrefs.SetInt(Key + "Difficulty", (int)Difficulty);
            PlayerPrefs.SetInt(Key + "Sound", Sound ? 1 : 0);
            PlayerPrefs.SetInt(Key + "Commentary", Commentary ? 1 : 0);
            PlayerPrefs.SetInt(Key + "Music", Music ? 1 : 0);
            PlayerPrefs.Save();
        }

        public BattingMission RollMission()
        {
            int overs = BattingMission.Lengths[Length];
            string history = Key + "Target." + overs + "." + Difficulty;
            BattingMission mission = BattingMission.Roll(overs, Difficulty, new System.Random(),
                PlayerPrefs.GetInt(history, 0));
            PlayerPrefs.SetInt(history, mission.Target);
            Save();
            return mission;
        }

        public void ApplyGraphics()
        {
            Application.targetFrameRate = Quality >= 2 ? 60 : 30;
            QualitySettings.vSyncCount = 0;
            if (GraphicsSettings.currentRenderPipeline is UniversalRenderPipelineAsset urp)
            {
                urp.renderScale = Quality == 0 ? .72f : Quality == 1 ? .89f : 1f;
                urp.msaaSampleCount = Quality == 0 ? 1 : Quality == 1 ? 2 : 4;
                urp.shadowDistance = Quality == 0 ? 0f : Quality == 1 ? 28f : 46f;
            }
        }
    }
}
