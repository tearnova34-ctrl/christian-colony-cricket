using UnityEngine;

namespace ColonyCricket
{
    internal sealed class UmpireController
    {
        public const string MainName = "Kosar Parveen";
        public const string SquareName = "Razia Parveen";
        private readonly PlayerCharacter main, square;

        public UmpireController(Transform parent, ArenaArt art)
        {
            main = new PlayerCharacter(parent, art, MainName, 9, 2, official: true);
            square = new PlayerCharacter(parent, art, SquareName, 12, 2, official: true);
            main.Root.position = new Vector3(.82f, 0, 10.82f);
            main.Root.rotation = Quaternion.Euler(0, 180, 0);
            square.Root.position = new Vector3(7.1f, 0, -8.6f);
            square.Root.rotation = Quaternion.Euler(0, -90, 0);
        }

        public static string Decision(DeliveryResult result)
        {
            if (result.Dismissal == Dismissal.RunOut) return SquareName + "  ·  OUT";
            if (result.Dismissal != Dismissal.None) return MainName + "  ·  OUT";
            if (result.Extra == Extra.Wide) return MainName + "  ·  WIDE";
            if (result.Extra == Extra.NoBall) return MainName + "  ·  NO BALL";
            if (result.Boundary == 4) return MainName + "  ·  FOUR";
            if (result.Boundary == 6) return SquareName + "  ·  SIX";
            return "";
        }

        public void Animate(MatchManager match)
        {
            ActorPose atBowler = ActorPose.Idle;
            ActorPose atSquare = ActorPose.Idle;
            if (match.Phase == PlayPhase.Interval || match.Phase == PlayPhase.Finished)
                atBowler = ActorPose.IntervalSignal;
            if (match.Phase == PlayPhase.Decision)
            {
                DeliveryResult d = match.LastResult;
                if (d.Dismissal == Dismissal.RunOut) atSquare = ActorPose.OutSignal;
                else if (d.Dismissal != Dismissal.None) atBowler = ActorPose.OutSignal;
                if (d.Extra == Extra.Wide) atBowler = ActorPose.WideSignal;
                else if (d.Extra == Extra.NoBall) atBowler = ActorPose.NoBallSignal;
                if (d.Boundary == 4 && d.Extra == Extra.None) atBowler = ActorPose.FourSignal;
                if (d.Boundary == 6) atSquare = ActorPose.SixSignal;
            }
            main.Act(atBowler, atBowler == ActorPose.Idle ? Time.time : match.PhaseTime);
            square.Act(atSquare, atSquare == ActorPose.Idle ? Time.time + .4f : match.PhaseTime);
        }
    }
}
