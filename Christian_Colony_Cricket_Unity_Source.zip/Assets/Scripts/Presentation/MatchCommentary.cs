using System.Collections.Generic;
using UnityEngine;

namespace ColonyCricket
{
    internal sealed class MatchCommentary
    {
        private readonly MatchManager match;
        private readonly SettingsManager settings;
        private readonly AudioSource voice;
        private readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>();
        private readonly Queue<AudioClip> pending = new Queue<AudioClip>();
        private DeliveryType delivery;
        private string shotDescription;
        private float captionUntil;
        private bool paused;
        public string Caption { get; private set; } = "";

        public MatchCommentary(Transform owner, MatchManager match, SettingsManager settings)
        {
            this.match = match;
            this.settings = settings;
            voice = ArenaArt.Node("Commentator", owner, Vector3.zero).gameObject.AddComponent<AudioSource>();
            voice.playOnAwake = false;
            voice.spatialBlend = 0f;
            voice.volume = .96f;

            match.Changed += OnPhase;
            match.Swing += OnSwing;
            match.Decided += OnDecision;
        }

        public void Update(bool isPaused)
        {
            if (isPaused != paused)
            {
                paused = isPaused;
                if (paused) voice.Pause();
                else voice.UnPause();
            }
            if (paused) { captionUntil += Time.unscaledDeltaTime; return; }
            if (Time.unscaledTime >= captionUntil) Caption = "";
            if (voice.isPlaying || pending.Count == 0) return;
            voice.clip = pending.Dequeue();
            voice.Play();
        }

        private void OnPhase()
        {
            if (match.Phase == PlayPhase.RunUp)
            {
                delivery = match.Aim.Type;
                shotDescription = "";
                Announce(match.Bowler.Name + " to " + match.Striker.Name + "  ·  " + CharacterDatabase.DeliveryName(delivery),
                    false, match.Bowler.Name, "To", match.Striker.Name, delivery.ToString());
            }
            else if (match.Phase == PlayPhase.Interval)
            {
                Announce("Innings break  ·  Gold need " + (match.Rules.Current.Runs + 1) + " to win",
                    false, "InningsBreak");
            }
        }

        private void OnSwing(Shot shot)
        {
            if (!shot.MadeContact) return;
            shotDescription = Describe(shot.Stroke);
            if (shot.Timing == Timing.Early || shot.Timing == Timing.Late) shotDescription = "Mishit " + shotDescription.ToLowerInvariant();
        }

        private void OnDecision(DeliveryResult result)
        {
            string batter = match.BatsmanAtDecision;
            string bowler = match.BowlerAtDecision;
            string played = string.IsNullOrEmpty(shotDescription) ? "" : shotDescription + "  ·  ";
            string extra = result.Extra == Extra.None ? "" : result.Extra == Extra.Wide ? "Wide" : "NoBall";
            string extraText = result.Extra == Extra.None ? "" : result.Extra == Extra.Wide ? "  ·  Wide" : "  ·  No ball";
            if (result.Dismissal != Dismissal.None)
            {
                string name = match.DismissedName;
                string call = result.Dismissal == Dismissal.Bowled ? " bowled by " + bowler :
                    result.Dismissal == Dismissal.Caught ? " caught off " + bowler : " run out";
                Announce(name + call + extraText, true, name, result.Dismissal.ToString(),
                    result.Dismissal == Dismissal.RunOut ? "" : bowler, extra);
            }
            else if (result.Boundary > 0)
            {
                Announce(batter + "  ·  " + played + (result.Boundary == 6 ? "Six!" : "Four!") + extraText,
                    true, batter, result.Boundary == 6 ? "Six" : "Four", extra);
            }
            else if (result.Extra != Extra.None && result.RunningRuns == 0)
            {
                Announce(bowler + extraText, true, bowler, extra);
            }
            else
            {
                int runs = result.RunningRuns;
                string score = runs == 0 ? "Dot ball" : runs == 1 ? "1 run" : runs + " runs";
                string token = runs == 0 ? "Dot" : runs == 1 ? "Single" : runs == 2 ? "Double" : "Triple";
                Announce(batter + "  ·  " + played + score + extraText, true, batter, token, extra);
            }
        }

        private void Announce(string caption, bool priority, params string[] tokens)
        {
            Caption = caption;
            captionUntil = Time.unscaledTime + (priority ? 2.8f : 2.15f);
            if (!settings.Commentary) return;
            if (!priority && (voice.isPlaying || pending.Count != 0)) return;
            if (priority)
            {
                voice.Stop();
                pending.Clear();
            }
            foreach (string token in tokens)
            {
                if (string.IsNullOrEmpty(token)) continue;
                if (!clips.TryGetValue(token, out AudioClip clip))
                {
                    clip = Resources.Load<AudioClip>("Commentary/" + token);
                    clips[token] = clip;
                }
                if (clip) pending.Enqueue(clip);
            }
        }

        private static string Describe(Stroke stroke)
        {
            switch (stroke)
            {
                case Stroke.CoverDrive: return "Cover drive";
                case Stroke.Cut: return "Square cut";
                case Stroke.OffDrive: return "Off drive";
                case Stroke.Pull: return "Pull shot";
                case Stroke.Flick: return "Flick";
                case Stroke.OnDrive: return "On drive";
                case Stroke.Defensive: return "Defensive stroke";
                case Stroke.Loft: return "Lofted shot";
                default: return "";
            }
        }
    }
}
