using System.Collections.Generic;
using UnityEngine;

namespace ColonyCricket
{
    internal sealed class MatchCommentary
    {
        private readonly SettingsManager settings;
        private readonly AudioSource voice;
        private readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>();

        public bool Speaking => voice.isPlaying;

        public MatchCommentary(Transform owner, MatchManager match, SettingsManager settings)
        {
            this.settings = settings;
            voice = ArenaArt.Node("Commentary", owner, Vector3.zero).gameObject.AddComponent<AudioSource>();
            voice.playOnAwake = false;
            voice.spatialBlend = 0f;
            voice.priority = 24;
            voice.volume = .91f;
            foreach (AudioClip asset in Resources.LoadAll<AudioClip>("Commentary"))
                clips.Add(asset.name, asset);
            match.Decided += Announce;
        }

        public void SetPaused(bool paused)
        {
            if (paused) voice.Pause();
            else voice.UnPause();
        }

        private void Announce(DeliveryResult result)
        {
            if (!settings.Commentary || !clips.TryGetValue(result.VoiceKey, out AudioClip clip)) return;
            voice.Stop();
            voice.clip = clip;
            voice.Play();
        }
    }
}
