using UnityEngine;

namespace ColonyCricket
{
    internal enum ActorPose
    {
        Idle, Stance, Prepare, Cover, Cut, OffDrive, Pull, Flick, OnDrive, Defend, Loft, Miss,
        Run, FastRelease, SpinRelease, Celebrate, Regroup, Handshake, Toss, SignalOut, SignalFour, SignalSix, SignalWide, SignalReview, Applaud
    }

    internal sealed class PlayerCharacter
    {
        public readonly Transform Root;
        private readonly Transform kit, head, bat, helmet, cap;
        private readonly Transform[] upperArm = new Transform[2], forearm = new Transform[2], hand = new Transform[2];
        private readonly Transform[] upperLeg = new Transform[2], lowerLeg = new Transform[2], shoe = new Transform[2];
        private readonly Transform[] kneePad = new Transform[2];
        private readonly CricketerFace face;
        private readonly Transform[] gloves = new Transform[2];
        private readonly float build;
        private Frame current;
        private bool initialized;
        private struct Frame
        {
            public float Dip, Lean, Twist, FootTurn;
            public Vector3 LHand, RHand, LFoot, RFoot, Blade, FacePlane;
        }

        public PlayerCharacter(Transform parent, ArenaArt art, string name, int variation, int team, Cricketer person)
        {
            Root = ArenaArt.Node(name, parent, Vector3.zero);
            Root.localScale = Vector3.one * person.Height;
            build = person.Build;
            bool official = team == 2;
            string kitName = team == 0 ? "PAK" : "IND";
            Color trousersColor = team == 0 ? new Color(.038f, .29f, .16f) : new Color(.055f, .242f, .58f);
            Color stripeColor = team == 0 ? new Color(.54f, .88f, .61f) : new Color(1f, .44f, .146f);
            Material jersey = official ? art.Mat("Umpire shirt", new Color(.19f, .23f, .28f), "Weave")
                : art.Mat("Kit shirt " + team, Color.white, kitName + "Jersey");
            Material trousers = art.Mat("Kit trousers " + team, official ? new Color(.042f, .054f, .066f) : trousersColor, "Weave", tile: 2);
            Material stripe = art.Mat("Kit trim " + team, official ? new Color(.88f, .89f, .87f) : stripeColor, "Weave", tile: 2);
            Material light = art.Mat("Boot canvas", new Color(.93f, .94f, .89f));
            Material sole = art.Mat("Boot rubber", new Color(.095f, .15f, .18f));
            Material hair = art.Mat("Hair " + variation, Color.Lerp(new Color(.064f, .050f, .047f),
                new Color(.30f, .17f, .12f), (variation * 3 % 11) / 11f));
            Material complexion = art.Mat("Complexion " + variation, Color.Lerp(new Color(.38f, .22f, .16f),
                new Color(.84f, .60f, .44f), (variation * 7 % 13) / 12f));
            Material pads = art.Mat("Padded leather " + team, team == 0 ? new Color(.73f, .83f, .94f) : new Color(.95f, .88f, .66f));

            kit = ArenaArt.Node("Waist rig", Root, Vector3.zero);
            ArenaArt.Part("Tailored performance jersey", kit, Forms.Shirt, jersey, Vector3.zero, new Vector3(.568f * build, .62f, .359f));
            ArenaArt.Part("Jersey yoke", kit, Forms.Shirt, stripe, new Vector3(0, .445f, 0), new Vector3(.542f * build, .027f, .342f));
            ArenaArt.Part("Waist seam", kit, Forms.Sleeve, trousers, new Vector3(0, -.085f, 0), new Vector3(.458f * build, .158f, .338f));
            ArenaArt.Part("Stand collar", kit, Forms.Tube, stripe, new Vector3(0, .56f, .018f), new Vector3(.22f, .068f, .209f));
            ArenaArt.Part("Waistband", kit, Forms.Sleeve, stripe, new Vector3(0, .008f, 0), new Vector3(.448f * build, .038f, .342f));
            if (!official)
            {
                Material logo = art.Mat("Jersey chest " + team, Color.white, kitName + "Chest");
                Material back = art.Mat("Kit number " + variation + " team " + team, Color.white,
                    "Kit" + team + "_" + variation, flat: true);
                ArenaArt.Part("Rear name and number", kit, Forms.Quad, back,
                    new Vector3(0, .275f, -.182f), new Vector3(.305f, .27f, 1f), false);
                ArenaArt.Part("Chest team name", kit, Forms.Quad, logo, new Vector3(0f, .306f, .181f),
                    new Vector3(.236f, .075f, 1f), false).localRotation = Quaternion.Euler(0f, 180f, 0f);
            }

            head = ArenaArt.Node("Head rig", kit, new Vector3(0, .615f, .008f));
            float cheeks = .278f;
            float skullDepth = .291f;
            ArenaArt.Part("Neck", head, Forms.Tube, complexion, new Vector3(0, -.068f, 0), new Vector3(.142f, .122f, .149f));
            face = new CricketerFace(head, art, complexion, hair, variation);
            cap = ArenaArt.Node("Field cap", head, new Vector3(0, .228f, -.006f));
            ArenaArt.Part("Panel crown", cap, Forms.Cap, jersey, Vector3.zero, new Vector3(cheeks * 1.08f, .153f, skullDepth * 1.18f));
            ArenaArt.Part("Brim", cap, Forms.Ball, official ? jersey : stripe, new Vector3(0f, -.011f, official ? .018f : .104f),
                official ? new Vector3(.399f, .031f, .389f) : new Vector3(.226f, .026f, .239f));
            helmet = ArenaArt.Node("Batting helmet", head, new Vector3(0, .135f, .007f));
            {
                Material shell = art.Mat("Helmet " + team, team == 0 ? new Color(.023f, .19f, .11f) : new Color(.035f, .13f, .36f));
                ArenaArt.Part("Rounded helmet shell", helmet, Forms.Cap, shell, new Vector3(0, .078f, -.02f), new Vector3(.320f, .218f, .349f));
                ArenaArt.Part("Helmet visor", helmet, Forms.Ball, shell, new Vector3(0, .066f, .139f), new Vector3(.300f, .027f, .256f));
                for (int i = 0; i < 2; i++)
                    Rod("Guard wire", helmet, light, new Vector3(-.151f, i * .043f - .067f, .195f),
                        new Vector3(.151f, i * .043f - .067f, .195f), .014f);
                for (int i = -1; i <= 1; i += 2)
                    Rod("Guard strut", helmet, light, new Vector3(i * .165f, -.064f, .154f), new Vector3(i * .163f, .069f, .047f), .016f);
            }

            for (int i = 0; i < 2; i++)
            {
                upperArm[i] = ArenaArt.Node("Upper arm " + i, Root, Vector3.zero);
                ArenaArt.Part("Sleeve", upperArm[i], Forms.Sleeve, jersey, new Vector3(0, .465f, 0), new Vector3(.173f, .508f, .184f));
                ArenaArt.Part("Sleeve stripe", upperArm[i], Forms.Sleeve, stripe, new Vector3(0, .466f, 0), new Vector3(.166f, .080f, .182f));
                ArenaArt.Part("Upper arm skin", upperArm[i], Forms.Sleeve, complexion, Vector3.zero, new Vector3(.141f, .67f, .152f));
                forearm[i] = ArenaArt.Part("Forearm", Root, Forms.Sleeve, complexion, Vector3.zero, Vector3.one);
                hand[i] = ArenaArt.Part("Hand", Root, Forms.Ball, complexion, Vector3.zero, new Vector3(.087f, .126f, .075f));
                gloves[i] = ArenaArt.Part("Padded batting glove", hand[i], Forms.Ball, light, Vector3.zero,
                    new Vector3(1.12f, 1.07f, 1.20f), false);
                ArenaArt.Part("Glove seam", gloves[i], Forms.Tube, stripe, new Vector3(0, .70f, .087f),
                    new Vector3(1f, .15f, .75f), false);
                upperLeg[i] = ArenaArt.Part("Thigh", Root, Forms.Trousers, trousers, Vector3.zero, Vector3.one);
                lowerLeg[i] = ArenaArt.Part("Trouser calf", Root, Forms.Trousers, trousers, Vector3.zero, Vector3.one);
                kneePad[i] = ArenaArt.Node("Layered batting pad", lowerLeg[i], new Vector3(0, .07f, .26f));
                for (int rib = -1; rib <= 1; rib++)
                    ArenaArt.Part("Pad rib", kneePad[i], Forms.Tube, pads, new Vector3(rib * .238f, .04f, .30f),
                        new Vector3(.246f, .92f - Mathf.Abs(rib) * .08f, .58f));
                shoe[i] = ArenaArt.Node("Boot pivot", Root, Vector3.zero);
                ArenaArt.Part("Cricket shoe", shoe[i], Forms.Shoe, light, new Vector3(0, -.042f, .048f), new Vector3(.166f, .132f, .294f));
                ArenaArt.Part("Outsole", shoe[i], Forms.Shoe, sole, new Vector3(0, -.077f, .048f), new Vector3(.172f, .052f, .299f));
                    for (int stud = 0; stud < 3; stud++)
                        ArenaArt.Part("Stud", shoe[i], Forms.Tube, stripe, new Vector3((stud % 2 == 0 ? .048f : -.048f), -.081f, .13f - stud * .065f),
                            new Vector3(.032f, .04f, .032f));
            }

            bat = ArenaArt.Node("Cricket bat rig", Root, Vector3.zero);
            {
                Material willow = art.Mat("Bat willow grain", Color.white, "Willow");
                ArenaArt.Part("Willow blade", bat, Forms.Bat, willow, Vector3.zero, new Vector3(.151f, .685f, .083f));
                ArenaArt.Part("Blade shoulder", bat, Forms.Ball, stripe, new Vector3(0, .40f, -.042f), new Vector3(.11f, .22f, .011f));
                ArenaArt.Part("Bat grip", bat, Forms.Tube, sole, new Vector3(0, .622f, 0), new Vector3(.058f, .264f, .058f));
            }
            Dress(false);
        }

        public void Dress(bool batting)
        {
            bat.gameObject.SetActive(batting);
            helmet.gameObject.SetActive(batting);
            cap.gameObject.SetActive(!batting);
            foreach (Transform pad in kneePad) pad.gameObject.SetActive(batting);
            foreach (Transform glove in gloves) glove.gameObject.SetActive(batting);
        }

        public void Act(ActorPose pose, float elapsed, bool mirror = false, bool snap = false,
            Vector3? contact = null, int shotDirection = 0, float sideStep = 0f, Vector3? greeting = null)
        {
            Frame target = Calculate(pose, elapsed, mirror ? -shotDirection : shotDirection);
            if (mirror)
            {
                Vector3 left = target.LHand;
                target.LHand = Mirror(target.RHand);
                target.RHand = Mirror(left);
                Vector3 foot = target.LFoot;
                target.LFoot = Mirror(target.RFoot);
                target.RFoot = Mirror(foot);
                target.Blade = Mirror(target.Blade);
                target.FacePlane = Mirror(target.FacePlane);
                target.Twist = -target.Twist;
                target.FootTurn = -target.FootTurn;
            }
            if (Mathf.Abs(sideStep) > .008f)
            {
                float stride = Mathf.Clamp(sideStep * .40f, -.16f, .16f);
                if (stride < 0f) target.LFoot += new Vector3(stride, -stride * .36f, 0f);
                else target.RFoot += new Vector3(stride, stride * .36f, 0f);
                target.Dip += Mathf.Abs(stride) * .15f;
            }
            if (contact.HasValue)
            {
                Vector3 grip = (target.LHand + target.RHand) * .5f;
                Vector3 axis = (grip - target.Blade).normalized;
                Vector3 meetingGrip = contact.Value + axis * (BatGrip.CentreSocket - BatGrip.SweetSpot);
                float blend = 1f - Mathf.SmoothStep(0, 1, elapsed / .16f);
                Vector3 shift = (meetingGrip - grip) * blend;
                target.LHand += shift;
                target.RHand += shift;
                target.Blade += shift;
            }
            if (greeting.HasValue) target.RHand = Root.InverseTransformPoint(greeting.Value);
            float alpha = snap || !initialized ? 1 : 1f - Mathf.Exp(-Time.deltaTime * (pose == ActorPose.FastRelease ? 32f : 21f));
            if (!initialized)
            {
                initialized = true;
                current = target;
            }
            current.LHand = Vector3.Lerp(current.LHand, target.LHand, alpha);
            current.RHand = Vector3.Lerp(current.RHand, target.RHand, alpha);
            current.LFoot = Vector3.Lerp(current.LFoot, target.LFoot, alpha);
            current.RFoot = Vector3.Lerp(current.RFoot, target.RFoot, alpha);
            current.Blade = Vector3.Lerp(current.Blade, target.Blade, alpha);
            current.FacePlane = Vector3.Lerp(current.FacePlane, target.FacePlane, alpha);
            current.FootTurn = Mathf.Lerp(current.FootTurn, target.FootTurn, alpha);
            current.Dip = Mathf.Lerp(current.Dip, target.Dip, alpha);
            current.Lean = Mathf.Lerp(current.Lean, target.Lean, alpha);
            current.Twist = Mathf.Lerp(current.Twist, target.Twist, alpha);
            kit.localPosition = new Vector3(0, .98f + current.Dip, 0);
            kit.localRotation = Quaternion.Euler(current.Lean, current.Twist, 0);
            bool batting = pose >= ActorPose.Stance && pose <= ActorPose.Miss;
            head.localRotation = batting
                ? Quaternion.Euler(-current.Lean * .65f + 5f, -current.Twist * .92f, 0f)
                : Quaternion.Euler(pose == ActorPose.Regroup ? 17f : pose == ActorPose.Toss ? -16f : -current.Lean * .45f, -current.Twist * .37f, 0f);

            Leg(0, current.LFoot, batting);
            Leg(1, current.RFoot, batting);
            if (bat.gameObject.activeSelf)
            {
                Vector3 grip = (current.LHand + current.RHand) * .5f;
                Vector3 axis = (grip - current.Blade).normalized;
                if (axis.sqrMagnitude < .001f) axis = Vector3.up;
                grip = BattingRig.FitGrip(grip, axis, Shoulder(0), Shoulder(1), mirror);
                var held = new BatGrip(grip, axis, current.FacePlane);
                bat.SetLocalPositionAndRotation(held.Origin, held.Rotation);
                Arm(0, mirror ? held.Bottom : held.Top, true);
                Arm(1, mirror ? held.Top : held.Bottom, true);
            }
            else
            {
                Arm(0, current.LHand, false);
                Arm(1, current.RHand, false);
            }
            face.Animate(Time.time);
        }

        private Vector3 Shoulder(int index)
        {
            float side = index == 0 ? -1f : 1f;
            return kit.localPosition + kit.localRotation * new Vector3(side * (.239f * build), .465f, 0);
        }

        private void Arm(int index, Vector3 point, bool gripping)
        {
            float side = index == 0 ? -1f : 1f;
            Vector3 shoulder = Shoulder(index);
            Vector3 hinge;
            if (gripping)
            {
                Vector3 outward = kit.localRotation * new Vector3(side * .88f, -.43f, -.32f);
                hinge = BattingRig.Hinge(shoulder, point, outward, .303f, .312f);
            }
            else hinge = (shoulder + point) * .5f + new Vector3(side * .104f, -.065f, -.079f);
            Segment(upperArm[index], hinge, shoulder, 1, 1);
            Segment(forearm[index], point, hinge, .113f, .124f);
            Vector3 fromElbow = (point - hinge).normalized;
            hand[index].SetLocalPositionAndRotation(point - fromElbow * .056f,
                Quaternion.FromToRotation(Vector3.up, fromElbow));
        }

        private void Leg(int index, Vector3 foot, bool batting)
        {
            float side = index == 0 ? -1f : 1f;
            Vector3 hip = kit.localPosition + Quaternion.Euler(0f, current.Twist, 0f) *
                new Vector3(side * .145f * build, 0f, -.028f);
            Vector3 knee = batting
                ? BattingRig.Hinge(hip, foot, Quaternion.Euler(0f, current.FootTurn, 0f) * Vector3.forward, .468f, .466f)
                : (hip + foot) * .5f + new Vector3(side * .027f, 0, .153f);
            Segment(upperLeg[index], knee, hip, .235f * build, .254f);
            Segment(lowerLeg[index], foot, knee, .213f * build, .228f);
            shoe[index].SetLocalPositionAndRotation(foot, Quaternion.Euler(0f, batting ? current.FootTurn + side * 7f : 0f, 0f));
        }

        private static Frame Calculate(ActorPose pose, float t, int shotDirection)
        {
            float breathe = .017f * Mathf.Sin(t * 3.2f);
            Frame f = new Frame
            {
                Dip = breathe, LHand = new Vector3(-.358f, .984f + breathe, .021f),
                RHand = new Vector3(.358f, .984f + breathe, .021f),
                LFoot = new Vector3(-.173f, .09f, .051f), RFoot = new Vector3(.172f, .09f, -.087f),
                Blade = new Vector3(.36f, .125f, .20f), FacePlane = Vector3.forward
            };

            if (pose >= ActorPose.Stance && pose <= ActorPose.Miss)
            {
                f.Dip = -.168f + breathe * .38f;
                f.Lean = 15f;
                f.Twist = 69f;
                f.FootTurn = 64f;
                f.LFoot = new Vector3(-.056f, .099f, .282f);
                f.RFoot = new Vector3(.080f, .099f, -.248f);
                Vector3 grip = new Vector3(.308f, .794f + breathe * .25f, .133f);
                f.LHand = f.RHand = grip;
                f.Blade = new Vector3(.707f, .233f, .315f);
                f.FacePlane = new Vector3(.55f, 0f, -.83f);
                if (pose == ActorPose.Stance) return f;
                if (pose == ActorPose.Prepare)
                {
                    float draw = Mathf.SmoothStep(0, 1, Mathf.InverseLerp(.37f, 1f, t));
                    f.Twist += draw * 8f;
                    f.Lean -= draw * 5f;
                    f.LHand = f.RHand = grip + new Vector3(.052f, .21f, -.259f) * draw;
                    f.Blade = Vector3.Lerp(f.Blade, new Vector3(.29f, 1.553f, -.44f), draw);
                    return f;
                }

                float follow = Mathf.SmoothStep(0, 1, Mathf.Clamp01(t / .40f));
                float recovery = Mathf.SmoothStep(0, 1, (t - .46f) / .22f);
                float finish = follow * (1f - .45f * recovery);
                bool loft = pose == ActorPose.Loft;
                bool defend = pose == ActorPose.Defend;
                bool across = pose == ActorPose.Cut || pose == ActorPose.Pull || pose == ActorPose.Flick;
                float direction = shotDirection != 0 ? shotDirection : pose == ActorPose.Miss ? -.65f : 1f;
                float elevation = loft ? 1.03f : across ? .56f : .76f;
                f.Twist = Mathf.Lerp(62f, 15f + direction * (defend ? 13f : 48f), finish);
                f.FootTurn = Mathf.Lerp(64f, 25f + direction * 18f, finish);
                f.FacePlane = Vector3.Lerp(f.FacePlane, new Vector3(direction * .48f, 0f, -.87f), finish);
                f.Lean = Mathf.Lerp(defend ? 21f : 14f, loft ? -22f : defend ? 14f : 4f, finish);
                f.Dip -= (defend ? .10f : .045f) * (1f - follow);
                float step = Mathf.SmoothStep(0f, 1f, t * 12f);
                f.LFoot.z += (defend ? .16f : .31f) * step;
                f.LFoot.x += direction * .095f * step;
                f.LHand = new Vector3(.34f + direction * .30f * finish, .91f + (defend ? .08f : elevation) * finish,
                    Mathf.Lerp(.32f, across ? .25f : .62f, finish));
                f.RHand = f.LHand;
                f.Blade = new Vector3(.51f + direction * .67f * finish,
                    Mathf.Lerp(across ? .67f : .33f, defend ? .60f : loft ? 2.68f : across ? 1.62f : 2.20f, finish),
                    Mathf.Lerp(.57f, across ? .02f : .74f, finish));
                return f;
            }

            if (pose == ActorPose.Run)
            {
                float arc = Mathf.Sin(t * 19.5f);
                float stride = .55f;
                f.Dip = -.04f + .086f * Mathf.Abs(arc);
                f.Lean = 13f;
                f.Twist = arc * 14f;
                f.LFoot.z = arc * stride; f.RFoot.z = -arc * stride;
                f.LFoot.y += Mathf.Max(0, -arc) * .28f; f.RFoot.y += Mathf.Max(0, arc) * .28f;
                f.LHand.z = -arc * .35f; f.RHand.z = arc * .35f;
                f.LHand.y = 1.11f - arc * .10f; f.RHand.y = 1.11f + arc * .10f;
                return f;
            }

            if (pose == ActorPose.FastRelease || pose == ActorPose.SpinRelease)
            {
                float u = Mathf.Clamp01(t);
                f.RHand = new Vector3(.22f + Mathf.Sin(u * Mathf.PI) * (pose == ActorPose.SpinRelease ? .36f : .16f),
                    1.05f + .98f * u, Mathf.Lerp(-.58f, .32f, u));
                f.LHand = new Vector3(-.32f, 1.69f - .72f * u, .32f - .10f * u);
                f.LFoot.z = .40f;
                f.RFoot.z = -.53f;
                f.RFoot.y += .23f * u;
                f.Lean = u * 14f;
                f.Twist = -21f + u * 48f;
                float followThrough = Mathf.SmoothStep(0, 1, t - 1f);
                f.RHand = Vector3.Lerp(f.RHand, new Vector3(-.24f, .88f, .52f), followThrough);
                f.LHand = Vector3.Lerp(f.LHand, new Vector3(-.30f, 1.02f, -.22f), followThrough);
                f.RFoot.z += followThrough * .86f;
                f.Lean += followThrough * 11f;
                f.Twist += followThrough * 22f;
                return f;
            }

            if (pose >= ActorPose.SignalOut && pose <= ActorPose.Applaud)
            {
                float lift = Mathf.SmoothStep(0f, 1f, t * 2.8f);
                Vector3 left = f.LHand, right = f.RHand;
                switch (pose)
                {
                    case ActorPose.SignalOut: right = new Vector3(.26f, 1.99f, .12f); break;
                    case ActorPose.SignalSix:
                        right = new Vector3(.28f, 2.015f, .05f);
                        left = new Vector3(-.28f, 2.015f, .05f);
                        break;
                    case ActorPose.SignalFour:
                        right = new Vector3(.35f + .39f * Mathf.Sin(t * 5.9f), 1.44f, .29f);
                        break;
                    case ActorPose.SignalWide:
                        right = new Vector3(.79f, 1.43f, .04f);
                        left = new Vector3(-.79f, 1.43f, .04f);
                        break;
                    case ActorPose.SignalReview:
                        right = new Vector3(.24f, 1.56f, .37f);
                        left = new Vector3(-.24f, 1.56f, .37f);
                        break;
                    case ActorPose.Applaud:
                        float gap = Mathf.Abs(Mathf.Sin(t * 9.2f)) * .19f;
                        right = new Vector3(.055f + gap, 1.30f, .30f);
                        left = new Vector3(-.055f - gap, 1.30f, .30f);
                        break;
                }
                f.RHand = Vector3.Lerp(f.RHand, right, lift);
                f.LHand = Vector3.Lerp(f.LHand, left, lift);
            }

            if (pose == ActorPose.Toss)
            {
                float flick = Mathf.Sin(Mathf.Clamp01(t) * Mathf.PI);
                f.RHand = new Vector3(.13f, 1.22f + flick * .37f, .35f + flick * .10f);
                f.LHand.y += .07f * flick;
                f.Lean = -8f * flick;
            }
            if (pose == ActorPose.Regroup)
            {
                f.Lean = 12f;
                f.Dip -= .058f;
                f.LHand = new Vector3(-.31f, .86f, .07f);
                f.RHand = new Vector3(.31f, .86f, .07f);
            }
            if (pose == ActorPose.Celebrate)
            {
                float up = Mathf.SmoothStep(0, 1, Mathf.PingPong(t * .85f, 1f));
                f.LHand = Vector3.Lerp(f.LHand, new Vector3(-.31f, 1.96f, .09f), up);
                f.RHand = Vector3.Lerp(f.RHand, new Vector3(.33f, 1.98f, .13f), up);
                f.Dip += .032f * Mathf.Sin(t * 5.5f);
            }
            return f;
        }

        private static Vector3 Mirror(Vector3 p) => new Vector3(-p.x, p.y, p.z);

        private static void Segment(Transform t, Vector3 from, Vector3 to, float w, float d)
        {
            Vector3 direction = to - from;
            t.localPosition = from;
            t.localRotation = Quaternion.FromToRotation(Vector3.up, direction.normalized);
            t.localScale = new Vector3(w, direction.magnitude, d);
        }

        private static void Rod(string name, Transform root, Material material, Vector3 from, Vector3 to, float width)
        {
            Transform t = ArenaArt.Part(name, root, Forms.Tube, material, Vector3.zero, Vector3.one);
            Segment(t, from, to, width, width);
        }
    }
}
