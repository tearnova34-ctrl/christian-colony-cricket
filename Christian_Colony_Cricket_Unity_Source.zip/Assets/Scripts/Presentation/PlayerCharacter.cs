using UnityEngine;

namespace ColonyCricket
{
    internal enum ActorPose
    {
        Idle, Stance, Prepare, Cover, Cut, OffDrive, Pull, Flick, OnDrive, Defend, Loft, Miss,
        Run, Walk, FastRelease, SpinRelease, Catch, Pickup, Throw, Celebrate, Dismissed,
        OutSignal, FourSignal, SixSignal, WideSignal, NoBallSignal, IntervalSignal
    }

    internal sealed class PlayerCharacter
    {
        public readonly Transform Root;
        private readonly Transform kit, collar, belt, head, bat, helmet, cap;
        private readonly Transform[] upperArm = new Transform[2], forearm = new Transform[2], hand = new Transform[2];
        private readonly Transform[] upperLeg = new Transform[2], lowerLeg = new Transform[2], shoe = new Transform[2];
        private readonly Transform[] kneePad = new Transform[2];
        private readonly Transform finger;
        private readonly float build;
        private Frame current;
        private bool initialized;
        private struct Frame
        {
            public float Dip, Lean, Twist;
            public Vector3 LHand, RHand, LFoot, RFoot, Blade;
        }

        public PlayerCharacter(Transform parent, ArenaArt art, string name, int variation, int team, Cricketer person = null, bool official = false, bool simple = false)
        {
            Root = ArenaArt.Node(name, parent, Vector3.zero);
            Root.localScale = Vector3.one * (person?.Height ?? (variation % 2 == 0 ? 1f : .98f));
            build = person?.Build ?? 1f;
            Color jerseyColor = official ? new Color(.785f, .865f, .901f) : team == 0 ? ArenaArt.Blue : ArenaArt.Gold;
            Color trousersColor = official ? new Color(.085f, .12f, .18f) : team == 0 ? new Color(.069f, .25f, .72f) : new Color(.81f, .46f, .085f);
            Color stripeColor = official ? new Color(.10f, .19f, .27f) : team == 0 ? ArenaArt.Bone : ArenaArt.Green;
            Material jersey = art.Mat("Kit shirt " + team, jerseyColor, "Weave", tile: 2);
            Material trousers = art.Mat("Kit trousers " + team, trousersColor, "Weave", tile: 2);
            Material stripe = art.Mat("Kit trim " + team, stripeColor, "Weave", tile: 2);
            Material light = art.Mat("Boot canvas", new Color(.93f, .94f, .89f));
            Material sole = art.Mat("Boot rubber", new Color(.095f, .15f, .18f));
            Material hair = art.Mat("Hair " + variation, Color.Lerp(new Color(.064f, .050f, .047f),
                new Color(.30f, .17f, .12f), (variation * 3 % 11) / 11f));
            Material complexion = art.Mat("Complexion " + variation, Color.Lerp(new Color(.38f, .22f, .16f),
                new Color(.84f, .60f, .44f), (variation * 7 % 13) / 12f));
            Material pupil = art.Mat("Eye detail", new Color(.065f, .045f, .04f));
            Material pads = art.Mat("Padded leather", team == 0 ? new Color(.73f, .83f, .94f) : new Color(.95f, .88f, .66f));

            kit = ArenaArt.Node("Waist rig", Root, Vector3.zero);
            ArenaArt.Part("Tailored performance jersey", kit, Forms.Shirt, jersey, Vector3.zero, new Vector3(.64f * build, .62f, .41f));
            ArenaArt.Part("Jersey yoke", kit, Forms.Shirt, stripe, new Vector3(0, .445f, 0), new Vector3(.603f * build, .095f, .382f));
            ArenaArt.Part("Waist seam", kit, Forms.Sleeve, trousers, new Vector3(0, -.085f, 0), new Vector3(.507f * build, .195f, .356f));
            collar = ArenaArt.Part("Stand collar", kit, Forms.Tube, stripe, new Vector3(0, .56f, .018f), new Vector3(.22f, .068f, .209f));
            belt = ArenaArt.Part("Waistband", kit, Forms.Sleeve, stripe, new Vector3(0, .008f, 0), new Vector3(.50f * build, .067f, .38f));
            if (!simple)
            {
                Material logo = art.Mat("Jersey crest", Color.white, "Crest", flat: true);
                // A small embroidered block keeps the rear kit legible at batting distance.
                ArenaArt.Part("Back kit panel", kit, Forms.Quad, stripe, new Vector3(0, .30f, -.194f), new Vector3(.24f, .163f, 1), false);
                if (!official)
                    ArenaArt.Part("Chest crest", kit, Forms.Quad, logo, new Vector3(-.103f, .38f, .197f),
                        new Vector3(.095f, .095f, 1), false).localRotation = Quaternion.Euler(0, 180, 0);
            }

            head = ArenaArt.Node("Head rig", kit, new Vector3(0, .615f, .008f));
            float cheeks = .295f + (variation % 4) * .012f;
            float skullDepth = .323f - (variation % 5) * .008f;
            ArenaArt.Part("Neck", head, Forms.Tube, complexion, new Vector3(0, -.068f, 0), new Vector3(.143f, .126f, .15f));
            ArenaArt.Part("Sculpted head", head, Forms.Head, complexion, new Vector3(0, -.007f, 0), new Vector3(cheeks, .357f, skullDepth));
            if (!simple)
            {
                for (int i = -1; i <= 1; i += 2)
                {
                    ArenaArt.Part("Ear", head, Forms.Ball, complexion, new Vector3(i * cheeks * .455f, .125f, 0),
                        new Vector3(.059f, .083f, .063f));
                    ArenaArt.Part("Eye", head, Forms.Ball, light, new Vector3(i * .058f, .193f, .136f), new Vector3(.058f, .027f, .027f), false);
                    ArenaArt.Part("Iris", head, Forms.Ball, pupil, new Vector3(i * .059f, .196f, .148f), new Vector3(.021f, .021f, .015f), false);
                    ArenaArt.Part("Brow", head, Forms.Sleeve, hair, new Vector3(i * .057f, .237f, .145f), new Vector3(.017f, .053f, .018f), false)
                        .localRotation = Quaternion.Euler(0, 0, i * 84f);
                }
                ArenaArt.Part("Nose", head, Forms.Ball, complexion, new Vector3(0, .139f, .145f), new Vector3(.053f, .089f, .066f));
                ArenaArt.Part("Mouth", head, Forms.Ball, hair, new Vector3(0, .102f, .132f), new Vector3(.072f, .012f, .025f), false);
                if (variation == 0 || variation == 3)
                    ArenaArt.Part("Short beard", head, Forms.Cap, hair, new Vector3(0, .148f, .025f), new Vector3(.23f, .14f, .235f))
                        .localRotation = Quaternion.Euler(180, 0, 0);
                if (variation == 1 || variation == 6 || variation == 7 || official)
                    ArenaArt.Part("Tied hair", head, Forms.Ball, hair, new Vector3(.032f, -.09f, -.141f),
                        new Vector3(.104f, .274f - (variation % 3) * .032f, .106f)).localRotation = Quaternion.Euler(-15, 0, -9);
            }
            cap = ArenaArt.Node("Field cap", head, new Vector3(0, .228f, -.006f));
            ArenaArt.Part("Panel crown", cap, Forms.Cap, official ? light : jersey, Vector3.zero, new Vector3(cheeks * 1.08f, .153f, skullDepth * 1.18f));
            ArenaArt.Part("Brim", cap, Forms.Ball, official ? light : stripe, new Vector3(0, -.011f, official ? .008f : .122f),
                official ? new Vector3(.456f, .036f, .416f) : new Vector3(.261f, .032f, .263f));
            helmet = ArenaArt.Node("Batting helmet", head, new Vector3(0, .135f, .007f));
            if (!simple && !official)
            {
                Material shell = art.Mat("Helmet " + team, team == 0 ? new Color(.04f, .13f, .36f) : new Color(.19f, .17f, .10f));
                ArenaArt.Part("Rounded helmet shell", helmet, Forms.Cap, shell, new Vector3(0, .078f, -.02f), new Vector3(.362f, .244f, .383f));
                ArenaArt.Part("Helmet visor", helmet, Forms.Ball, shell, new Vector3(0, .066f, .139f), new Vector3(.326f, .033f, .265f));
                for (int i = 0; i < 2; i++)
                    Rod("Guard wire", helmet, light, new Vector3(-.151f, i * .043f - .067f, .195f),
                        new Vector3(.151f, i * .043f - .067f, .195f), .014f);
                for (int i = -1; i <= 1; i += 2)
                    Rod("Guard strut", helmet, light, new Vector3(i * .165f, -.064f, .154f), new Vector3(i * .163f, .069f, .047f), .016f);
            }

            for (int i = 0; i < 2; i++)
            {
                upperArm[i] = ArenaArt.Node("Upper arm " + i, Root, Vector3.zero);
                ArenaArt.Part("Sleeve", upperArm[i], Forms.Sleeve, jersey, new Vector3(0, .465f, 0), new Vector3(.205f, .572f, .22f));
                ArenaArt.Part("Sleeve stripe", upperArm[i], Forms.Sleeve, stripe, new Vector3(0, .466f, 0), new Vector3(.205f, .152f, .21f));
                ArenaArt.Part("Upper arm skin", upperArm[i], Forms.Sleeve, complexion, Vector3.zero, new Vector3(.151f, .67f, .16f));
                forearm[i] = ArenaArt.Part("Forearm", Root, Forms.Sleeve, complexion, Vector3.zero, Vector3.one);
                hand[i] = ArenaArt.Part("Hand", Root, Forms.Ball, complexion, Vector3.zero, new Vector3(.116f, .144f, .099f));
                upperLeg[i] = ArenaArt.Part("Thigh", Root, Forms.Trousers, trousers, Vector3.zero, Vector3.one);
                lowerLeg[i] = ArenaArt.Part("Trouser calf", Root, Forms.Trousers, trousers, Vector3.zero, Vector3.one);
                kneePad[i] = ArenaArt.Node("Layered batting pad", lowerLeg[i], new Vector3(0, .07f, .26f));
                for (int rib = -1; rib <= 1; rib++)
                    ArenaArt.Part("Pad rib", kneePad[i], Forms.Tube, pads, new Vector3(rib * .238f, .04f, .30f),
                        new Vector3(.246f, .92f - Mathf.Abs(rib) * .08f, .58f));
                shoe[i] = ArenaArt.Node("Boot pivot", Root, Vector3.zero);
                ArenaArt.Part("Cricket shoe", shoe[i], Forms.Shoe, light, new Vector3(0, -.042f, .048f), new Vector3(.166f, .132f, .294f));
                ArenaArt.Part("Outsole", shoe[i], Forms.Shoe, sole, new Vector3(0, -.077f, .048f), new Vector3(.172f, .052f, .299f));
                if (!simple)
                    for (int stud = 0; stud < 3; stud++)
                        ArenaArt.Part("Stud", shoe[i], Forms.Tube, stripe, new Vector3((stud % 2 == 0 ? .048f : -.048f), -.081f, .13f - stud * .065f),
                            new Vector3(.032f, .04f, .032f));
            }

            finger = official ? ArenaArt.Part("Raised index finger", hand[1], Forms.Tube, complexion, new Vector3(0, .76f, 0),
                new Vector3(.25f, .43f, .25f)) : null;
            bat = ArenaArt.Node("Cricket bat rig", Root, Vector3.zero);
            if (!simple && !official)
            {
                Material willow = art.Mat("Bat willow grain", Color.white, "Willow");
                ArenaArt.Part("Willow blade", bat, Forms.Bat, willow, Vector3.zero, new Vector3(.151f, .685f, .083f));
                ArenaArt.Part("Blade shoulder", bat, Forms.Ball, stripe, new Vector3(0, .40f, -.042f), new Vector3(.11f, .22f, .011f));
                ArenaArt.Part("Bat grip", bat, Forms.Tube, sole, new Vector3(0, .622f, 0), new Vector3(.058f, .264f, .058f));
            }
            Dress(false);
        }

        public void Dress(bool batting)
        {
            bat.gameObject.SetActive(batting);
            helmet.gameObject.SetActive(batting);
            cap.gameObject.SetActive(!batting);
            foreach (Transform pad in kneePad) pad.gameObject.SetActive(batting);
            if (finger) finger.gameObject.SetActive(false);
        }

        public void Act(ActorPose pose, float elapsed, bool mirror = false, bool snap = false,
            Vector3? contact = null, int shotDirection = 0)
        {
            Frame target = Calculate(pose, elapsed, mirror ? -shotDirection : shotDirection);
            if (mirror)
            {
                Vector3 left = target.LHand;
                target.LHand = Mirror(target.RHand);
                target.RHand = Mirror(left);
                Vector3 foot = target.LFoot;
                target.LFoot = Mirror(target.RFoot);
                target.RFoot = Mirror(foot);
                target.Blade = Mirror(target.Blade);
                target.Twist = -target.Twist;
            }
            if (contact.HasValue)
            {
                Vector3 grip = (target.LHand + target.RHand) * .5f;
                Vector3 axis = (grip - target.Blade).normalized;
                Vector3 meetingGrip = contact.Value + axis * .43f;
                float blend = 1f - Mathf.SmoothStep(0, 1, elapsed / .16f);
                Vector3 shift = (meetingGrip - grip) * blend;
                target.LHand += shift;
                target.RHand += shift;
                target.Blade += shift;
            }
            float alpha = snap || !initialized ? 1 : 1f - Mathf.Exp(-Time.deltaTime * (pose == ActorPose.FastRelease ? 32f : 21f));
            if (!initialized)
            {
                initialized = true;
                current = target;
            }
            current.LHand = Vector3.Lerp(current.LHand, target.LHand, alpha);
            current.RHand = Vector3.Lerp(current.RHand, target.RHand, alpha);
            current.LFoot = Vector3.Lerp(current.LFoot, target.LFoot, alpha);
            current.RFoot = Vector3.Lerp(current.RFoot, target.RFoot, alpha);
            current.Blade = Vector3.Lerp(current.Blade, target.Blade, alpha);
            current.Dip = Mathf.Lerp(current.Dip, target.Dip, alpha);
            current.Lean = Mathf.Lerp(current.Lean, target.Lean, alpha);
            current.Twist = Mathf.Lerp(current.Twist, target.Twist, alpha);
            kit.localPosition = new Vector3(0, .98f + current.Dip, 0);
            kit.localRotation = Quaternion.Euler(current.Lean, current.Twist, 0);
            bool batting = pose >= ActorPose.Stance && pose <= ActorPose.Miss;
            head.localRotation = Quaternion.Euler(-current.Lean * .45f,
                -current.Twist * (batting ? .78f : .37f), 0);

            Leg(0, current.LFoot);
            Leg(1, current.RFoot);
            Arm(0, current.LHand);
            Arm(1, current.RHand);
            if (bat.gameObject.activeSelf)
            {
                Vector3 grip = (current.LHand + current.RHand) * .5f;
                Vector3 axis = (grip - current.Blade).normalized;
                bat.localPosition = grip - axis * .682f;
                bat.localRotation = Quaternion.FromToRotation(Vector3.up, axis);
                bat.localScale = Vector3.one;
            }
            if (finger) finger.gameObject.SetActive(pose == ActorPose.OutSignal && elapsed > .24f);
        }

        private void Arm(int i, Vector3 point)
        {
            float side = i == 0 ? -1f : 1f;
            Vector3 shoulder = kit.localPosition + kit.localRotation * new Vector3(side * (.266f * build), .465f, 0);
            Vector3 hinge = (shoulder + point) * .5f + new Vector3(side * .104f, -.065f, -.079f);
            Segment(upperArm[i], hinge, shoulder, 1, 1);
            Segment(forearm[i], point, hinge, .126f, .139f);
            hand[i].localPosition = point - Vector3.up * .048f;
        }

        private void Leg(int i, Vector3 foot)
        {
            float side = i == 0 ? -1f : 1f;
            Vector3 hip = new Vector3(side * .13f * build, .99f + current.Dip, 0);
            Vector3 knee = (hip + foot) * .5f + new Vector3(side * .027f, 0, .153f);
            Segment(upperLeg[i], knee, hip, .267f * build, .294f);
            Segment(lowerLeg[i], foot, knee, .213f * build, .228f);
            shoe[i].localPosition = foot;
        }

        private static Frame Calculate(ActorPose pose, float t, int shotDirection)
        {
            float breathe = .017f * Mathf.Sin(t * 3.2f);
            Frame f = new Frame
            {
                Dip = breathe, LHand = new Vector3(-.358f, .984f + breathe, .021f),
                RHand = new Vector3(.358f, .984f + breathe, .021f),
                LFoot = new Vector3(-.173f, .09f, .051f), RFoot = new Vector3(.172f, .09f, -.087f),
                Blade = new Vector3(.36f, .125f, .20f)
            };

            if (pose >= ActorPose.Stance && pose <= ActorPose.Miss)
            {
                f.Dip = -.13f + breathe;
                f.Lean = 13f;
                f.Twist = 52f;
                f.LFoot = new Vector3(-.13f, .09f, .29f);
                f.RFoot = new Vector3(.15f, .09f, -.27f);
                f.LHand = new Vector3(.32f, .81f, -.11f);
                f.RHand = new Vector3(.36f, .71f, -.16f);
                f.Blade = new Vector3(.54f, .10f, -.32f);
                if (pose == ActorPose.Stance) return f;
                if (pose == ActorPose.Prepare)
                {
                    float draw = Mathf.SmoothStep(0, 1, t);
                    f.Twist += draw * 16f;
                    f.LHand += new Vector3(.08f, .27f, -.19f) * draw;
                    f.RHand += new Vector3(.10f, .30f, -.19f) * draw;
                    f.Blade = Vector3.Lerp(f.Blade, new Vector3(.63f, 1.65f, -.72f), draw);
                    return f;
                }

                float follow = Mathf.SmoothStep(0, 1, Mathf.Clamp01(t / .40f));
                float recovery = Mathf.SmoothStep(0, 1, (t - .46f) / .22f);
                float finish = follow * (1f - .45f * recovery);
                bool loft = pose == ActorPose.Loft;
                bool defend = pose == ActorPose.Defend;
                bool across = pose == ActorPose.Cut || pose == ActorPose.Pull || pose == ActorPose.Flick;
                float direction = shotDirection != 0 ? shotDirection : pose == ActorPose.Miss ? -.65f : 1f;
                float elevation = loft ? 1.03f : across ? .56f : .76f;
                f.Twist = Mathf.Lerp(43f, 12f + direction * (defend ? 12f : 55f), finish);
                f.Lean = Mathf.Lerp(defend ? 21f : 14f, loft ? -22f : defend ? 14f : 4f, finish);
                f.Dip -= (defend ? .10f : .045f) * (1f - follow);
                f.LFoot.z += defend ? .22f : .34f;
                f.LFoot.x += direction * .12f * follow;
                f.LHand = new Vector3(.34f + direction * .30f * finish, .91f + (defend ? .08f : elevation) * finish,
                    Mathf.Lerp(.32f, across ? .25f : .62f, finish));
                f.RHand = f.LHand + new Vector3(.035f, -.105f, .024f);
                f.Blade = new Vector3(.51f + direction * .67f * finish,
                    Mathf.Lerp(across ? .67f : .33f, defend ? .60f : loft ? 2.68f : across ? 1.62f : 2.20f, finish),
                    Mathf.Lerp(.57f, across ? .02f : .74f, finish));
                return f;
            }

            if (pose == ActorPose.Run || pose == ActorPose.Walk || pose == ActorPose.Dismissed)
            {
                float pace = pose == ActorPose.Run ? 14.4f : 7.7f;
                float arc = Mathf.Sin(t * pace);
                float lift = pose == ActorPose.Run ? .27f : .13f;
                float stride = pose == ActorPose.Run ? .60f : .31f;
                f.Lean = pose == ActorPose.Dismissed ? 19f : pose == ActorPose.Run ? 15f : 4f;
                f.Dip = -.03f + .07f * Mathf.Abs(arc);
                f.Twist = arc * 13f;
                f.LFoot.z = arc * stride; f.RFoot.z = -arc * stride;
                f.LFoot.y += Mathf.Max(0, -arc) * lift; f.RFoot.y += Mathf.Max(0, arc) * lift;
                f.LHand.z = -arc * .36f; f.RHand.z = arc * .36f;
                f.LHand.y = 1.15f + Mathf.Max(0, -arc) * .16f; f.RHand.y = 1.15f + Mathf.Max(0, arc) * .16f;
                f.Blade = f.RHand + new Vector3(.45f, -.56f, .29f);
                return f;
            }

            if (pose == ActorPose.FastRelease || pose == ActorPose.SpinRelease)
            {
                float u = Mathf.Clamp01(t);
                f.RHand = new Vector3(.22f + Mathf.Sin(u * Mathf.PI) * (pose == ActorPose.SpinRelease ? .36f : .16f),
                    1.05f + .98f * u, Mathf.Lerp(-.58f, .32f, u));
                f.LHand = new Vector3(-.32f, 1.69f - .72f * u, .32f - .10f * u);
                f.LFoot.z = .40f;
                f.RFoot.z = -.53f;
                f.RFoot.y += .23f * u;
                f.Lean = u * 14f;
                f.Twist = -21f + u * 48f;
                float followThrough = Mathf.SmoothStep(0, 1, t - 1f);
                f.RHand = Vector3.Lerp(f.RHand, new Vector3(-.24f, .88f, .52f), followThrough);
                f.LHand = Vector3.Lerp(f.LHand, new Vector3(-.30f, 1.02f, -.22f), followThrough);
                f.RFoot.z += followThrough * .86f;
                f.Lean += followThrough * 11f;
                f.Twist += followThrough * 22f;
                return f;
            }

            float gesture = Mathf.SmoothStep(0, 1, t * 4.2f);
            switch (pose)
            {
                case ActorPose.Catch:
                    f.LHand = new Vector3(-.11f, 1.64f, .45f);
                    f.RHand = new Vector3(.11f, 1.64f, .45f);
                    f.Dip = -.10f;
                    break;
                case ActorPose.Pickup:
                    f.Lean = 38f;
                    f.Dip = -.33f;
                    f.RHand = new Vector3(.18f, .24f, .52f);
                    f.RFoot.z = -.39f;
                    break;
                case ActorPose.Throw:
                    f.RHand = new Vector3(.32f, 1.57f + Mathf.Sin(t * 10) * .44f, Mathf.Lerp(-.47f, .69f, gesture));
                    f.LHand.z = .55f - gesture * .47f;
                    f.Twist = 30 - gesture * 61f;
                    break;
                case ActorPose.Celebrate:
                    f.LHand = new Vector3(-.60f, 1.85f + .15f * Mathf.Sin(t * 10), .14f);
                    f.RHand = new Vector3(.54f, 1.89f - .19f * Mathf.Sin(t * 10), .20f);
                    f.Dip = Mathf.Max(0f, Mathf.Sin(t * 9.6f)) * .098f;
                    break;
                case ActorPose.OutSignal:
                    f.RHand = Vector3.Lerp(f.RHand, new Vector3(.31f, 2.13f, .12f), gesture);
                    break;
                case ActorPose.FourSignal:
                    f.RHand = Vector3.Lerp(f.RHand, new Vector3(.46f + .44f * Mathf.Sin(t * 13f), 1.45f, .36f), gesture);
                    break;
                case ActorPose.SixSignal:
                    f.LHand = Vector3.Lerp(f.LHand, new Vector3(-.28f, 2.16f, .10f), gesture);
                    f.RHand = Vector3.Lerp(f.RHand, new Vector3(.28f, 2.16f, .10f), gesture);
                    break;
                case ActorPose.WideSignal:
                    f.LHand = Vector3.Lerp(f.LHand, new Vector3(-.90f, 1.48f, .02f), gesture);
                    f.RHand = Vector3.Lerp(f.RHand, new Vector3(.90f, 1.48f, .02f), gesture);
                    break;
                case ActorPose.NoBallSignal:
                    f.RHand = Vector3.Lerp(f.RHand, new Vector3(.90f, 1.49f, .02f), gesture);
                    break;
                case ActorPose.IntervalSignal:
                    f.RHand = Vector3.Lerp(f.RHand, new Vector3(-.21f, 1.35f, .32f), gesture);
                    f.LHand = Vector3.Lerp(f.LHand, new Vector3(.21f, 1.35f, .36f), gesture);
                    break;
            }
            return f;
        }

        private static Vector3 Mirror(Vector3 p) => new Vector3(-p.x, p.y, p.z);

        private static void Segment(Transform t, Vector3 from, Vector3 to, float w, float d)
        {
            Vector3 direction = to - from;
            t.localPosition = from;
            t.localRotation = Quaternion.FromToRotation(Vector3.up, direction.normalized);
            t.localScale = new Vector3(w, direction.magnitude, d);
        }

        private static void Rod(string name, Transform root, Material material, Vector3 from, Vector3 to, float width)
        {
            Transform t = ArenaArt.Part(name, root, Forms.Tube, material, Vector3.zero, Vector3.one);
            Segment(t, from, to, width, width);
        }
    }
}
