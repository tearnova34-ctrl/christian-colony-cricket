using UnityEngine;

namespace ColonyCricket
{
    public static class PitchLayout
    {
        public static readonly Vector3 BowlerEndUmpire = new Vector3(0f, 0f, 10.87f);

        public static Vector3 SquareLegUmpire(bool leftHanded) =>
            new Vector3(leftHanded ? 5.25f : -5.25f, 0f, -7.92f);

        public static Vector3 ToWorld(Vector3 point, bool reverseEnd) =>
            reverseEnd ? new Vector3(-point.x, point.y, -point.z) : point;
    }
}
