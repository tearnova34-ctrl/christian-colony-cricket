using UnityEngine;

namespace ColonyCricket
{
    [System.Serializable]
    public struct BowlingAim
    {
        public DeliveryType Type;
        public float Line, LandingZ;
        public bool Overstep;
    }

    public sealed class DeliveryTrajectory
    {
        public const float BatZ = -8.79f;
        public const float StumpsZ = -10f;
        public const float BowlerCreaseZ = 8.78f;
        public const float Radius = .085f;
        private readonly Vector3 release;
        private readonly float speed, curve;
        private readonly bool spin;
        private readonly float bounceTime, bounceVelocity, postBounceX;
        public readonly BowlingAim Aim;
        public float BatTime => TimeAtZ(BatZ);
        public float StumpsTime => TimeAtZ(StumpsZ);
        public float Speed => speed;

        public DeliveryTrajectory(BowlingAim aim, Vector3 releasePosition, Difficulty difficulty)
        {
            Aim = aim;
            release = releasePosition;
            spin = CharacterDatabase.IsSpin(aim.Type);
            float baseSpeed = aim.Type == DeliveryType.Fast ? 24 : aim.Type == DeliveryType.MediumPace ? 20.9f :
                spin ? 16.8f : 22.2f;
            speed = baseSpeed * (difficulty == Difficulty.Easy ? .90f : difficulty == Difficulty.Hard ? 1.09f : 1f);
            curve = aim.Type == DeliveryType.OffSpin ? .34f : aim.Type == DeliveryType.LegSpin ? -.43f :
                aim.Type == DeliveryType.InSwing ? -.41f : aim.Type == DeliveryType.OutSwing ? .43f : 0f;
            bounceTime = TimeAtZ(aim.LandingZ);
            float preBounce = (Radius - release.y + 4.9f * bounceTime * bounceTime) / bounceTime;
            bounceVelocity = Mathf.Clamp(-(preBounce - 9.8f * bounceTime) * (spin ? .65f : .76f), 3.2f, 6.8f);
            postBounceX = aim.Line - (spin ? curve : 0f);
        }

        public Vector3 Position(float t)
        {
            float z = release.z - speed * t;
            float u = t / BatTime;
            float x = Mathf.LerpUnclamped(release.x, postBounceX, u);
            if (spin)
            {
                x += curve * Mathf.Max(0, (t - bounceTime) / (BatTime - bounceTime));
            }
            else
            {
                x += curve * u * (1f - u) * 4f;
            }

            float y;
            if (t <= bounceTime)
            {
                y = Mathf.Lerp(release.y, Radius, t / bounceTime) + 4.9f * t * (bounceTime - t);
            }
            else
            {
                float afterBounce = t - bounceTime;
                y = Mathf.Max(Radius, Radius + bounceVelocity * afterBounce - 4.9f * afterBounce * afterBounce);
            }
            return new Vector3(x, y, z);
        }

        public float TimeAtZ(float z) => (release.z - z) / speed;
        public bool HasBounced(float t) => t >= bounceTime;

        public bool HitsStumps()
        {
            Vector3 crossing = Position(StumpsTime);
            return Mathf.Abs(crossing.x) <= .19f + Radius && crossing.y <= .79f;
        }

        public bool IsWide()
        {
            Vector3 crossing = Position(StumpsTime);
            return Mathf.Abs(crossing.x) > 1.11f || crossing.y > 1.89f;
        }
    }

    public sealed class BallPhysicsController
    {
        public const float FieldX = 42f;
        public const float FieldZ = 48f;
        public const float ShotGravity = 12.4f;
        public Vector3 Position { get; private set; }
        public Vector3 Velocity { get; private set; }
        public bool Grounded { get; private set; }
        public bool BouncedThisStep { get; private set; }
        public int Boundary { get; private set; }
        public bool Rolling { get; private set; }

        [System.Serializable]
        public struct Flight
        {
            public Vector3 Position, Velocity;
            public bool Grounded, Rolling;
            public int Boundary;
        }

        internal Flight Capture() => new Flight { Position = Position, Velocity = Velocity, Grounded = Grounded,
            Rolling = Rolling, Boundary = Boundary };

        internal void Restore(Flight flight)
        {
            Position = flight.Position;
            Velocity = flight.Velocity;
            Grounded = flight.Grounded;
            Rolling = flight.Rolling;
            Boundary = flight.Boundary;
        }

        public void Launch(Vector3 position, Vector3 velocity)
        {
            Position = position;
            Velocity = velocity;
            Grounded = Rolling = BouncedThisStep = false;
            Boundary = 0;
        }

        public static float BoundaryDistance(Vector3 p) =>
            p.x * p.x / (FieldX * FieldX) + p.z * p.z / (FieldZ * FieldZ);

        public void Tick(float dt)
        {
            BouncedThisStep = false;
            Vector3 p = Position;
            Vector3 v = Velocity;
            if (Rolling)
            {
                v = Vector3.MoveTowards(v, Vector3.zero, dt * (4.8f + v.magnitude * .13f));
                p += v * dt;
            }
            else
            {
                v.x *= 1f - .025f * dt;
                v.z *= 1f - .025f * dt;
                float groundTime = (v.y + Mathf.Sqrt(v.y * v.y + 2f * ShotGravity *
                    Mathf.Max(0f, p.y - DeliveryTrajectory.Radius))) / ShotGravity;
                if (groundTime <= dt)
                {
                    Vector3 impact = p + v * groundTime - Vector3.up * (.5f * ShotGravity * groundTime * groundTime);
                    if (BoundaryDistance(impact) >= 1f && !Grounded)
                    {
                        Position = RopeCrossing(p, impact);
                        Boundary = 6;
                        return;
                    }

                    v.y -= ShotGravity * groundTime;
                    p = new Vector3(impact.x, DeliveryTrajectory.Radius, impact.z);
                    Grounded = true;
                    BouncedThisStep = true;
                    v = new Vector3(v.x * .83f, -v.y * .37f, v.z * .83f);
                    if (v.y < 1.22f)
                    {
                        v.y = 0f;
                        Rolling = true;
                    }
                }
                else
                {
                    p += v * dt - Vector3.up * (.5f * ShotGravity * dt * dt);
                    v.y -= ShotGravity * dt;
                }
            }

            if (BoundaryDistance(p) >= 1f)
            {
                p = RopeCrossing(Position, p);
                Boundary = Grounded ? 4 : 6;
            }
            Position = p;
            Velocity = v;
        }

        private static Vector3 RopeCrossing(Vector3 inside, Vector3 outside)
        {
            for (int i = 0; i < 9; i++)
            {
                Vector3 mid = (inside + outside) * .5f;
                if (BoundaryDistance(mid) >= 1) outside = mid;
                else inside = mid;
            }
            return outside;
        }
    }
}
