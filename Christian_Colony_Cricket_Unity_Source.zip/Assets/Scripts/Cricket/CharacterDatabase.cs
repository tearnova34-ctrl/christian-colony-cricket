using System;

namespace ColonyCricket
{
    public enum DeliveryType { Fast, MediumPace, OffSpin, LegSpin, InSwing, OutSwing }
    public enum Difficulty { Easy, Normal, Hard }

    public sealed class Cricketer
    {
        public readonly string Name;
        public readonly bool LeftHanded;
        public readonly float Power, Placement, Running, Height, Build;
        public readonly DeliveryType[] Deliveries;

        public Cricketer(string name, bool leftHanded, float power, float placement, float running,
            float height, float build, params DeliveryType[] deliveries)
        {
            Name = name;
            LeftHanded = leftHanded;
            Power = power;
            Placement = placement;
            Running = running;
            Height = height;
            Build = build;
            Deliveries = deliveries;
        }
    }

    public static class CharacterDatabase
    {
        public static readonly Cricketer[] Players =
        {
            new Cricketer("Rashid", false, 1.08f, 1f, 1f, 1.03f, 1.08f, DeliveryType.Fast, DeliveryType.InSwing, DeliveryType.OutSwing),
            new Cricketer("Aneeza", false, .99f, 1.09f, 1.02f, .98f, .95f, DeliveryType.OffSpin, DeliveryType.LegSpin),
            new Cricketer("Abdullah", true, 1.06f, 1.01f, 1.01f, 1.07f, 1.04f, DeliveryType.Fast, DeliveryType.MediumPace, DeliveryType.OutSwing),
            new Cricketer("Atif", false, 1.02f, 1.02f, 1f, 1.01f, 1.10f, DeliveryType.MediumPace, DeliveryType.InSwing),
            new Cricketer("Haadi", false, 1.10f, .98f, 1.04f, .91f, .91f, DeliveryType.LegSpin, DeliveryType.OffSpin),
            new Cricketer("Musa", true, 1.01f, 1.06f, 1.09f, .94f, .96f, DeliveryType.MediumPace, DeliveryType.Fast, DeliveryType.OutSwing),
            new Cricketer("Haram", false, .97f, 1.11f, 1.02f, .96f, .92f, DeliveryType.OffSpin, DeliveryType.MediumPace),
            new Cricketer("Hania", false, 1f, 1.07f, 1.03f, .93f, .94f, DeliveryType.MediumPace, DeliveryType.InSwing)
        };

        public static string DeliveryName(DeliveryType type)
        {
            switch (type)
            {
                case DeliveryType.MediumPace: return "Medium Pace";
                case DeliveryType.OffSpin: return "Off Spin";
                case DeliveryType.LegSpin: return "Leg Spin";
                case DeliveryType.InSwing: return "In Swing";
                case DeliveryType.OutSwing: return "Out Swing";
                default: return "Fast";
            }
        }

        public static bool IsSpin(DeliveryType type) => type == DeliveryType.OffSpin || type == DeliveryType.LegSpin;
    }

    public sealed class TeamManager
    {
        public static readonly string[] Names = { "Christian Colony Blue", "Christian Colony Gold" };
        private readonly int[,] roster = { { 0, 1, 2, 3 }, { 4, 5, 6, 7 } };

        public int PlayerId(int team, int slot) => roster[team, slot];
        public Cricketer Player(int team, int slot) => CharacterDatabase.Players[PlayerId(team, slot)];

        public void SwapPlayers(int teamA, int slotA, int teamB, int slotB)
        {
            if (teamA < 0 || teamA > 1 || teamB < 0 || teamB > 1 ||
                slotA < 0 || slotA > 3 || slotB < 0 || slotB > 3)
                throw new ArgumentOutOfRangeException();
            int first = roster[teamA, slotA];
            roster[teamA, slotA] = roster[teamB, slotB];
            roster[teamB, slotB] = first;
        }
    }
}
