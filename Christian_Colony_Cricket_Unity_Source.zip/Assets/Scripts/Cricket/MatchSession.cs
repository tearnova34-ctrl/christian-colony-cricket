using System;
using UnityEngine;

namespace ColonyCricket
{
    [Serializable]
    public sealed class MatchSession
    {
        public int Schema = 1;
        public bool Competition, SecondInnings, Interval;
        public int Overs, TossWinner, BattingFirst, PakistanCaptain, IndiaCaptain;
        public Difficulty Difficulty;
        public CricketRulesEngine.Totals FirstScore;
        public MatchManager.Snapshot Round;

        public int BattingTeam => SecondInnings ? 1 - BattingFirst : BattingFirst;
        public static string Team(int side) => side == 0 ? "PAKISTAN" : "INDIA";
        public static string ShortTeam(int side) => side == 0 ? "PAK" : "IND";
        public int Winner => !Competition ? (Round.Total.Runs >= Round.Target ? 0 : 1)
            : FirstScore.Runs == Round.Total.Runs ? -1
            : Round.Total.Runs > FirstScore.Runs ? BattingTeam : BattingFirst;
        public CricketRulesEngine.Totals Score(int team) => team == BattingTeam ? Round.Total : FirstScore;

        public static MatchSession Create(TeamManager teams, BattingMission mission, int seed, bool competition = false,
            int tossWinner = 0, int battingFirst = 0)
        {
            var session = new MatchSession { Competition = competition, Overs = mission.Overs, Difficulty = mission.Difficulty,
                TossWinner = tossWinner, BattingFirst = battingFirst, PakistanCaptain = teams.PlayerId(0, 0),
                IndiaCaptain = teams.PlayerId(1, 0) };
            session.Round = session.NewRound(mission.Target, seed).Capture();
            return session;
        }

        public MatchManager NewRound(int target, int seed)
        {
            int batter = BattingTeam == 0 ? PakistanCaptain : IndiaCaptain;
            int bowler = BattingTeam == 0 ? IndiaCaptain : PakistanCaptain;
            return new MatchManager(new BattingMission(Overs, Difficulty, target), seed, batter, bowler, BattingTeam == 1);
        }

        public void StartChase()
        {
            if (!Competition || SecondInnings) throw new InvalidOperationException("The first innings already ended.");
            FirstScore = Round.Total;
            SecondInnings = Interval = true;
            Round = NewRound(FirstScore.Runs + 1, unchecked(Round.Seed ^ 97111)).Capture();
        }
    }

    public static class MatchSave
    {
        private const string Key = "CCC.MatchResume.1";

        public static MatchSession Read()
        {
            string json = PlayerPrefs.GetString(Key);
            if (string.IsNullOrEmpty(json)) return null;
            try
            {
                MatchSession saved = JsonUtility.FromJson<MatchSession>(json);
                if (saved?.Round == null || saved.Schema != 1 ||
                    Array.IndexOf(BattingMission.Lengths, saved.Overs) < 0 ||
                    saved.Round.Total.Balls < 0 || saved.Round.Total.Balls > saved.Overs * 6 ||
                    saved.Round.Target < 0 || saved.PakistanCaptain < 0 || saved.PakistanCaptain >= CharacterDatabase.Players.Length ||
                    saved.IndiaCaptain < 0 || saved.IndiaCaptain >= CharacterDatabase.Players.Length)
                    return null;
                return saved;
            }
            catch (ArgumentException)
            {
                return null;
            }
        }

        public static void Write(MatchSession session)
        {
            PlayerPrefs.SetString(Key, JsonUtility.ToJson(session));
            PlayerPrefs.Save();
        }

        public static void Clear()
        {
            PlayerPrefs.DeleteKey(Key);
            PlayerPrefs.Save();
        }
    }
}
