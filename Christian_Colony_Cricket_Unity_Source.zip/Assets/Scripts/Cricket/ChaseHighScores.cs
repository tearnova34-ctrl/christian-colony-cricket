using System;
using System.Collections.Generic;
using UnityEngine;

namespace ColonyCricket
{
    [Serializable]
    public struct ChaseScore
    {
        public int Runs, Wickets, Balls, Target;
    }

    public static class ChaseHighScores
    {
        public const int Capacity = 5;

        [Serializable]
        private sealed class Board
        {
            public List<ChaseScore> Scores = new List<ChaseScore>();
        }

        public static IReadOnlyList<ChaseScore> Read(int overs, Difficulty difficulty) =>
            Load(Key(overs, difficulty)).Scores;

        public static void Record(BattingMission mission, CricketRulesEngine rules)
        {
            if (!rules.Won) return;

            string key = Key(mission.Overs, mission.Difficulty);
            Board board = Load(key);
            var score = new ChaseScore { Runs = rules.Runs, Wickets = rules.Wickets, Balls = rules.Balls, Target = rules.Target };
            int slot = board.Scores.FindIndex(entry => Compare(score, entry) < 0);
            if (slot < 0) slot = board.Scores.Count;
            if (slot >= Capacity) return;
            board.Scores.Insert(slot, score);
            if (board.Scores.Count > Capacity) board.Scores.RemoveAt(Capacity);
            PlayerPrefs.SetString(key, JsonUtility.ToJson(board));
            PlayerPrefs.Save();
        }

        private static string Key(int overs, Difficulty difficulty) => "CCC.TopChases." + overs + "." + difficulty;

        private static Board Load(string key)
        {
            string saved = PlayerPrefs.GetString(key);
            if (saved.Length == 0) return new Board();
            try
            {
                Board board = JsonUtility.FromJson<Board>(saved);
                return board?.Scores == null ? new Board() : board;
            }
            catch (ArgumentException)
            {
                return new Board();
            }
        }

        private static int Compare(ChaseScore a, ChaseScore b)
        {
            int runs = b.Runs.CompareTo(a.Runs);
            if (runs != 0) return runs;
            int balls = a.Balls.CompareTo(b.Balls);
            if (balls != 0) return balls;
            return a.Wickets.CompareTo(b.Wickets);
        }
    }
}
