using UnityEngine;

namespace ColonyCricket
{
    public sealed class FielderAI
    {
        public static readonly Vector3[] Stations =
        {
            new Vector3(0, 0, -12.6f),
            new Vector3(-7.8f, 0, -2.9f), new Vector3(8.3f, 0, -4.8f),
            new Vector3(-17f, 0, 8f), new Vector3(17.6f, 0, 12.8f),
            new Vector3(-23.2f, 0, -17.5f), new Vector3(24.5f, 0, -15.2f),
            new Vector3(-9f, 0, 27.5f), new Vector3(13.2f, 0, 30.6f)
        };
        public readonly Vector3 Home;
        public Vector3 Position { get; private set; }
        public Vector3 Heading { get; private set; } = Vector3.forward;
        public float Speed { get; private set; }
        private readonly float maxSpeed;

        public FielderAI(Vector3 home, float maxSpeed)
        {
            Home = Position = home;
            this.maxSpeed = maxSpeed;
        }

        public void Move(Vector3 target, float dt)
        {
            target.y = 0;
            Vector3 delta = target - Position;
            float distance = delta.magnitude;
            Speed = Mathf.MoveTowards(Speed, distance > .18f ? maxSpeed : 0, 19f * dt);
            if (distance < .035f) return;
            Heading = delta / distance;
            Position += Heading * Mathf.Min(distance, Speed * dt);
        }

        public void Reset()
        {
            Position = Home;
            Heading = (new Vector3(0, 0, DeliveryTrajectory.BatZ) - Home).normalized;
            Speed = 0;
        }
    }

    public sealed class RunningBetweenWickets
    {
        public static readonly Vector3 StrikerCrease = new Vector3(.48f, 0, -8.4f);
        public static readonly Vector3 NonStrikerCrease = new Vector3(1.9f, 0, 8.04f);
        private readonly float crossingTime;
        private float progress, delay = .29f;
        public int Completed { get; private set; }
        public bool Crossing { get; private set; }
        public bool Attempted { get; private set; }
        public Vector3 StrikerPosition => PositionOf(true);
        public Vector3 PartnerPosition => PositionOf(false);

        public RunningBetweenWickets(Cricketer striker, Cricketer partner)
        {
            crossingTime = 1.94f / Mathf.Min(striker.Running, partner.Running);
        }

        public void Tick(float dt, float estimatedTimeToReturn, int runLimit)
        {
            delay -= dt;
            if (delay > 0 || Completed >= runLimit) return;

            float safety = Completed == 0 ? -.12f : .19f;
            if (!Crossing && estimatedTimeToReturn > crossingTime + safety)
            {
                Crossing = Attempted = true;
                progress = 0;
            }
            if (!Crossing) return;
            progress += dt / crossingTime;
            if (progress < 1f) return;
            Completed++;
            progress = 0;
            Crossing = false;
            delay = .21f;
        }

        public bool VulnerableAt(WicketEnd end)
        {
            if (!Crossing) return false;
            float groundedAt = end == WicketEnd.Striker ? .92f : .93f;
            return progress < groundedAt;
        }

        private Vector3 PositionOf(bool originalStriker)
        {
            bool near = originalStriker == (Completed % 2 == 0);
            Vector3 origin = near ? StrikerCrease : NonStrikerCrease;
            Vector3 destination = near ? NonStrikerCrease : StrikerCrease;
            Vector3 point = Vector3.Lerp(origin, destination, progress);
            if (Crossing) point.x += (originalStriker ? -.78f : .60f) * Mathf.Sin(progress * Mathf.PI);
            return point;
        }
    }
}
