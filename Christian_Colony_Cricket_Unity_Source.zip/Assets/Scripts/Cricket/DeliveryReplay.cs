using System;
using UnityEngine;

namespace ColonyCricket
{
    [Serializable]
    public sealed class DeliveryReplay
    {
        public BowlingAim Aim;
        public Shot Shot;
        public Vector3 Release, Impact;
        public float GuardX, DeliveryTime, AfterTime;
        public bool Struck, ReverseEnd;
        public Difficulty Difficulty;
        public DeliveryResult Result;
        public FieldingSimulation.Play Fielding;
        public DeliveryReview Evidence;
    }

    public sealed class ReplayTimeline
    {
        private const float Step = 1f / 120f;
        private readonly DeliveryReplay data;
        private readonly DeliveryTrajectory trajectory;
        private readonly Vector3[] outgoing;

        public ReplayTimeline(DeliveryReplay data)
        {
            this.data = data;
            trajectory = new DeliveryTrajectory(data.Aim, data.Release, data.Difficulty);
            if (!data.Struck) return;
            var ball = new BallPhysicsController();
            ball.Launch(data.Impact, data.Shot.Velocity);
            outgoing = new Vector3[Mathf.CeilToInt(data.AfterTime / Step) + 2];
            outgoing[0] = data.Impact;
            for (int i = 1; i < outgoing.Length; i++)
            {
                float time = i * Step;
                if (data.Fielding.Collected && time >= data.Fielding.At)
                    outgoing[i] = FieldingSimulation.ReturnPosition(data.Fielding, time);
                else
                {
                    if (ball.Boundary == 0) ball.Tick(Step);
                    outgoing[i] = ball.Position;
                }
            }
        }

        public float Duration => data.DeliveryTime + data.AfterTime;
        public Vector3 Ball(float time)
        {
            if (time <= data.DeliveryTime) return trajectory.Position(Mathf.Max(0f, time));
            if (outgoing == null)
            {
                if (data.Evidence.Kind == Appeal.LegBefore)
                    return Vector3.Lerp(data.Impact, data.Evidence.AtWicket, Mathf.Clamp01((time - data.DeliveryTime) * 5.8f));
                return trajectory.Position(Mathf.Min(time, data.DeliveryTime + .145f));
            }
            float index = Mathf.Clamp((time - data.DeliveryTime) / Step, 0f, outgoing.Length - 2);
            int i = Mathf.FloorToInt(index);
            return Vector3.Lerp(outgoing[i], outgoing[i + 1], index - i);
        }
    }

}
