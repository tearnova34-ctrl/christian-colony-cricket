using System;
using UnityEngine;

namespace ColonyCricket
{
    [Serializable]
    public struct OverFigure
    {
        public int BatRuns, BallsFaced, BowlerRuns, Wickets, LegalBalls, Deliveries;
    }

    public sealed class OverScorecard
    {
        private readonly OverFigure[] overs;
        public int BatRuns { get; private set; }
        public int BallsFaced { get; private set; }
        internal int LegacyBatRuns { get; private set; }
        internal int LegacyBallsFaced { get; private set; }

        public OverScorecard(int length) => overs = new OverFigure[length];

        public int Length => overs.Length;
        public OverFigure At(int index) => overs[Mathf.Clamp(index, 0, overs.Length - 1)];

        internal bool Record(int over, DeliveryResult result)
        {
            int before = BatRuns;
            Change(over, result, 1);
            return before < 50 && BatRuns >= 50;
        }

        private void Change(int over, DeliveryResult result, int sign)
        {
            ref OverFigure row = ref overs[Mathf.Clamp(over, 0, overs.Length - 1)];
            row.Deliveries += sign;
            row.BowlerRuns += result.Runs * sign;
            if (result.Wicket) row.Wickets += sign;
            if (result.Call == BallCall.Wide) return;

            row.BatRuns += result.Runs * sign;
            row.BallsFaced += sign;
            row.LegalBalls += sign;
            BatRuns += result.Runs * sign;
            BallsFaced += sign;
        }

        internal bool Replace(int over, DeliveryResult original, DeliveryResult corrected)
        {
            Change(over, original, -1);
            return Record(over, corrected);
        }

        internal OverFigure[] Capture() => (OverFigure[])overs.Clone();

        internal void Restore(OverFigure[] entries, CricketRulesEngine.Totals legacy, int priorRuns = 0, int priorBalls = 0)
        {
            HistoricalOversUnavailable = priorBalls > 0 || priorRuns > 0;
            LegacyBatRuns = priorRuns;
            LegacyBallsFaced = priorBalls;
            if (entries != null && entries.Length == overs.Length)
            {
                Array.Copy(entries, overs, entries.Length);
            }
            else if (legacy.Deliveries > 0)
            {
                // The only recoverable batting totals from a pre-0.9 save are aggregate runs and balls.
                HistoricalOversUnavailable = true;
                LegacyBatRuns = Mathf.Max(0, legacy.Runs - (legacy.Deliveries - legacy.Balls));
                LegacyBallsFaced = legacy.Balls;
            }
            BatRuns = LegacyBatRuns;
            BallsFaced = LegacyBallsFaced;
            foreach (OverFigure row in overs)
            {
                BatRuns += row.BatRuns;
                BallsFaced += row.BallsFaced;
            }
        }

        public bool HistoricalOversUnavailable { get; internal set; }
    }
}
