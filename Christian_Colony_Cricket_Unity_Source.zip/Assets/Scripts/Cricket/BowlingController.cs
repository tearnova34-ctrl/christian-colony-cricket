using System;
using UnityEngine;

namespace ColonyCricket
{
    public static class BowlingController
    {
        public static BowlingAim Aim(DeliveryType type, Vector2 pitchPoint, bool overstep)
        {
            return new BowlingAim
            {
                Type = type, Line = Mathf.Clamp(pitchPoint.x, -1.48f, 1.48f),
                LandingZ = Mathf.Clamp(pitchPoint.y, -8.03f, .8f),
                Overstep = overstep
            };
        }

        public static BowlingAim ComputerAim(Cricketer bowler, Difficulty difficulty, System.Random random, int priorBoundary)
        {
            DeliveryType type = bowler.Deliveries[random.Next(bowler.Deliveries.Length)];
            float accuracy = difficulty == Difficulty.Easy ? .68f : difficulty == Difficulty.Hard ? .94f : .82f;
            float line = random.NextDouble() < accuracy
                ? (float)(random.NextDouble() - .5) * (difficulty == Difficulty.Hard ? 1.1f : 1.5f)
                : (float)(random.NextDouble() - .5) * 2.9f;
            float length = (float)random.NextDouble();
            float range = priorBoundary == 6 ? 7.8f : 6.1f;
            return Aim(type, new Vector2(line, -7.9f + length * range), false);
        }
    }

    public static class BattingController
    {
        public static bool Swipe(Vector2 start, Vector2 end, float screenWidth, float time, out ShotInput input)
        {
            Vector2 delta = end - start;
            input = default;
            if (Mathf.Abs(delta.x) < screenWidth * .065f || Mathf.Abs(delta.x) < Mathf.Abs(delta.y) * .68f)
                return false;
            input.Direction = delta.x < 0 ? -1 : 1;
            input.Strength = Mathf.InverseLerp(.065f, .52f, Mathf.Abs(delta.x) / screenWidth);
            input.Time = time;
            return true;
        }

        public static ShotInput ComputerShot(DeliveryTrajectory ball, Cricketer batter, Difficulty difficulty, System.Random random)
        {
            float window = difficulty == Difficulty.Hard ? .135f : difficulty == Difficulty.Easy ? .34f : .22f;
            float error = ((float)random.NextDouble() - (float)random.NextDouble()) * window * 1.45f;
            if (Mathf.Abs(ball.Aim.Line) > .75f || CharacterDatabase.IsSpin(ball.Aim.Type)) error *= 1.18f;
            int side = random.Next(2) == 0 ? -1 : 1;
            float strength = Mathf.Clamp01((float)random.NextDouble() * .88f + .04f + (batter.Power - 1) * .5f);
            return new ShotInput { Direction = side, Strength = strength, Time = ball.BatTime + error };
        }
    }
}
