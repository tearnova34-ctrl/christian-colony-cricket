using System;
using UnityEngine;

namespace ColonyCricket
{
    public static class BowlingController
    {
        public static BowlingAim Aim(DeliveryType type, Vector2 pitchPoint, bool overstep)
        {
            return new BowlingAim
            {
                Type = type, Line = Mathf.Clamp(pitchPoint.x, -1.48f, 1.48f),
                LandingZ = Mathf.Clamp(pitchPoint.y, -8.03f, .8f),
                Overstep = overstep
            };
        }

        public static BowlingAim ComputerAim(Cricketer bowler, Difficulty difficulty, System.Random random, int priorBoundary)
        {
            DeliveryType type = bowler.Deliveries[random.Next(bowler.Deliveries.Length)];
            float accuracy = difficulty == Difficulty.Easy ? .68f : difficulty == Difficulty.Hard ? .94f : .82f;
            float line = random.NextDouble() < accuracy
                ? (float)(random.NextDouble() - .5) * (difficulty == Difficulty.Hard ? 1.1f : 1.5f)
                : (float)(random.NextDouble() - .5) * 2.9f;
            float length = (float)random.NextDouble();
            float range = priorBoundary == 6 ? 7.8f : 6.1f;
            return Aim(type, new Vector2(line, -7.9f + length * range), false);
        }
    }

    public static class BattingController
    {
        public static bool Swipe(Vector2 start, Vector2 end, float screenWidth, float time, out ShotInput input)
        {
            Vector2 delta = end - start;
            float horizontal = Mathf.Abs(delta.x);
            float vertical = Mathf.Abs(delta.y);
            input = default;
            if (screenWidth <= 0f || (delta.y < 0f && vertical > horizontal)) return false;
            bool straight = horizontal < screenWidth * .05f || delta.y > horizontal * 1.08f;
            input.Direction = straight ? 0 : delta.x < 0 ? -1 : 1;
            float distance = (straight ? Mathf.Max(0f, delta.y) : delta.magnitude) / screenWidth;
            input.Strength = distance < .025f ? .39f : Mathf.Lerp(.30f, 1f, Mathf.InverseLerp(.025f, .42f, distance));
            input.Time = time;
            return true;
        }
    }
}
