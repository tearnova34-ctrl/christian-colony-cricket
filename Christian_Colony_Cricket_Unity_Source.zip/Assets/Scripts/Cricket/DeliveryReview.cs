using System;
using UnityEngine;

namespace ColonyCricket
{
    public enum Appeal { None, LegBefore, Catch }

    [Serializable]
    public struct DeliveryReview
    {
        public Appeal Kind;
        public bool OnFieldOut, ActualOut, PitchedLegal, ImpactInline, HitsWicket;
        public Vector3 Bounce, Impact, AtWicket;
        public float GroundTime, GloveTime;
        public bool CanReview => Kind != Appeal.None;

        public static DeliveryReview FromCatch(FieldingSimulation.Play play) => new DeliveryReview
        {
            Kind = play.Appealable ? Appeal.Catch : Appeal.None, ActualOut = play.ActuallyCaught, OnFieldOut = play.Caught,
            Impact = play.Pickup, GroundTime = play.FirstBounce, GloveTime = play.At
        };

        public static DeliveryReview FromPad(DeliveryTrajectory flight, bool leftHanded)
        {
            var bounce = flight.Position(flight.TimeAtZ(flight.Aim.LandingZ));
            var contact = flight.Position(flight.TimeAtZ(-9.29f));
            var atWicket = flight.Position(flight.StumpsTime);
            bool pitched = leftHanded ? bounce.x >= -.19f : bounce.x <= .19f;
            bool inline = Mathf.Abs(contact.x) < .36f;
            bool hits = flight.HitsStumps();
            bool outOnField = pitched && inline && Mathf.Abs(atWicket.x) <= .23f && atWicket.y <= .73f;
            return new DeliveryReview { Kind = Appeal.LegBefore, OnFieldOut = outOnField,
                ActualOut = pitched && inline && hits, PitchedLegal = pitched, ImpactInline = inline, HitsWicket = hits,
                Bounce = bounce, Impact = contact, AtWicket = atWicket };
        }

        public DeliveryResult Apply(DeliveryResult onField, int fieldRuns)
        {
            if (Kind == Appeal.LegBefore) onField.Call = ActualOut ? BallCall.Lbw : BallCall.Dot;
            if (Kind == Appeal.Catch) onField.Call = ActualOut ? BallCall.Caught : fieldRuns == 0 ? BallCall.Dot : BallCall.Runs;
            onField.Runs = Kind == Appeal.Catch && !ActualOut ? fieldRuns : 0;
            return onField;
        }
    }
}
