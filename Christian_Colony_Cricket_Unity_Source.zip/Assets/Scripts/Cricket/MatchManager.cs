using System;
using UnityEngine;

namespace ColonyCricket
{
    public enum PlayPhase { Ready, RunUp, Delivery, Decision, Finished }

    public sealed class MatchManager
    {
        private const float Step = 1f / 120f;
        public const float GuardLimit = .54f;
        private readonly int seed;
        public readonly bool UserBowls, Competition;
        private readonly bool firstEndReversed;
        public readonly BattingMission Mission;
        private Difficulty Difficulty => Mission.Difficulty;
        private readonly BallPhysicsController struckBall = new BallPhysicsController();
        private float accumulator, guardOffset, requestedGuard;
        private ShotInput? pendingShot;
        private bool bouncedDelivery, struck, swingCommitted, releaseLocked, reverseEnd, reviewed, loggedDelivery;
        private float releaseMark, playedTime;
        private CricketRulesEngine.Totals beforeCall;
        private DeliveryTrajectory delivery;

        public readonly CricketRulesEngine Rules;
        public readonly int StrikerId, BowlerId;
        public Cricketer Striker => CharacterDatabase.Players[StrikerId];
        public Cricketer Bowler => CharacterDatabase.Players[BowlerId];
        public BowlingAim Aim { get; private set; }
        public PlayPhase Phase { get; private set; }
        public float PhaseTime { get; private set; }
        public DeliveryResult LastResult { get; private set; }
        public Vector3 BallPosition { get; private set; }
        public Vector3 ContactPosition { get; private set; }
        public Vector3 ShotVelocity { get; private set; }
        public Shot LastShot { get; private set; }
        public float? ShotMeterMark { get; private set; }
        public DeliveryReplay LastReplay { get; private set; }
        public FieldingSimulation.Play Fielding { get; private set; }
        public DeliveryReview Evidence { get; private set; }
        public int ReviewsLeft { get; private set; } = 1;
        public readonly OverScorecard Scorecard;
        public bool HitFifty { get; private set; }
        public int OverIndex => Mathf.Clamp((Phase == PlayPhase.Decision ? beforeCall.Balls : Rules.Balls) / 6, 0, Mission.Overs - 1);
        public float RevealAt => Fielding.Collected ? Fielding.At : Fielding.Player >= 0 ? Fielding.EndAt :
            LastResult.Runs >= 4 ? LastResult.TravelTime : 0f;
        public float FiftyAt => RevealAt + (LastResult.RequiresSignal ? 1.44f : .46f);
        public bool ShowingFifty => Phase == PlayPhase.Decision && HitFifty && PhaseTime >= FiftyAt;
        public bool ShowingUmpire => Phase == PlayPhase.Decision && LastResult.RequiresSignal &&
            PhaseTime >= RevealAt && PhaseTime <= RevealAt + 1.42f && !ShowingFifty;
        private float FlightVisibility => Mathf.Max(Mathf.Max(1.18f, Fielding.EndAt), LastResult.Runs >= 4 ? LastResult.TravelTime + .01f : 0f);
        public bool CanReview => Phase == PlayPhase.Decision && PhaseTime >= RevealAt && Evidence.CanReview && !reviewed && ReviewsLeft > 0 &&
            (UserBowls != Evidence.OnFieldOut);
        public bool ReverseEnd => Competition && (Phase == PlayPhase.Ready ? firstEndReversed ^ ((Rules.Balls / 6) % 2 != 0) : reverseEnd);
        public static Vector3 World(Vector3 point, bool reversed) => PitchLayout.ToWorld(point, reversed);
        public Vector3 World(Vector3 point) => World(point, ReverseEnd);
        public bool ReleaseLocked => releaseLocked;
        public float ReleaseCursor => releaseLocked ? releaseMark : Mathf.Clamp01(PhaseTime / RunUpDuration);
        public float ReleaseError => releaseMark - .79f;
        public float PerfectWindow => Difficulty == Difficulty.Easy ? .093f : Difficulty == Difficulty.Hard ? .059f : .076f;
        public string ReleaseGrade => Mathf.Abs(ReleaseError) <= PerfectWindow ? "PERFECT RELEASE" :
            Mathf.Abs(ReleaseError) <= .17f ? "GOOD RELEASE" : ReleaseError < 0 ? "EARLY RELEASE" : "LATE RELEASE";
        public float DecisionDuration
        {
            get
            {
                float react = LastResult.RequiresSignal ? 1.70f : 1.18f;
                float normal = Mathf.Max(Competition ? 2.68f : 2.04f, Mathf.Max(Fielding.EndAt + .48f, RevealAt + react));
                if (Evidence.CanReview) normal = Mathf.Max(normal, Mathf.Max(3.6f, Fielding.At + 1.55f));
                return HitFifty ? Mathf.Max(normal, FiftyAt + 2.55f) : normal;
            }
        }
        public Vector3 UpcomingBounce { get; private set; }
        public bool ShowLandingPreview => Phase == PlayPhase.RunUp || (Phase == PlayPhase.Delivery && !bouncedDelivery);
        public bool BallVisible => Phase == PlayPhase.Delivery ||
            (Phase == PlayPhase.Decision && (struck ? PhaseTime < FlightVisibility : PhaseTime < .28f));
        public float TimingProgress => delivery == null ? 0 : Mathf.Clamp01(PhaseTime / delivery.BatTime);
        public float TimingGuideProgress => delivery == null ? 0f :
            ShotTimingSystem.MeterPosition(ShotTimingSystem.NormalizedError(
                PhaseTime - delivery.BatTime, delivery.Speed, Difficulty, Striker.Placement));
        public bool CanMoveGuard => !UserBowls && (Phase == PlayPhase.Ready || Phase == PlayPhase.RunUp);
        public float GuardStep => requestedGuard - guardOffset;
        public static Vector3 RunningStart => new Vector3(-.47f, 0, 14.65f);
        public static Vector3 RunningRelease => new Vector3(-.47f, 0, 9.0f);
        public Vector3 ReleasePoint => ReleaseFor(Aim);
        public Vector3 ReleaseFor(BowlingAim aim) => Crease(aim.Around) + new Vector3(-.22f, 2.03f * Bowler.Height, -.32f);
        public static Vector3 Crease(bool around) => RunningRelease + (around ? Vector3.right * 1.19f : Vector3.zero);
        public Vector3 BattingGuard => new Vector3((Striker.LeftHanded ? .62f : -.62f) + guardOffset, 0, -9.26f);
        public float RunUpDuration => UserBowls ? (CharacterDatabase.IsSpin(Aim.Type) ? 1.62f : 1.77f) :
            CharacterDatabase.IsSpin(Aim.Type) ? .85f : 1.12f;

        public event Action Changed;
        public event Action<Shot> Swing;
        public event Action Bounce;
        public event Action Release;
        public event Action<DeliveryResult> Decided;

        [Serializable]
        public sealed class Snapshot
        {
            public int Seed, Target;
            public PlayPhase Phase;
            public float PhaseTime, Accumulator, GuardOffset, RequestedGuard, MeterMark;
            public bool HasDelivery, Bounced, Struck, SwingCommitted, HasInput, HasMeterMark;
            public ShotInput Input;
            public Shot Shot;
            public BowlingAim Aim;
            public DeliveryResult Result;
            public CricketRulesEngine.Totals Total;
            public BallPhysicsController.Flight Flight;
            public Vector3 BallPosition, ContactPosition, ShotVelocity, UpcomingBounce;
            public DeliveryReplay Replay;
            public FieldingSimulation.Play Fielding;
            public DeliveryReview Evidence;
            public CricketRulesEngine.Totals BeforeCall;
            public bool ReleaseLocked, ReverseEnd, Reviewed, HasReviewState;
            public float ReleaseMark, PlayedTime;
            public int ReviewsLeft;
            public OverFigure[] Scorecard;
            public bool HitFifty, LoggedDelivery;
            public int LegacyBatRuns, LegacyBallsFaced;
        }

        public MatchManager(TeamManager teams, BattingMission mission, int seed)
            : this(mission, seed, teams.PlayerId(0, 0), teams.PlayerId(1, 0), false) { }

        internal MatchManager(BattingMission mission, int seed, int batter, int bowler, bool userBowls, bool competition = false, bool firstEndReversed = false)
        {
            StrikerId = batter;
            BowlerId = bowler;
            Mission = mission;
            this.seed = seed;
            UserBowls = userBowls;
            Competition = competition;
            this.firstEndReversed = firstEndReversed;
            reverseEnd = firstEndReversed;
            Rules = new CricketRulesEngine(mission);
            Scorecard = new OverScorecard(mission.Overs);
        }

        public static MatchManager Resume(MatchSession session)
        {
            Snapshot saved = session.Round;
            var match = session.NewRound(saved.Target, saved.Seed);
            match.Rules.Restore(saved.Total);
            match.Scorecard.Restore(saved.Scorecard, saved.Total, saved.LegacyBatRuns, saved.LegacyBallsFaced);
            match.loggedDelivery = saved.LoggedDelivery;
            match.HitFifty = saved.HitFifty;
            match.Phase = saved.Phase;
            match.PhaseTime = saved.PhaseTime;
            match.accumulator = saved.Accumulator;
            match.guardOffset = saved.GuardOffset;
            match.requestedGuard = saved.RequestedGuard;
            match.bouncedDelivery = saved.Bounced;
            match.struck = saved.Struck;
            match.swingCommitted = saved.SwingCommitted;
            if (saved.HasInput) match.pendingShot = saved.Input;
            if (saved.HasMeterMark) match.ShotMeterMark = saved.MeterMark;
            match.LastShot = saved.Shot;
            match.Aim = saved.Aim;
            match.LastResult = saved.Result;
            match.BallPosition = saved.BallPosition;
            match.ContactPosition = saved.ContactPosition;
            match.ShotVelocity = saved.ShotVelocity;
            match.UpcomingBounce = saved.UpcomingBounce;
            match.struckBall.Restore(saved.Flight);
            match.LastReplay = saved.Replay != null && saved.Replay.DeliveryTime > 0f ? saved.Replay : null;
            match.Fielding = saved.Fielding;
            match.Evidence = saved.Evidence;
            match.beforeCall = saved.BeforeCall;
            match.releaseLocked = saved.ReleaseLocked;
            match.releaseMark = saved.ReleaseMark;
            match.reverseEnd = saved.ReverseEnd;
            match.reviewed = saved.Reviewed;
            match.playedTime = saved.PlayedTime;
            if (saved.HasReviewState) match.ReviewsLeft = saved.ReviewsLeft;
            if (saved.HasDelivery) match.delivery = new DeliveryTrajectory(saved.Aim, match.ReleasePoint, match.Difficulty);
            return match;
        }

        public Snapshot Capture() => new Snapshot
        {
            Seed = seed, Target = Rules.Target, Phase = Phase, PhaseTime = PhaseTime, Accumulator = accumulator,
            GuardOffset = guardOffset, RequestedGuard = requestedGuard, HasDelivery = delivery != null, Bounced = bouncedDelivery,
            Struck = struck, SwingCommitted = swingCommitted, HasInput = pendingShot.HasValue, Input = pendingShot.GetValueOrDefault(),
            HasMeterMark = ShotMeterMark.HasValue, MeterMark = ShotMeterMark.GetValueOrDefault(), Shot = LastShot, Aim = Aim,
            Result = LastResult, Total = Rules.Capture(), Flight = struckBall.Capture(), BallPosition = BallPosition,
            ContactPosition = ContactPosition, ShotVelocity = ShotVelocity, UpcomingBounce = UpcomingBounce,
            Replay = LastReplay, Fielding = Fielding, Evidence = Evidence, BeforeCall = beforeCall, ReleaseLocked = releaseLocked,
            ReleaseMark = releaseMark, PlayedTime = playedTime, ReverseEnd = reverseEnd, Reviewed = reviewed,
            ReviewsLeft = ReviewsLeft, HasReviewState = true, Scorecard = Scorecard.Capture(), HitFifty = HitFifty,
            LoggedDelivery = loggedDelivery, LegacyBatRuns = Scorecard.LegacyBatRuns, LegacyBallsFaced = Scorecard.LegacyBallsFaced
        };

        private System.Random BallRandom(int salt) => new System.Random(unchecked(seed + (Rules.Deliveries + 1) * 486187739 + salt));

        private void SetComputerShot()
        {
            if (Mathf.Abs(ReleaseError) <= PerfectWindow && delivery.HitsStumps()) return;
            var rng = BallRandom(72931);
            float miss = Difficulty == Difficulty.Easy ? .34f : Difficulty == Difficulty.Hard ? .13f : .24f;
            Vector3 contact = delivery.Position(delivery.BatTime);
            float difficultLine = Mathf.Abs(contact.x) * .08f + (delivery.Speed > 24f ? .055f : 0f)
                + Mathf.Lerp(.13f, -.09f, Mathf.Clamp01(Mathf.Abs(ReleaseError) / .53f));
            if (rng.NextDouble() < miss + difficultLine) return;
            float spread = Difficulty == Difficulty.Easy ? .25f : Difficulty == Difficulty.Hard ? .105f : .18f;
            var shot = new ShotInput { Time = delivery.BatTime + ((float)rng.NextDouble() * 2f - 1f) * spread,
                Direction = rng.Next(-1, 2), Strength = Mathf.Lerp(.34f, 1f, (float)rng.NextDouble()) };
            pendingShot = shot;
        }

        public void StartBowl(BowlingAim aim)
        {
            if (Phase != PlayPhase.Ready || Rules.Complete) return;
            reverseEnd = ReverseEnd;
            Aim = aim;
            RecalculateDelivery();
            releaseLocked = reviewed = false;
            HitFifty = loggedDelivery = false;
            releaseMark = 1f;
            Fielding = default;
            Evidence = default;
            pendingShot = null;
            bouncedDelivery = struck = swingCommitted = false;
            ShotVelocity = Vector3.zero;
            LastShot = default;
            ShotMeterMark = null;
            PhaseChange(PlayPhase.RunUp);
        }

        public BowlingAim StumpsAim(DeliveryType type, bool around)
        {
            BowlingAim aim = BowlingController.Aim(type, new Vector2(0f, -8.03f), false);
            aim.Around = around;
            Vector3 release = ReleaseFor(aim);
            var estimate = new DeliveryTrajectory(aim, release, Difficulty);
            aim.Line = -estimate.Position(estimate.StumpsTime).x * estimate.BatTime / estimate.StumpsTime;
            return aim;
        }

        private void RecalculateDelivery()
        {
            delivery = new DeliveryTrajectory(Aim, ReleasePoint, Difficulty);
            UpcomingBounce = delivery.Position(delivery.TimeAtZ(Aim.LandingZ));
        }

        public void LockRelease(float extraTime = 0f)
        {
            if (!UserBowls || Phase != PlayPhase.RunUp || releaseLocked) return;
            releaseLocked = true;
            releaseMark = Mathf.Clamp01((PhaseTime + extraTime) / RunUpDuration);
            if (Mathf.Abs(ReleaseError) <= PerfectWindow) return;

            BowlingAim adjusted = Aim;
            adjusted.Line = Mathf.Clamp(adjusted.Line + ReleaseError * 1.41f, -1.55f, 1.55f);
            adjusted.LandingZ = Mathf.Clamp(adjusted.LandingZ + Mathf.Abs(ReleaseError) * 3f, -8.03f, .8f);
            adjusted.SpeedScale = Mathf.Lerp(.99f, .81f, Mathf.Clamp01(Mathf.Abs(ReleaseError) * 1.7f));
            Aim = adjusted;
            RecalculateDelivery();
        }

        public bool Review()
        {
            if (!CanReview) return false;
            reviewed = true;
            if (Evidence.ActualOut == Evidence.OnFieldOut)
            {
                ReviewsLeft--;
                return false;
            }
            Rules.Restore(beforeCall);
            DeliveryResult result = Evidence.Apply(LastResult, Fielding.CompletedRuns);
            Rules.Record(result);
            if (loggedDelivery)
                HitFifty = Scorecard.Replace(beforeCall.Balls / 6, LastResult, result);
            LastResult = result;
            if (LastReplay != null) LastReplay.Result = result;
            Decided?.Invoke(result);
            return true;
        }

        public void SubmitSwipe(Vector2 start, Vector2 end, float screenWidth, float elapsedSinceTick = 0f)
        {
            if (UserBowls || Phase != PlayPhase.Delivery || swingCommitted) return;
            if (!BattingController.Swipe(start, end, screenWidth, PhaseTime + elapsedSinceTick, out ShotInput shot)) return;
            pendingShot = shot;
            ShotMeterMark = ShotTimingSystem.MeterPosition(ShotTimingSystem.NormalizedError(
                shot.Time - delivery.BatTime, delivery.Speed, Difficulty, Striker.Placement));
            swingCommitted = true;
        }

        public void MoveGuard(int direction)
        {
            if (!CanMoveGuard || direction == 0) return;
            requestedGuard = Mathf.Clamp(requestedGuard + Mathf.Sign(direction) * .27f, -GuardLimit, GuardLimit);
        }

        public void Tick(float elapsed)
        {
            accumulator += Mathf.Min(.12f, elapsed);
            while (accumulator >= Step)
            {
                accumulator -= Step;
                PhaseTime += Step;
                if (CanMoveGuard)
                    guardOffset = Mathf.MoveTowards(guardOffset, requestedGuard, 3.6f * Step);
                switch (Phase)
                {
                    case PlayPhase.Ready:
                        if (!UserBowls && PhaseTime >= (Rules.Deliveries == 0 ? 1.55f : .25f))
                            StartBowl(BowlingController.ComputerAim(Bowler, Difficulty, BallRandom(913), LastResult.Runs));
                        break;
                    case PlayPhase.RunUp:
                        if (PhaseTime < RunUpDuration) break;
                        if (UserBowls && !releaseLocked) LockRelease();
                        BallPosition = delivery.Position(0);
                        if (UserBowls) SetComputerShot();
                        PhaseChange(PlayPhase.Delivery);
                        Release?.Invoke();
                        break;
                    case PlayPhase.Delivery:
                        AdvanceDelivery();
                        break;
                    case PlayPhase.Decision:
                        if (struck && PhaseTime < FlightVisibility)
                        {
                            if (Fielding.Collected && PhaseTime >= Fielding.At)
                                BallPosition = FieldingSimulation.ReturnPosition(Fielding, PhaseTime);
                            else if (struckBall.Boundary == 0)
                            {
                                struckBall.Tick(Step);
                                BallPosition = struckBall.Position;
                            }
                        }
                        if (PhaseTime >= DecisionDuration)
                            PhaseChange(Rules.Complete ? PlayPhase.Finished : PlayPhase.Ready);
                        break;
                }
            }
        }

        private void AdvanceDelivery()
        {
            BallPosition = delivery.Position(PhaseTime);
            if (!bouncedDelivery && delivery.HasBounced(PhaseTime))
            {
                bouncedDelivery = true;
                Bounce?.Invoke();
            }

            if (pendingShot.HasValue && PhaseTime >= Mathf.Max(pendingShot.Value.Time, delivery.BatTime - .062f))
            {
                Vector3 relativeLine = delivery.Position(delivery.BatTime) - Vector3.right * guardOffset;
                Shot shot = ShotResolver.Resolve(pendingShot.Value, delivery.BatTime, delivery.Speed,
                    relativeLine, Difficulty, Striker);
                pendingShot = null;
                if (shot.MadeContact && BallPosition.z >= DeliveryTrajectory.StumpsZ - .1f)
                {
                    ContactPosition = BallPosition;
                    ShotVelocity = shot.Velocity;
                    LastShot = shot;
                    struck = true;
                    struckBall.Launch(ContactPosition, shot.Velocity);
                    Swing?.Invoke(shot);
                    DeliveryResult result = CricketRulesEngine.ForShot(shot, Striker.LeftHanded, ContactPosition);
                    if (Competition)
                    {
                        Fielding = FieldingSimulation.Resolve(ContactPosition, shot.Velocity, Difficulty, UserBowls);
                        if (Fielding.Collected)
                        {
                            Evidence = DeliveryReview.FromCatch(Fielding);
                            result.Call = Fielding.Caught ? BallCall.Caught :
                                Fielding.CompletedRuns > 0 ? BallCall.Runs : BallCall.Dot;
                            result.Runs = Fielding.Caught ? 0 : Fielding.CompletedRuns;
                            result.ShotDistance = Fielding.Distance;
                        }
                    }
                    CompleteBall(result);
                    return;
                }
            }

            bool hitsStumps = delivery.HitsStumps();
            if (Competition && !(UserBowls && Mathf.Abs(ReleaseError) <= PerfectWindow && hitsStumps))
            {
                float padTime = delivery.TimeAtZ(-9.29f);
                if (PhaseTime >= padTime && PhaseTime < padTime + 2f * Step)
                {
                    Vector3 pad = delivery.Position(padTime);
                    float side = Striker.LeftHanded ? 1f : -1f;
                    float padX = side * .205f + guardOffset;
                    if (pad.y > .18f && pad.y < .90f && Mathf.Abs(pad.x - padX) < .235f &&
                        (hitsStumps || Mathf.Abs(delivery.Position(delivery.StumpsTime).x) < .49f))
                    {
                        Evidence = DeliveryReview.FromPad(delivery, Striker.LeftHanded);
                        ContactPosition = BallPosition = pad;
                        CompleteBall(new DeliveryResult { Call = Evidence.OnFieldOut ? BallCall.Lbw : BallCall.Dot, Timing = Timing.Miss });
                        return;
                    }
                }
            }
            if (PhaseTime < (hitsStumps ? delivery.StumpsTime : delivery.TimeAtZ(-11.7f))) return;
            var call = hitsStumps ? BallCall.Bowled : delivery.IsWide() ? BallCall.Wide : BallCall.Dot;
            CompleteBall(new DeliveryResult { Call = call, Runs = call == BallCall.Wide ? 1 : 0,
                Zone = ShotZone.Middle, Timing = Timing.Miss });
        }

        private void CompleteBall(DeliveryResult outcome)
        {
            beforeCall = Rules.Capture();
            Rules.Record(outcome);
            HitFifty = Scorecard.Record(beforeCall.Balls / 6, outcome);
            loggedDelivery = true;
            LastResult = outcome;
            playedTime = PhaseTime;
            LastReplay = new DeliveryReplay { Aim = Aim, Shot = LastShot, Release = ReleasePoint, Impact = ContactPosition,
                GuardX = BattingGuard.x, DeliveryTime = playedTime, AfterTime = struck ? Mathf.Max(1.32f, FlightVisibility + .12f) : .65f,
                Struck = struck, ReverseEnd = reverseEnd, Difficulty = Difficulty, Result = outcome,
                Fielding = Fielding, Evidence = Evidence };
            PhaseChange(PlayPhase.Decision);
            Decided?.Invoke(outcome);
        }

        private void PhaseChange(PlayPhase phase)
        {
            Phase = phase;
            PhaseTime = 0f;
            Changed?.Invoke();
        }
    }
}
