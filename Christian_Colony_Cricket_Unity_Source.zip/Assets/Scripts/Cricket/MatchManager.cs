using System;
using UnityEngine;

namespace ColonyCricket
{
    public enum PlayPhase { Ready, RunUp, Delivery, Decision, Finished }

    public sealed class MatchManager
    {
        private const float Step = 1f / 120f;
        public const float GuardLimit = .54f;
        private readonly System.Random random;
        public readonly BattingMission Mission;
        private Difficulty Difficulty => Mission.Difficulty;
        private readonly BallPhysicsController struckBall = new BallPhysicsController();
        private float accumulator, guardOffset, requestedGuard;
        private ShotInput? pendingShot;
        private bool bouncedDelivery, struck, swingCommitted;
        private DeliveryTrajectory delivery;

        public readonly CricketRulesEngine Rules;
        public readonly int StrikerId, BowlerId;
        public Cricketer Striker => CharacterDatabase.Players[StrikerId];
        public Cricketer Bowler => CharacterDatabase.Players[BowlerId];
        public BowlingAim Aim { get; private set; }
        public PlayPhase Phase { get; private set; }
        public float PhaseTime { get; private set; }
        public DeliveryResult LastResult { get; private set; }
        public Vector3 BallPosition { get; private set; }
        public Vector3 ContactPosition { get; private set; }
        public Vector3 ShotVelocity { get; private set; }
        public Shot LastShot { get; private set; }
        public float? ShotMeterMark { get; private set; }
        public Vector3 UpcomingBounce { get; private set; }
        public bool ShowLandingPreview => Phase == PlayPhase.RunUp || (Phase == PlayPhase.Delivery && !bouncedDelivery);
        public bool BallVisible => Phase == PlayPhase.Delivery ||
            (Phase == PlayPhase.Decision && (struck ? PhaseTime < .86f : PhaseTime < .28f));
        public float TimingProgress => delivery == null ? 0 : Mathf.Clamp01(PhaseTime / delivery.BatTime);
        public float TimingGuideProgress => delivery == null ? 0f :
            ShotTimingSystem.MeterPosition(ShotTimingSystem.NormalizedError(
                PhaseTime - delivery.BatTime, delivery.Speed, Difficulty, Striker.Placement));
        public bool CanMoveGuard => Phase == PlayPhase.Ready || Phase == PlayPhase.RunUp;
        public float GuardStep => requestedGuard - guardOffset;
        public static Vector3 RunningStart => new Vector3(-.47f, 0, 14.65f);
        public static Vector3 RunningRelease => new Vector3(-.47f, 0, 9.0f);
        public Vector3 ReleasePoint => RunningRelease + new Vector3(-.22f, 2.03f * Bowler.Height, -.32f);
        public Vector3 BattingGuard => new Vector3((Striker.LeftHanded ? .62f : -.62f) + guardOffset, 0, -9.26f);
        public float RunUpDuration => CharacterDatabase.IsSpin(Aim.Type) ? .85f : 1.12f;

        public event Action Changed;
        public event Action<Shot> Swing;
        public event Action Bounce;
        public event Action Release;
        public event Action<DeliveryResult> Decided;

        public MatchManager(TeamManager teams, BattingMission mission, int seed)
        {
            StrikerId = teams.PlayerId(0, 0);
            BowlerId = teams.PlayerId(1, 0);
            Mission = mission;
            random = new System.Random(seed);
            Rules = new CricketRulesEngine(mission);
        }

        public void StartBowl(BowlingAim aim)
        {
            if (Phase != PlayPhase.Ready || Rules.Complete) return;
            Aim = aim;
            delivery = new DeliveryTrajectory(Aim, ReleasePoint, Difficulty);
            UpcomingBounce = delivery.Position(delivery.TimeAtZ(aim.LandingZ));
            pendingShot = null;
            bouncedDelivery = struck = swingCommitted = false;
            ShotVelocity = Vector3.zero;
            LastShot = default;
            ShotMeterMark = null;
            PhaseChange(PlayPhase.RunUp);
        }

        public void SubmitSwipe(Vector2 start, Vector2 end, float screenWidth, float elapsedSinceTick = 0f)
        {
            if (Phase != PlayPhase.Delivery || swingCommitted) return;
            if (!BattingController.Swipe(start, end, screenWidth, PhaseTime + elapsedSinceTick, out ShotInput shot)) return;
            pendingShot = shot;
            ShotMeterMark = ShotTimingSystem.MeterPosition(ShotTimingSystem.NormalizedError(
                shot.Time - delivery.BatTime, delivery.Speed, Difficulty, Striker.Placement));
            swingCommitted = true;
        }

        public void MoveGuard(int direction)
        {
            if (!CanMoveGuard || direction == 0) return;
            requestedGuard = Mathf.Clamp(requestedGuard + Mathf.Sign(direction) * .27f, -GuardLimit, GuardLimit);
        }

        internal void DetachPresentation()
        {
            Changed = null;
            Swing = null;
            Bounce = null;
            Release = null;
            Decided = null;
        }

        public void Tick(float elapsed)
        {
            accumulator += Mathf.Min(.12f, elapsed);
            while (accumulator >= Step)
            {
                accumulator -= Step;
                PhaseTime += Step;
                if (CanMoveGuard)
                    guardOffset = Mathf.MoveTowards(guardOffset, requestedGuard, 3.6f * Step);
                switch (Phase)
                {
                    case PlayPhase.Ready:
                        if (PhaseTime >= (Rules.Deliveries == 0 ? 1.55f : .25f))
                            StartBowl(BowlingController.ComputerAim(Bowler, Difficulty, random, LastResult.Runs));
                        break;
                    case PlayPhase.RunUp:
                        if (PhaseTime < RunUpDuration) break;
                        BallPosition = delivery.Position(0);
                        PhaseChange(PlayPhase.Delivery);
                        Release?.Invoke();
                        break;
                    case PlayPhase.Delivery:
                        AdvanceDelivery();
                        break;
                    case PlayPhase.Decision:
                        if (struck && PhaseTime < .86f && struckBall.Boundary == 0)
                        {
                            struckBall.Tick(Step);
                            BallPosition = struckBall.Position;
                        }
                        if (PhaseTime >= 1.42f)
                            PhaseChange(Rules.Complete ? PlayPhase.Finished : PlayPhase.Ready);
                        break;
                }
            }
        }

        private void AdvanceDelivery()
        {
            BallPosition = delivery.Position(PhaseTime);
            if (!bouncedDelivery && delivery.HasBounced(PhaseTime))
            {
                bouncedDelivery = true;
                Bounce?.Invoke();
            }

            if (pendingShot.HasValue && PhaseTime >= Mathf.Max(pendingShot.Value.Time, delivery.BatTime - .062f))
            {
                Vector3 relativeLine = delivery.Position(delivery.BatTime) - Vector3.right * guardOffset;
                Shot shot = ShotResolver.Resolve(pendingShot.Value, delivery.BatTime, delivery.Speed,
                    relativeLine, Difficulty, Striker);
                pendingShot = null;
                if (shot.MadeContact && BallPosition.z >= DeliveryTrajectory.StumpsZ - .1f)
                {
                    ContactPosition = BallPosition;
                    ShotVelocity = shot.Velocity;
                    LastShot = shot;
                    struck = true;
                    struckBall.Launch(ContactPosition, shot.Velocity);
                    Swing?.Invoke(shot);
                    CompleteBall(CricketRulesEngine.ForShot(shot, Striker.LeftHanded, ContactPosition));
                    return;
                }
            }

            bool hitsStumps = delivery.HitsStumps();
            if (PhaseTime < (hitsStumps ? delivery.StumpsTime : delivery.TimeAtZ(-11.7f))) return;
            var call = hitsStumps ? BallCall.Bowled : delivery.IsWide() ? BallCall.Wide : BallCall.Dot;
            CompleteBall(new DeliveryResult { Call = call, Runs = call == BallCall.Wide ? 1 : 0,
                Zone = ShotZone.Middle, Timing = Timing.Miss });
        }

        private void CompleteBall(DeliveryResult outcome)
        {
            Rules.Record(outcome);
            LastResult = outcome;
            PhaseChange(PlayPhase.Decision);
            Decided?.Invoke(outcome);
        }

        private void PhaseChange(PlayPhase phase)
        {
            Phase = phase;
            PhaseTime = 0f;
            Changed?.Invoke();
        }
    }
}
