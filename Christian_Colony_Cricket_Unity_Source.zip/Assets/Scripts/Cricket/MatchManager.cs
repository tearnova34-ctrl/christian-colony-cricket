using System;
using UnityEngine;

namespace ColonyCricket
{
    public enum PlayPhase { Ready, RunUp, Delivery, Flight, Throw, Decision, Interval, Finished }

    public sealed class MatchManager
    {
        private const float Step = 1f / 120f;
        private readonly System.Random random;
        private readonly Difficulty difficulty;
        private readonly BallPhysicsController struckBall = new BallPhysicsController();
        private float accumulator, automaticBowlDelay, returnDuration, returnClock, flightTime;
        private Vector3 returnOrigin, returnDestination, chaseTarget;
        private WicketEnd returnEnd;
        private ShotInput? pendingShot;
        private bool shotAttempted, bouncedDelivery;
        private int chaser, backup, priorBoundary;
        private DeliveryResult currentDelivery;
        private BowlingAim aimed;
        private DeliveryTrajectory delivery;
        public readonly CricketRulesEngine Rules;
        public readonly TeamManager Teams;
        public readonly FielderAI[] Fielders;
        public PlayPhase Phase { get; private set; }
        public float PhaseTime { get; private set; }
        public Vector3 BallPosition { get; private set; }
        public bool BallVisible => Phase == PlayPhase.Delivery || Phase == PlayPhase.Flight || Phase == PlayPhase.Throw ||
            (Phase == PlayPhase.Decision && PhaseTime < .35f);
        public bool HumanBatting => Rules.Innings == 0;
        public int StrikerId => Teams.PlayerId(Rules.Innings, Rules.Current.Striker);
        public int PartnerId => Teams.PlayerId(Rules.Innings, Rules.Current.NonStriker);
        public int BowlerId => Teams.PlayerId(1 - Rules.Innings, Rules.BowlingSlot);
        public Cricketer Striker => CharacterDatabase.Players[StrikerId];
        public Cricketer Bowler => CharacterDatabase.Players[BowlerId];
        public RunningBetweenWickets Runners { get; private set; }
        public float TimingProgress => delivery == null ? 0 : Mathf.Clamp01(PhaseTime / delivery.BatTime);
        public BowlingAim Aim => aimed;
        public DeliveryResult LastResult { get; private set; }
        public string DismissedName { get; private set; }
        public string BatsmanAtDecision { get; private set; }
        public string BowlerAtDecision { get; private set; }
        public int ActiveFielder { get; private set; } = -1;
        public Vector3 RunningStart { get; } = new Vector3(-.72f, 0, 14f);
        public Vector3 RunningRelease => new Vector3(-.47f, 0, aimed.Overstep ? 8.43f : 9.0f);
        public Vector3 ReleasePoint => RunningRelease + new Vector3(-.22f, 2.03f * Bowler.Height, -.32f);
        public float RunUpDuration => CharacterDatabase.IsSpin(aimed.Type) ? .69f : .98f;

        public event Action Changed;
        public event Action<Shot> Swing;
        public event Action Bounce;
        public event Action Release;
        public event Action<DeliveryResult> Decided;

        public MatchManager(TeamManager teams, int overs, Difficulty level, int seed)
        {
            Teams = teams;
            difficulty = level;
            random = new System.Random(seed);
            Rules = new CricketRulesEngine(overs);
            Fielders = new FielderAI[FielderAI.Stations.Length];
            float speed = level == Difficulty.Easy ? 5.75f : level == Difficulty.Hard ? 7.55f : 6.68f;
            for (int i = 0; i < Fielders.Length; i++)
                Fielders[i] = new FielderAI(FielderAI.Stations[i], speed * (i == 0 ? .83f : 1f));
            Ready();
        }

        public void AdvanceContinued()
        {
            if (Phase != PlayPhase.Interval) return;
            Rules.ChangeInnings();
            priorBoundary = 0;
            Ready();
        }

        public void StartBowl(BowlingAim aim)
        {
            if (Phase != PlayPhase.Ready) return;
            aimed = aim;
            PhaseChange(PlayPhase.RunUp);
        }

        public void SubmitSwipe(Vector2 start, Vector2 end, float screenWidth, float elapsedSinceTick = 0)
        {
            if (!HumanBatting || Phase != PlayPhase.Delivery || shotAttempted || pendingShot.HasValue) return;
            if (BattingController.Swipe(start, end, screenWidth, PhaseTime + elapsedSinceTick, out ShotInput shot))
            {
                pendingShot = shot;
                if (shot.Time < delivery.BatTime - .29f)
                    TryStrike(shot);
            }
        }

        public void Tick(float elapsed)
        {
            accumulator += Mathf.Min(.12f, elapsed);
            while (accumulator >= Step)
            {
                accumulator -= Step;
                PhaseTime += Step;
                switch (Phase)
                {
                    case PlayPhase.Ready:
                        if (HumanBatting && PhaseTime >= automaticBowlDelay)
                            StartBowl(BowlingController.ComputerAim(Bowler, difficulty, random, priorBoundary));
                        break;
                    case PlayPhase.RunUp:
                        if (PhaseTime >= RunUpDuration) ReleaseBall();
                        break;
                    case PlayPhase.Delivery: AdvanceDelivery(); break;
                    case PlayPhase.Flight: AdvanceFlight(); break;
                    case PlayPhase.Throw: AdvanceThrow(); break;
                    case PlayPhase.Decision:
                        ReturnFielders();
                        if (PhaseTime >= (LastResult.Dismissal != Dismissal.None ? 2.05f : LastResult.Boundary > 0 ? 1.65f : .98f))
                        {
                            if (Rules.InningsEnded) PhaseChange(Rules.MatchEnded ? PlayPhase.Finished : PlayPhase.Interval);
                            else Ready();
                        }
                        break;
                }
            }
        }

        private void Ready()
        {
            automaticBowlDelay = Rules.Current.LegalBalls == 0 && Rules.Current.Extras == 0 ? 1.46f : .50f;
            pendingShot = null;
            shotAttempted = bouncedDelivery = false;
            delivery = null;
            Runners = null;
            currentDelivery = default;
            ActiveFielder = -1;
            foreach (FielderAI fielder in Fielders) fielder.Reset();
            aimed = BowlingController.Aim(Bowler.Deliveries[0], new Vector2(.12f, -5.55f), false);
            PhaseChange(PlayPhase.Ready);
        }

        private void ReleaseBall()
        {
            delivery = new DeliveryTrajectory(aimed, ReleasePoint, difficulty);
            BallPosition = delivery.Position(0);
            if (!HumanBatting) pendingShot = BattingController.ComputerShot(delivery, Striker, difficulty, random);
            currentDelivery.Extra = aimed.Overstep && RunningRelease.z < DeliveryTrajectory.BowlerCreaseZ ? Extra.NoBall : Extra.None;
            PhaseChange(PlayPhase.Delivery);
            Release?.Invoke();
        }

        private void AdvanceDelivery()
        {
            BallPosition = delivery.Position(PhaseTime);
            if (!bouncedDelivery && delivery.HasBounced(PhaseTime))
            {
                bouncedDelivery = true;
                Bounce?.Invoke();
            }

            if (pendingShot.HasValue && !shotAttempted)
            {
                ShotInput shot = pendingShot.Value;
                float contactTime = Mathf.Max(shot.Time, delivery.BatTime - .045f);
                if (PhaseTime >= contactTime && (contactTime <= delivery.StumpsTime || !delivery.HitsStumps()))
                {
                    TryStrike(shot);
                    if (Phase == PlayPhase.Flight) return;
                }
            }

            bool hitWicket = delivery.HitsStumps();
            float finish = hitWicket ? delivery.StumpsTime : delivery.TimeAtZ(-12.58f);
            if (PhaseTime < finish) return;
            if (!shotAttempted) Swing?.Invoke(new Shot { Timing = Timing.Miss, Stroke = Stroke.Miss });
            if (currentDelivery.Extra == Extra.None && delivery.IsWide()) currentDelivery.Extra = Extra.Wide;
            if (hitWicket && currentDelivery.Extra == Extra.None) currentDelivery.Dismissal = Dismissal.Bowled;
            ActiveFielder = hitWicket ? -1 : 0;
            CompleteBall();
        }

        private void TryStrike(ShotInput shotInput)
        {
            shotAttempted = true;
            Vector3 reach = delivery.Position(delivery.BatTime);
            Shot shot = ShotResolver.Resolve(shotInput, delivery.BatTime, delivery.Speed, reach, difficulty, Striker);
            // A late swing can reach behind the crease, up to the plane of the stumps.
            if (BallPosition.z < DeliveryTrajectory.StumpsZ - .12f)
                shot = new Shot { Timing = Timing.Miss, Stroke = Stroke.Miss };
            Swing?.Invoke(shot);
            if (!shot.MadeContact) return;
            struckBall.Launch(BallPosition, shot.Velocity);
            Runners = new RunningBetweenWickets(Striker, CharacterDatabase.Players[PartnerId]);
            flightTime = 0;
            ChooseChasers();
            PhaseChange(PlayPhase.Flight);
        }

        private void ChooseChasers()
        {
            chaseTarget = ClampField(struckBall.InterceptPoint());
            chaser = backup = -1;
            float best = float.MaxValue;
            float next = float.MaxValue;
            for (int i = 0; i < Fielders.Length; i++)
            {
                float cost = (Fielders[i].Position - chaseTarget).sqrMagnitude + (i == 0 && chaseTarget.z > -8f ? 75f : 0f);
                if (cost < best)
                {
                    next = best;
                    backup = chaser;
                    best = cost;
                    chaser = i;
                }
                else if (cost < next)
                {
                    next = cost;
                    backup = i;
                }
            }
        }

        private void AdvanceFlight()
        {
            flightTime += Step;
            struckBall.Tick(Step);
            BallPosition = struckBall.Position;
            if (struckBall.BouncedThisStep) Bounce?.Invoke();
            if (struckBall.Boundary != 0)
            {
                currentDelivery.Boundary = struckBall.Boundary;
                CompleteBall();
                return;
            }

            if (struckBall.Grounded || flightTime > .17f) chaseTarget = ClampField(struckBall.InterceptPoint());
            Fielders[chaser].Move(chaseTarget, Step);
            Vector3 support = ClampField(chaseTarget + (Fielders[backup].Home - chaseTarget).normalized * 1.9f);
            Fielders[backup].Move(support, Step);
            float nearest = float.MaxValue;
            int nearIndex = -1;
            for (int i = 0; i < Fielders.Length; i++)
            {
                float d = FlatDistance(Fielders[i].Position, BallPosition);
                if (d >= nearest) continue;
                nearest = d;
                nearIndex = i;
            }

            if (flightTime > .14f && !struckBall.Grounded && nearest < .86f &&
                BallPosition.y > .52f && BallPosition.y < 1.77f && struckBall.Velocity.y < -.40f)
            {
                if (currentDelivery.Extra == Extra.None)
                {
                    ActiveFielder = nearIndex;
                    currentDelivery.Dismissal = Dismissal.Caught;
                    CompleteBall();
                }
                else BeginThrow(nearIndex);
                return;
            }

            if (flightTime > .14f && struckBall.Grounded && nearest < .80f && BallPosition.y < .48f)
            {
                BeginThrow(nearIndex);
                return;
            }

            if (flightTime >= 9f)
            {
                currentDelivery.RunningRuns = Runners.Completed;
                CompleteBall();
                return;
            }

            float retrieval = FlatDistance(Fielders[chaser].Position, chaseTarget) / 6.5f;
            float returnTravel = DistanceToNearestWicket(chaseTarget) / 15.5f;
            float projected = retrieval + returnTravel + .39f;
            if (!struckBall.Grounded)
                projected = Mathf.Max(projected, .4f + Mathf.Max(0, struckBall.Velocity.y / 7f) + BallPosition.y / 4f);
            Runners.Tick(Step, projected, RunLimit());
            TryFinishChase();
        }

        private void BeginThrow(int fielder)
        {
            ActiveFielder = fielder;
            returnOrigin = Fielders[fielder].Position + Vector3.up * 1.35f;
            float near = Mathf.Abs(returnOrigin.z - DeliveryTrajectory.StumpsZ);
            float far = Mathf.Abs(returnOrigin.z - 10f);
            returnEnd = near <= far ? WicketEnd.Striker : WicketEnd.NonStriker;
            returnDestination = new Vector3(0, .62f, returnEnd == WicketEnd.Striker ? DeliveryTrajectory.StumpsZ : 10f);
            returnDuration = .24f + Vector3.Distance(returnOrigin, returnDestination) / 16.5f;
            returnClock = 0;
            PhaseChange(PlayPhase.Throw);
        }

        private void AdvanceThrow()
        {
            returnClock += Step;
            float remaining = returnDuration - returnClock;
            Runners.Tick(Step, remaining, RunLimit());
            if (TryFinishChase()) return;
            float u = Mathf.InverseLerp(.21f, returnDuration, returnClock);
            BallPosition = Vector3.Lerp(returnOrigin, returnDestination, u) + Vector3.up * (Mathf.Sin(u * Mathf.PI) * 1.05f);
            if (returnClock < returnDuration) return;
            currentDelivery.RunningRuns = Runners.Completed;
            if (Runners.VulnerableAt(returnEnd))
            {
                currentDelivery.Dismissal = Dismissal.RunOut;
                currentDelivery.WicketEnd = returnEnd;
            }
            CompleteBall();
        }

        private int RunLimit()
        {
            int neededWithExtra = Rules.Required - (currentDelivery.Extra == Extra.None ? 0 : 1);
            return Rules.Innings == 1 ? Mathf.Clamp(neededWithExtra, 0, 3) : 3;
        }

        private bool TryFinishChase()
        {
            if (Rules.Innings != 1 || Runners.Completed + currentDelivery.Total < Rules.Required) return false;
            currentDelivery.RunningRuns = Runners.Completed;
            CompleteBall();
            return true;
        }

        private void CompleteBall()
        {
            int battingTeam = Rules.Innings;
            int striker = StrikerId;
            int bowler = BowlerId;
            BatsmanAtDecision = CharacterDatabase.Players[striker].Name;
            BowlerAtDecision = CharacterDatabase.Players[bowler].Name;
            Rules.Record(currentDelivery, striker, bowler);
            LastResult = currentDelivery;
            if (Rules.LastDismissedSlot < 0) LastResult = WithoutWicket(LastResult);
            DismissedName = Rules.LastDismissedSlot >= 0 ? Teams.Player(battingTeam, Rules.LastDismissedSlot).Name : "";
            priorBoundary = LastResult.Boundary;
            PhaseChange(PlayPhase.Decision);
            Decided?.Invoke(LastResult);
        }

        private static DeliveryResult WithoutWicket(DeliveryResult result)
        {
            result.Dismissal = Dismissal.None;
            return result;
        }

        private void PhaseChange(PlayPhase phase)
        {
            Phase = phase;
            PhaseTime = 0;
            Changed?.Invoke();
        }

        private void ReturnFielders()
        {
            if (PhaseTime < .56f) return;
            foreach (FielderAI fielder in Fielders) fielder.Move(fielder.Home, Step);
        }

        private static float FlatDistance(Vector3 a, Vector3 b)
        {
            a.y = b.y = 0;
            return Vector3.Distance(a, b);
        }

        private static float DistanceToNearestWicket(Vector3 p) =>
            Mathf.Min(FlatDistance(p, new Vector3(0, 0, -10)), FlatDistance(p, new Vector3(0, 0, 10)));

        private static Vector3 ClampField(Vector3 target)
        {
            float normalizedDistance = BallPhysicsController.BoundaryDistance(target);
            return normalizedDistance <= .96f ? target : target * Mathf.Sqrt(.96f / normalizedDistance);
        }
    }
}
