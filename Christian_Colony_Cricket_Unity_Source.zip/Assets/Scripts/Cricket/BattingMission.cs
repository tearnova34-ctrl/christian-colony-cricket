using System;

namespace ColonyCricket
{
    public readonly struct BattingMission
    {
        public static readonly int[] Lengths = { 1, 2, 5, 10 };
        public readonly int Overs;
        public readonly Difficulty Difficulty;
        public readonly int Target;

        public BattingMission(int overs, Difficulty difficulty, int target)
        {
            if (Array.IndexOf(Lengths, overs) < 0) throw new ArgumentOutOfRangeException(nameof(overs));
            if (target < 1 || target > 36 * overs) throw new ArgumentOutOfRangeException(nameof(target));
            Overs = overs;
            Difficulty = difficulty;
            Target = target;
        }

        public static BattingMission Roll(int overs, Difficulty difficulty, Random random, int previous)
        {
            int minPerOver = difficulty == Difficulty.Easy ? 8 : difficulty == Difficulty.Normal ? 13 : 19;
            int maxPerOver = difficulty == Difficulty.Easy ? 12 : difficulty == Difficulty.Normal ? 18 : 24;
            int min = minPerOver * overs;
            int max = maxPerOver * overs;
            bool skipPrevious = previous >= min && previous <= max;
            int target = min + random.Next(max - min + (skipPrevious ? 0 : 1));
            if (skipPrevious && target >= previous) target++;
            return new BattingMission(overs, difficulty, target);
        }
    }
}
