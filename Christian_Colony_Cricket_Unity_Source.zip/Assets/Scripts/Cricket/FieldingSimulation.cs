using System;
using UnityEngine;

namespace ColonyCricket
{
    public static class FieldingSimulation
    {
        // Nine outfielders and one wicketkeeper, with the current bowler making eleven.
        public static readonly Vector3[] Homes =
        {
            new Vector3(-10,0,-17), new Vector3(-19,0,-9), new Vector3(-22,0,5),
            new Vector3(-13,0,21), new Vector3(0,0,27), new Vector3(15,0,21),
            new Vector3(22,0,6), new Vector3(19,0,-11), new Vector3(12,0,-22),
            new Vector3(.12f,0,-12.45f)
        };

        [Serializable]
        public struct Play
        {
            public bool Collected, Caught, Appealable, ActuallyCaught;
            public int Player, CompletedRuns;
            public float At, ReturnAt, FirstBounce, Distance, EndAt;
            public Vector3 Pickup, Origin;
        }

        public static Play Resolve(Vector3 hit, Vector3 velocity, Difficulty difficulty, bool userFields)
        {
            var ball = new BallPhysicsController();
            ball.Launch(hit, velocity);
            const float step = 1f / 120f;
            float speed = (difficulty == Difficulty.Hard ? 7.15f : difficulty == Difficulty.Easy ? 5.85f : 6.5f)
                * (userFields ? 1.06f : 1f);
            var play = new Play { Player = -1, Origin = hit, FirstBounce = -1f };

            for (int tick = 1; tick <= 960; tick++)
            {
                ball.Tick(step);
                float now = tick * step;
                var point = ball.Position;
                play.Distance = new Vector2(point.x - hit.x, point.z - hit.z).magnitude;
                play.EndAt = now;
                if (ball.BouncedThisStep && play.FirstBounce < 0f) play.FirstBounce = now;
                if (ball.Boundary > 0)
                {
                    float nearest = float.MaxValue;
                    for (int i = 0; i < Homes.Length; i++)
                    {
                        float distance = FlatDistance(Homes[i], point);
                        if (distance >= nearest) continue;
                        nearest = distance;
                        play.Player = i;
                    }
                    play.Pickup = point;
                    play.At = now;
                    return play;
                }
                if (point.y > 2.15f || now < .15f) continue;

                float best = float.MaxValue;
                for (int i = 0; i < Homes.Length; i++)
                {
                    float run = FlatDistance(Homes[i], point);
                    float reach = ball.Grounded ? .65f : .54f;
                    float arrival = .17f + Mathf.Max(0f, run - reach) / speed;
                    if (arrival > now || arrival >= best) continue;
                    best = arrival;
                    play.Player = i;
                }
                if (play.Player < 0) continue;

                play.At = now;
                play.Pickup = point;
                play.Collected = true;
                play.ActuallyCaught = play.FirstBounce < 0f;
                play.Appealable = play.ActuallyCaught ||
                    (play.FirstBounce >= 0f && now - play.FirstBounce < .095f && point.y > .16f);
                play.Caught = play.ActuallyCaught;
                if (play.Appealable && Mathf.Abs(point.y - .30f) < .20f && play.Player % 2 == 0)
                    play.Caught = !play.ActuallyCaught;
                Vector3 wicket = point.z < 0 ? new Vector3(0f, .64f, -10f) : new Vector3(0f, .64f, 10f);
                play.ReturnAt = now + .42f + FlatDistance(point, wicket) / 21f;
                play.EndAt = play.Caught ? now + .69f : play.ReturnAt + .24f;
                play.CompletedRuns = Mathf.Clamp(Mathf.FloorToInt((play.ReturnAt - .20f) / 1.60f), 0, 3);
                return play;
            }

            return play;
        }

        public static Vector3 FielderPosition(Play play, int player, float elapsed)
        {
            Vector3 start = Homes[player];
            if (play.Player < 0) return start;
            if (player == play.Player)
            {
                Vector3 destination = new Vector3(play.Pickup.x, 0f, play.Pickup.z);
                if (!play.Collected) destination = Vector3.MoveTowards(start, destination, Mathf.Max(0f, play.At - .17f) * 6.1f);
                return Vector3.Lerp(start, destination, Mathf.SmoothStep(0f, 1f, (elapsed - .17f) / Mathf.Max(.1f, play.At - .17f)));
            }
            // The two nearest teammates cover the return lane and back up the collector.
            float distance = FlatDistance(start, play.Pickup);
            if (distance > 17f) return start;
            Vector3 support = Vector3.MoveTowards(start, new Vector3(play.Pickup.x, 0, play.Pickup.z), 2.1f);
            return Vector3.Lerp(start, support, Mathf.SmoothStep(0f, 1f, (elapsed - .27f) / 1.1f));
        }

        public static Vector3 ReturnPosition(Play play, float elapsed)
        {
            if (elapsed < play.At + .42f || play.ActuallyCaught)
                return Vector3.Lerp(play.Pickup, new Vector3(play.Pickup.x, 1.12f, play.Pickup.z),
                    (elapsed - play.At) * 3.3f);
            Vector3 wicket = new Vector3(0f, .63f, play.Pickup.z < 0 ? -10f : 10f);
            float t = Mathf.InverseLerp(play.At + .42f, play.ReturnAt, elapsed);
            return Vector3.Lerp(new Vector3(play.Pickup.x, 1.29f, play.Pickup.z), wicket, t)
                + Vector3.up * (3f * t * (1f - t));
        }

        private static float FlatDistance(Vector3 a, Vector3 b) => new Vector2(a.x - b.x, a.z - b.z).magnitude;
    }
}
