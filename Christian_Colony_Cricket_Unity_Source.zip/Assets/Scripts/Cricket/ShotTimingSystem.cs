using UnityEngine;

namespace ColonyCricket
{
    public enum Timing { Perfect, Good, Ok, Early, Late, Miss }
    public enum Stroke { CoverDrive, Cut, OffDrive, Pull, Flick, OnDrive, Defensive, Loft, Miss }

    [System.Serializable]
    public struct ShotInput
    {
        public int Direction;
        public float Strength, Time;
    }

    public static class ShotTimingSystem
    {
        public const float PerfectLimit = .073f;
        public const float GoodLimit = .122f;
        public const float ContactLimit = .177f;
        public const float MishitLimit = .250f;
        public const float MeterLimit = .30f;

        public static float MeterPosition(float error) => Mathf.InverseLerp(-MeterLimit, MeterLimit, error);

        public static Timing Rate(float timingError, float speed, Difficulty difficulty, float placement)
        {
            float error = Mathf.Abs(NormalizedError(timingError, speed, difficulty, placement));
            if (error <= PerfectLimit) return Timing.Perfect;
            if (error <= GoodLimit) return Timing.Good;
            if (error <= ContactLimit) return Timing.Ok;
            if (error <= MishitLimit) return timingError < 0 ? Timing.Early : Timing.Late;
            return Timing.Miss;
        }

        public static float NormalizedError(float timingError, float speed, Difficulty difficulty, float placement)
        {
            float speedFactor = Mathf.Clamp(23f / speed, .81f, 1.13f);
            float window = (difficulty == Difficulty.Easy ? 1.23f : difficulty == Difficulty.Hard ? .87f : 1f)
                * speedFactor * placement;
            return timingError / window;
        }

        public static string Label(Timing timing)
        {
            switch (timing)
            {
                case Timing.Perfect: return "PERFECT!";
                case Timing.Good: return "GOOD TIMING!";
                case Timing.Ok: return "OK CONTACT";
                case Timing.Early: return "TOO EARLY";
                case Timing.Late: return "TOO LATE";
                default: return "MISS";
            }
        }
    }

    [System.Serializable]
    public struct Shot
    {
        public Timing Timing;
        public Stroke Stroke;
        public Vector3 Velocity;
        public int Direction;
        public bool MadeContact => Stroke != Stroke.Miss;
    }

    public static class ShotResolver
    {
        public static Shot Resolve(ShotInput input, float idealTime, float speed, Vector3 contact,
            Difficulty difficulty, Cricketer batter)
        {
            float error = input.Time - idealTime;
            Timing timing = ShotTimingSystem.Rate(error, speed, difficulty, batter.Placement);
            if (timing == Timing.Miss || Mathf.Abs(contact.x) > 1.13f || contact.y > 1.88f)
                return new Shot { Timing = Timing.Miss, Stroke = Stroke.Miss, Direction = input.Direction };

            float height = contact.y;
            bool edge = timing == Timing.Early || timing == Timing.Late;
            float quality = timing == Timing.Perfect ? 1f : timing == Timing.Good ? .84f : timing == Timing.Ok ? .64f : .43f;
            float strength = Mathf.Clamp01(input.Strength);
            float lineControl = Mathf.Lerp(1f, .81f, Mathf.InverseLerp(.68f, 1.13f, Mathf.Abs(contact.x)));
            float power = Mathf.Lerp(10f, 36f, strength) * quality * batter.Power * lineControl;
            bool loft = !edge && strength > .69f && quality >= .84f && height < 1.46f;
            bool defensive = strength < .28f && !edge;
            float angle = defensive ? 29 : height > 1.03f ? 82 : Mathf.Lerp(66, 40, strength);
            if (batter.LeftHanded && height < 1.02f) angle -= 7;
            angle += error * 58;
            if (timing == Timing.Early) angle += 28;
            if (timing == Timing.Late) angle += 76;
            angle *= Mathf.Deg2Rad;
            float lift = loft ? Mathf.Lerp(12f, 19.5f, strength) :
                edge ? (timing == Timing.Early ? 6.2f : 2.2f) : Mathf.Lerp(-3.4f, -1.5f, strength);
            Stroke stroke = defensive ? Stroke.Defensive : loft ? Stroke.Loft :
                input.Direction == 0 ? Stroke.OffDrive : input.Direction < 0 ? (height > 1.03f ? Stroke.Cut : strength > .52f ? Stroke.CoverDrive : Stroke.OffDrive) :
                (height > 1.03f ? Stroke.Pull : strength > .48f ? Stroke.OnDrive : Stroke.Flick);

            return new Shot
            {
                Timing = timing, Stroke = stroke, Direction = input.Direction,
                Velocity = new Vector3(input.Direction * Mathf.Sin(angle) * power, lift, (input.Direction == 0 ? 1f : Mathf.Cos(angle)) * power)
            };
        }
    }
}
