using System;
using UnityEngine;

namespace ColonyCricket
{
    public enum BallCall { Dot, Runs, Bowled, Wide, Caught, Lbw }
    public enum ShotZone { Middle, Off, Leg, Straight }

    [Serializable]
    public struct DeliveryResult
    {
        public BallCall Call;
        public int Runs;
        public float ShotDistance, TravelTime;
        public Timing Timing;
        public ShotZone Zone;

        public bool RequiresSignal => Wicket || Runs >= 4;

        public bool Wicket => Call == BallCall.Bowled || Call == BallCall.Caught || Call == BallCall.Lbw;

        public string VoiceKey => Call == BallCall.Runs ? Zone.ToString() + Runs :
            Call == BallCall.Dot && Zone == ShotZone.Middle ? "Beaten" : Call.ToString();

        public string OutcomeLabel => Call == BallCall.Runs ? Runs == 1 ? "1 RUN" : Runs + " RUNS" :
            Call == BallCall.Wide ? "WIDE  +1" : Wicket ? Call.ToString().ToUpperInvariant() : "DOT BALL";

        public string DirectionLabel => Zone == ShotZone.Off ? "OFF SIDE" :
            Zone == ShotZone.Leg ? "LEG SIDE" : Zone == ShotZone.Straight ? "STRAIGHT" : "";
    }

    public sealed class CricketRulesEngine
    {
        public readonly int BallLimit;
        public readonly int Target;
        public int Remaining => Mathf.Max(0, Target - Runs);
        public bool Won => Target > 0 && Runs >= Target;
        public int Runs { get; private set; }
        public int Wickets { get; private set; }
        public int Balls { get; private set; }
        public int Deliveries { get; private set; }
        public bool Complete => Won || Wickets >= 3 || Balls >= BallLimit;

        public CricketRulesEngine(BattingMission mission)
        {
            BallLimit = mission.Overs * 6;
            Target = mission.Target;
        }

        [Serializable]
        public struct Totals
        {
            public int Runs, Wickets, Balls, Deliveries;
            public string Score => Runs + "/" + Wickets;
        }

        public Totals Capture() => new Totals { Runs = Runs, Wickets = Wickets, Balls = Balls, Deliveries = Deliveries };

        internal void Restore(Totals totals)
        {
            Runs = totals.Runs;
            Wickets = totals.Wickets;
            Balls = totals.Balls;
            Deliveries = totals.Deliveries;
        }

        public static DeliveryResult ForShot(Shot shot, bool leftHanded, Vector3 impact)
        {
            if (!shot.MadeContact) throw new ArgumentException("Shot must make contact.", nameof(shot));
            ShotZone zone = shot.Direction == 0 ? ShotZone.Straight :
                (shot.Direction > 0) != leftHanded ? ShotZone.Off : ShotZone.Leg;

            var preview = new BallPhysicsController();
            preview.Launch(impact, shot.Velocity);
            int ticks = 0;
            for (; ticks < 1200 && preview.Boundary == 0 && (!preview.Rolling || preview.Velocity.sqrMagnitude > .01f); ticks++)
                preview.Tick(1f / 120f);
            Vector3 travelled = preview.Position - impact;
            float distance = new Vector2(travelled.x, travelled.z).magnitude;
            int runs = preview.Boundary;
            if (runs == 0)
            {
                switch (shot.Timing)
                {
                    case Timing.Perfect: runs = distance >= 30f ? 3 : distance >= 17f ? 2 : distance >= 6f ? 1 : 0; break;
                    case Timing.Good: runs = distance >= 34f ? 3 : distance >= 21f ? 2 : distance >= 8f ? 1 : 0; break;
                    case Timing.Ok: runs = distance >= 25f ? 2 : distance >= 10f ? 1 : 0; break;
                    default: runs = 0; break;
                }
            }

            return new DeliveryResult { Call = runs == 0 ? BallCall.Dot : BallCall.Runs,
                Runs = runs, Timing = shot.Timing, Zone = zone, ShotDistance = distance, TravelTime = ticks / 120f };
        }

        public void Record(DeliveryResult result)
        {
            if (Complete) throw new InvalidOperationException("This batting round is over.");
            Deliveries++;
            if (result.Call != BallCall.Wide) Balls++;
            if (result.Wicket) Wickets++;
            Runs += result.Runs;
        }
    }
}
