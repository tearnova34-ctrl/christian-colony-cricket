using System;
using UnityEngine;

namespace ColonyCricket
{
    public enum BallCall { Dot, Runs, Bowled, Wide }
    public enum ShotZone { Middle, Off, Leg, Straight }

    public struct DeliveryResult
    {
        public BallCall Call;
        public int Runs;
        public Timing Timing;
        public ShotZone Zone;

        public string VoiceKey => Call == BallCall.Runs ? Zone.ToString() + Runs :
            Call == BallCall.Dot && Zone == ShotZone.Middle ? "Beaten" : Call.ToString();

        public string OutcomeLabel => Call == BallCall.Runs ? Runs == 1 ? "1 RUN" : Runs + " RUNS" :
            Call == BallCall.Wide ? "WIDE  +1" : Call == BallCall.Bowled ? "BOWLED" : "DOT BALL";

        public string DirectionLabel => Zone == ShotZone.Off ? "OFF SIDE" :
            Zone == ShotZone.Leg ? "LEG SIDE" : Zone == ShotZone.Straight ? "STRAIGHT" : "";
    }

    public sealed class CricketRulesEngine
    {
        public readonly int BallLimit;
        public int Runs { get; private set; }
        public int Wickets { get; private set; }
        public int Balls { get; private set; }
        public int Deliveries { get; private set; }
        public bool Complete => Wickets >= 3 || Balls >= BallLimit;

        public CricketRulesEngine(int overs)
        {
            if (overs != 1 && overs != 2 && overs != 5) throw new ArgumentOutOfRangeException(nameof(overs));
            BallLimit = overs * 6;
        }

        public static DeliveryResult ForShot(Shot shot, bool leftHanded, Vector3 impact)
        {
            if (!shot.MadeContact) throw new ArgumentException("Shot must make contact.", nameof(shot));
            ShotZone zone = shot.Direction == 0 ? ShotZone.Straight :
                (shot.Direction < 0) != leftHanded ? ShotZone.Off : ShotZone.Leg;
            int runs;
            if (shot.Timing == Timing.Perfect)
            {
                // A perfect strike is worth four, with six reserved for a strong loft.
                // The preview uses the same trajectory as the ball drawn in the scene.
                bool aerialBoundary = false;
                if (shot.Stroke == Stroke.Loft)
                {
                    var preview = new BallPhysicsController();
                    preview.Launch(impact, shot.Velocity);
                    for (int i = 0; i < 240 && !preview.Grounded && preview.Boundary == 0; i++)
                        preview.Tick(1f / 60f);
                    aerialBoundary = preview.Boundary == 6;
                }
                runs = aerialBoundary ? 6 : 4;
            }
            else if (shot.Timing == Timing.Good)
                runs = Mathf.Abs(shot.Velocity.x) + Mathf.Abs(shot.Velocity.z) > 26f ? 3 : 2;
            else runs = shot.Timing == Timing.Ok ? 1 : 0;

            return new DeliveryResult { Call = runs == 0 ? BallCall.Dot : BallCall.Runs,
                Runs = runs, Timing = shot.Timing, Zone = zone };
        }

        public void Record(DeliveryResult result)
        {
            if (Complete) throw new InvalidOperationException("This batting round is over.");
            Deliveries++;
            if (result.Call != BallCall.Wide) Balls++;
            if (result.Call == BallCall.Bowled) Wickets++;
            Runs += result.Runs;
        }
    }
}
