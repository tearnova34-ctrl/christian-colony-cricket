using System;

namespace ColonyCricket
{
    public enum Extra { None, Wide, NoBall }
    public enum Dismissal { None, Bowled, Caught, RunOut }
    public enum WicketEnd { Striker, NonStriker }

    public struct DeliveryResult
    {
        public int RunningRuns, Boundary;
        public Extra Extra;
        public Dismissal Dismissal;
        public WicketEnd WicketEnd;
        public int Total => RunningRuns + Boundary + (Extra == Extra.None ? 0 : 1);
    }

    public sealed class InningsScore
    {
        public int Runs { get; internal set; }
        public int Wickets { get; internal set; }
        public int LegalBalls { get; internal set; }
        public int Extras { get; internal set; }
        public int Striker { get; internal set; }
        public int NonStriker { get; internal set; } = 1;
        public int NextBat { get; internal set; } = 2;
        public string Overs => $"{LegalBalls / 6}.{LegalBalls % 6}";
    }

    public sealed class CricketRulesEngine
    {
        public readonly InningsScore[] Scores = { new InningsScore(), new InningsScore() };
        public readonly int OversPerInnings;
        public readonly int[] BattingRuns = new int[8];
        public readonly int[] BattingBalls = new int[8];
        public readonly int[] BowlingBalls = new int[8];
        public readonly int[] BowlingRuns = new int[8];
        public readonly int[] BowlingWickets = new int[8];
        public int Innings { get; private set; }
        public bool InningsEnded { get; private set; }
        public bool MatchEnded => Innings == 1 && InningsEnded;
        public InningsScore Current => Scores[Innings];
        public int Target => Innings == 1 ? Scores[0].Runs + 1 : 0;
        public int Required => Innings == 1 ? Math.Max(0, Target - Current.Runs) : 0;
        public int RemainingBalls => OversPerInnings * 6 - Current.LegalBalls;
        public int BowlingSlot => Current.LegalBalls / 6 % 4;
        public int Winner => !MatchEnded || Scores[0].Runs == Scores[1].Runs ? -1 : Scores[0].Runs > Scores[1].Runs ? 0 : 1;
        public int LastDismissedSlot { get; private set; } = -1;

        public CricketRulesEngine(int overs)
        {
            if (overs != 1 && overs != 2 && overs != 5)
                throw new ArgumentOutOfRangeException(nameof(overs));
            OversPerInnings = overs;
        }

        public void Record(DeliveryResult delivery, int strikerId, int bowlerId)
        {
            if (InningsEnded) throw new InvalidOperationException("The innings is over.");
            if (delivery.RunningRuns < 0 || delivery.RunningRuns > 3 ||
                (delivery.Boundary != 0 && delivery.Boundary != 4 && delivery.Boundary != 6) ||
                (delivery.Boundary != 0 && delivery.RunningRuns != 0))
                throw new ArgumentException("Invalid delivery score.", nameof(delivery));

            InningsScore score = Current;
            if (delivery.Extra == Extra.None) score.LegalBalls++;
            else score.Extras++;
            score.Runs += delivery.Total;
            BowlingRuns[bowlerId] += delivery.Total;
            if (delivery.Extra == Extra.None) BowlingBalls[bowlerId]++;
            if (delivery.Extra != Extra.Wide) BattingBalls[strikerId]++;
            BattingRuns[strikerId] += delivery.Boundary + (delivery.Extra == Extra.Wide ? 0 : delivery.RunningRuns);

            if (delivery.RunningRuns % 2 == 1) SwapStrike(score);
            LastDismissedSlot = -1;
            bool chased = Innings == 1 && score.Runs >= Target;
            bool validWicket = delivery.Dismissal == Dismissal.RunOut ||
                (delivery.Extra == Extra.None && delivery.Dismissal != Dismissal.None);
            if (validWicket && !chased)
            {
                bool strikerEnd = delivery.Dismissal != Dismissal.RunOut || delivery.WicketEnd == WicketEnd.Striker;
                LastDismissedSlot = strikerEnd ? score.Striker : score.NonStriker;
                score.Wickets++;
                if (delivery.Dismissal != Dismissal.RunOut) BowlingWickets[bowlerId]++;
                if (score.Wickets < 3)
                {
                    if (strikerEnd) score.Striker = score.NextBat++;
                    else score.NonStriker = score.NextBat++;
                }
            }

            InningsEnded = score.Wickets == 3 || RemainingBalls == 0 || chased;
            if (!InningsEnded && delivery.Extra == Extra.None && score.LegalBalls % 6 == 0)
                SwapStrike(score);
        }

        public void ChangeInnings()
        {
            if (Innings != 0 || !InningsEnded) throw new InvalidOperationException("First innings is still active.");
            Innings = 1;
            InningsEnded = false;
        }

        public int PlayerOfMatch(TeamManager teams)
        {
            int best = teams.PlayerId(Winner < 0 ? 0 : Winner, 0);
            int bestRating = -1;
            for (int team = 0; team < 2; team++)
            {
                if (Winner >= 0 && team != Winner) continue;
                for (int slot = 0; slot < 4; slot++)
                {
                    int id = teams.PlayerId(team, slot);
                    int rating = BattingRuns[id] + 10 * BowlingWickets[id];
                    if (rating <= bestRating) continue;
                    best = id;
                    bestRating = rating;
                }
            }
            return best;
        }

        private static void SwapStrike(InningsScore score)
        {
            int previous = score.Striker;
            score.Striker = score.NonStriker;
            score.NonStriker = previous;
        }
    }
}
