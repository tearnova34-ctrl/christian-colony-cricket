# Christian Colony Cricket

Christian Colony Cricket is an offline portrait batting game built with Unity
6.3 LTS. Each round has one selected batter, one selected bowler, a fixed
camera behind the batting crease and a target to chase in 1, 2, 5, or 10 overs.
The mission ends at the target, the ball limit, or the third dismissal. The target is drawn per round from difficulty-dependent ranges and avoids immediately repeating the last target for the same settings.

- Batting is a tap for straight, a left or right swipe for the displayed side,
  or a longer upward swipe to drive straight with more power. Release as the
  indicator reaches the centre timing window.
- Timing determines runs. Perfect timing can score four, or six when a
  sufficiently strong loft clears the rope in the flight simulation. Good
  timing scores two or three, OK scores one, and edges are dot balls. A
  bowled dismissal requires physical contact with the stumps.
- The delivery result, score and recording share the same match event. The
  English speech clips are bundled. Turn Commentary off in Settings to play
  without the announcer.
- In Select Players, swap a favorite player into the top Blue batting slot
  or top Gold bowling slot. Both players remain for the round.

## Android build

Use Unity 6000.3.0f1 with Android Build Support, including the matching SDK,
NDK and OpenJDK. The runtime uses URP and bundled assets.

Choose **Christian Colony Cricket → Build Android APK** or invoke:

```sh
Unity -batchmode -quit -nographics -buildTarget Android \
  -projectPath "/absolute/path/to/Christian_Colony_Cricket_Unity_Project" \
  -executeMethod ColonyCricket.Editor.AndroidBuildConfiguration.BuildAndroid \
  -logFile "Christian_Colony_Cricket_Unity_Build.log"
```

The default output is `Builds/Android/Christian_Colony_Cricket.apk`. Set
`CCC_BUILD_DIR` to an absolute alternate output directory. The build uses
ARM64, IL2CPP, OpenGL ES 3, debug signing, and a minimum API of 26.

The Editor check exercises the run-up, bounce, directional shots, immediate
scoring, imported voice clips and completion for all four mission lengths, mission outcomes, grip sockets and joint lengths.
It does not replace checks for audio playback, portrait rendering or touch
response on Android hardware.

The team art and character models are original. The stylized anatomically
shaped faces, equipment, venue and fabrics are rendered in real time.
Speech clips were generated locally with Flite SLT. Font and speech
attributions are under `Assets/Licenses`.


The batting stance and grip timing use the supplied user video as a pose
reference. The procedural limb rig uses two-segment geometry and elbow and
knee bend hints, following Unity's Animation Rigging two-bone IK model.
Both hand positions are derived from the same bat handle transform.

- [Unity Animation Rigging Two Bone IK Constraint](https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.3/manual/constraints/TwoBoneIKConstraint.html)
- [Unity Quaternion.LookRotation](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Quaternion.LookRotation.html)
- [Cricket Namibia coaching guide](https://www.cricketnamibia.com/wp-content/uploads/2020/02/Kwata-Cricket-Coaching-Manual.pdf)
