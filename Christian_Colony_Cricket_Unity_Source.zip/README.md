# Christian Colony Cricket

An offline portrait cricket game project targeting Unity 6.3 LTS and Android. Blue bats first. After the innings break, the player bowls for Blue while Gold chases. Match lengths are one, two or five overs per side. The match HUD shows the predicted bounce, live fielder positions and the batting timing window.

- Batting takes a horizontal swipe. Finish the gesture as the ball reaches the bat. Short swipes keep the ball down and longer swipes can produce lofted shots. Click and drag in the Unity Editor.
- Bowl from the aim marker or drag on the playing area and release to bowl. Drag across to change line and up or down to change length. The delivery selector cycles the active bowler's options. An excessively long forward drag signals an overstep.
- Select Players can swap any two lineup slots. Put a favorite player first to open the batting and to open the bowling when their team fields.

## Build and verification

The four scenes, runtime components, textures, audio and their license notice are included. The project configures URP and player settings on first import. Its Android menu item runs the Editor-side gameplay checks before invoking Unity's Android builder. No manual scene or asset assembly is required.

Use Unity **6000.3.0f1** with **Android Build Support**, including the matching SDK, NDK and OpenJDK. On first import, Unity Package Manager must be able to resolve the pinned dependencies. The app itself has no network dependency.

In Unity use **Christian Colony Cricket → Verify gameplay logic** or **Christian Colony Cricket → Build Android APK**. The default build path relative to the project is `Builds/Android/Christian_Colony_Cricket.apk`.

The equivalent batch command for an installed, licensed Unity Editor is:

```sh
Unity -batchmode -quit -nographics -buildTarget Android \
  -projectPath "/absolute/path/to/Christian_Colony_Cricket_Unity_Project" \
  -executeMethod ColonyCricket.Editor.AndroidBuildConfiguration.BuildAndroid \
  -logFile "Christian_Colony_Cricket_Unity_Build.log"
```

Set `CCC_BUILD_DIR` to an absolute directory to change the APK location. The build is a standalone ARM64 APK using IL2CPP, OpenGL ES 3, ETC2 and Android API 26 minimum. Unity selects the target API from its installed Android platform. Unity's default debug signing is configured. See the accompanying build-status report for cloud build checks and pending device QA.

The previous Android packages declared `INTERNET`. The game uses bundled speech and assets and has no runtime connectivity requirement. Install on ARM64 Android, switch on airplane mode, and finish both innings using touch input before treating the APK as verified.

## Implementation

`Assets/Scripts/Cricket` contains the fixed-step match, trajectories, strokes, fielding and rules. `Assets/Scripts/Presentation` contains the stadium, player rigs, broadcast camera, scoreboard, menus, input, audio and settings. The five-over mode reuses the opening bowler for the fifth over. Batters run automatically. The implemented dismissals are bowled, caught and run out.

The arena, player meshes, animation poses, logo, texture art and synthesized audio are original to this project. The offline English announcer uses locally pre-rendered speech. The accompanying voice and font notices are in `Assets/Licenses`. Miniclip's publicly described quick matches, timing feedback and clear bowling aim informed the control flow. [Cricket League on Google Play](https://play.google.com/store/apps/details?id=com.miniclip.cricketleague)
