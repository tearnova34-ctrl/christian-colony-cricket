# Christian Colony Cricket

Christian Colony Cricket is an offline portrait batting game built with Unity
6.3 LTS. Each round has one selected batter, one selected bowler, a fixed
camera behind the batting crease and six, twelve, or thirty legal deliveries.
The round also ends when three balls hit the batting stumps.

- Batting is a tap for straight, a left or right swipe for the displayed side,
  or a longer upward swipe to drive straight with more power. Release as the
  indicator reaches the centre timing window.
- Timing determines runs. Perfect timing can score four, or six when a
  sufficiently strong loft clears the rope in the flight simulation. Good
  timing scores two or three, OK scores one, and edges are dot balls. A
  bowled dismissal requires physical contact with the stumps.
- The delivery result, score and recording share the same match event. The
  English speech clips are bundled. Turn Commentary off in Settings to play
  without the announcer.
- In Select Players, swap a favorite player into the top Blue batting slot
  or top Gold bowling slot. Both players remain for the round.

## Android build

Use Unity 6000.3.0f1 with Android Build Support, including the matching SDK,
NDK and OpenJDK. The runtime uses URP and bundled assets.

Choose **Christian Colony Cricket → Build Android APK** or invoke:

```sh
Unity -batchmode -quit -nographics -buildTarget Android \
  -projectPath "/absolute/path/to/Christian_Colony_Cricket_Unity_Project" \
  -executeMethod ColonyCricket.Editor.AndroidBuildConfiguration.BuildAndroid \
  -logFile "Christian_Colony_Cricket_Unity_Build.log"
```

The default output is `Builds/Android/Christian_Colony_Cricket.apk`. Set
`CCC_BUILD_DIR` to an absolute alternate output directory. The build uses
ARM64, IL2CPP, OpenGL ES 3, debug signing, and a minimum API of 26.

The Editor check exercises the run-up, bounce, directional shots, immediate
scoring, imported voice clips and completion for all three round lengths.
It does not replace checks for audio playback, portrait rendering or touch
response on Android hardware.

The team art and character models are original. The stylized anatomically
shaped faces, equipment, venue and fabrics are rendered in real time.
Speech clips were generated locally with Flite SLT. Font and speech
attributions are under `Assets/Licenses`.
